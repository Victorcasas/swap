# ISO-20022 Component
Library to help working with iso20022 messages

To add a new message, go to the bottom of pom.xml file and then develop just necessary code you need.

## Changelog
### 0.0.1-SNAPSHOT
* Pacs008v08 with builder, accessor & validator.
  

### 0.0.2-SNAPSHOT
* Refactored to a more abstracted model
* Pain001v11 & Pain002v12 models added

### 0.0.3-SNAPSHOT
* Added Pacs004v09 model

### 0.0.4-SNAPSHOT
* Refactoring of Pain001 model
* Added test & coverage to Pain001 model
* Fix field paths

