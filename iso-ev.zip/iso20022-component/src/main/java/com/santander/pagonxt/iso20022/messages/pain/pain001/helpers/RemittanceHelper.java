package com.santander.pagonxt.iso20022.messages.pain.pain001.helpers;

import com.santander.pagonxt.iso20022.common.fields.Remittance;
import com.santander.pagonxt.iso20022.messages.pain.pain001.accessors.PaymentAccessor;
import com.santander.pagonxt.iso20022.messages.pain.pain001.accessors.RemittanceAccessor;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.PaymentInstructionInformation3;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Clase encargada de devolver la lista de remesas
 */
public class RemittanceHelper {

    private final PaymentHelper paymentHelper;

    public RemittanceHelper() {
        this.paymentHelper = new PaymentHelper();
    }

    public void buildRemittanceList(Optional<List<PaymentInstructionInformation3>> remList,
                             ArrayList<Remittance> remittanceList, RemittanceAccessor acc, PaymentAccessor pAcc ) {
        for (PaymentInstructionInformation3 rem : remList.get()) {
            Remittance remOut = buildRemittance(rem, acc, pAcc);
            remittanceList.add(remOut);
        }
    }

    private Remittance buildRemittance(PaymentInstructionInformation3 rem, RemittanceAccessor acc, PaymentAccessor pAcc) {
        return Remittance.builder()
                .paymentMethod(acc.paymentMethod(rem))
                .paymentInfoId(acc.paymentInfoId(rem))
                .batchBooking(acc.batchBooking(rem))
                .numberOfTxs(acc.numberOfTxs(rem))
                .controlSum(acc.controlSum(rem))
                .instrPriority(acc.instrPriority(rem))
                .informationCode(acc.informationCode(rem))
                .localInstrumentCode(acc.localInstrumentCode(rem))
                .purpose(acc.purpose(rem))
                .requestedExecutionDate(acc.requestedExecutionDate(rem))
                .chargeBearer(acc.chargeBearer(rem))
                .originCountry(acc.sourceAddressCountry(rem))
                .debtorAccount(acc.debtorAccount(rem))
                .payments(paymentHelper.operationList(rem, acc, pAcc))
                .build();
    }
}
