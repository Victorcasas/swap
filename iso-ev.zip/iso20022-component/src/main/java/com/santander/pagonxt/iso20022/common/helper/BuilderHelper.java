package com.santander.pagonxt.iso20022.common.helper;

import com.santander.pagonxt.iso20022.mapper.OrikaMapper;
import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.accounts.LoanAccount;
import com.santander.pagonxt.iso20022.common.accounts.LocalAccount;
import com.santander.pagonxt.iso20022.common.accounts.SavingsAccount;
import com.santander.pagonxt.iso20022.common.paymentsubtype.IsoCode;
import com.santander.pagonxt.iso20022.common.accounts.SortcodeAccountNumber;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.paymentsubtype.PaymentSubtype;
import com.santander.pagonxt.iso20022.common.paymentsubtype.Proprietary;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.AccountIdentification4Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ActiveOrHistoricCurrencyAndAmount;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.BranchAndFinancialInstitutionIdentification6;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CashAccount38;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CashAccountType2Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CategoryPurpose1Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ClearingSystemMemberIdentification2;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.DateAndPlaceOfBirth1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.FinancialInstitutionIdentification18;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GenericAccountIdentification1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GenericFinancialIdentification1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GenericOrganisationIdentification1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GenericPersonIdentification1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.OrganisationIdentification29;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Party38Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PartyIdentification135;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PersonIdentification13;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PostalAddress24;
import lombok.NonNull;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.util.List;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.IntStream;

import static org.codehaus.plexus.util.StringUtils.isBlank;
import static org.codehaus.plexus.util.StringUtils.isNotBlank;

/**
 * Helper to create to common pacs objects among every pacs. First the object is created using pacs008 package,
 * then it's converted into the specific pacs package.
 */
public final class BuilderHelper {

    private BuilderHelper() {
    }

    /**
     * Fill party identification t.
     *
     * @param <T>                 the type parameter
     * @param partyIdentification the party identification
     * @param targetClass         the target class
     * @return the t
     */
    public static <T> T fillPartyIdentification(PartyIdentification partyIdentification, Class<T> targetClass) {
        final PartyIdentification135 partyIdentification135 = new PartyIdentification135();
        if (!isBlank(partyIdentification.getName())) {
            partyIdentification135.setNm(partyIdentification.getName());
        }
        final PostalAddress24 address = fillPostalAddress(partyIdentification.getAddress(), PostalAddress24.class);
        if (address != null) {
            partyIdentification135.setPstlAdr(address);
        }
        final PartyIdentification.PartyType partyType = partyIdentification.getPartyType();

        if (partyType != null) {
            Party38Choice party34ChoiceBuilder = new Party38Choice();

            if (partyType instanceof PartyIdentification.Person) {
                PersonIdentification13 idBuilder = new PersonIdentification13();

                if (isNotBlank(partyType.identifier())) {
                    GenericPersonIdentification1 genericPersonIdentification1 = new GenericPersonIdentification1();
                    genericPersonIdentification1.setId(partyType.identifier());
                    idBuilder.getOthrs().add(genericPersonIdentification1);
                }
                if (partyIdentification.getId() != null) {
                    final PartyIdentification.PersonIdentification prvtId = partyIdentification.getId().getPrvtId();
                    if (prvtId != null) {
                        final DateAndPlaceOfBirth1 dtAndPlcOfBirthBuild = new DateAndPlaceOfBirth1();
                        final PartyIdentification.DateAndPlaceOfBirth dtAndPlcOfBirth1 = prvtId.getDtAndPlcOfBirth();
                        dtAndPlcOfBirthBuild.setBirthDt(dtAndPlcOfBirth1.getBirthDt());
                        dtAndPlcOfBirthBuild.setCityOfBirth(dtAndPlcOfBirth1.getCityOfBirth());
                        dtAndPlcOfBirthBuild.setCtryOfBirth(dtAndPlcOfBirth1.getBirthCountry());
                        idBuilder.setDtAndPlcOfBirth(dtAndPlcOfBirthBuild);
                    }
                }
                party34ChoiceBuilder.setPrvtId(idBuilder);
                partyIdentification135.setId(party34ChoiceBuilder);

            } else if (partyType instanceof PartyIdentification.Organisation) {
                final PartyIdentification.Organisation organisation =
                        (PartyIdentification.Organisation) partyIdentification.getPartyType();
                OrganisationIdentification29 idBuilder = new OrganisationIdentification29();
                idBuilder.setAnyBIC(organisation.getBic());

                if (isNotBlank(organisation.getOtherId())) {
                    final GenericOrganisationIdentification1 genericOrganisationIdentification1 =
                            new GenericOrganisationIdentification1();
                    genericOrganisationIdentification1.setId(organisation.getOtherId());
                    idBuilder.getOthrs().add(genericOrganisationIdentification1);
                }
                party34ChoiceBuilder.setOrgId(idBuilder);
                partyIdentification135.setId(party34ChoiceBuilder);
            }
        }
        return OrikaMapper.mapper().map(partyIdentification135, targetClass);
    }

    /**
     * Fill postal address t.
     *
     * @param <T>                     the type parameter
     * @param address                 the address
     * @param postalAddres6TargeClass the postal addres 6 targe class
     * @return the t
     */
    public static <T> T fillPostalAddress(PartyIdentification.Address address, Class<T> postalAddres6TargeClass) {
        if (address == null || address.isEmpty()) {
            return null;
        }
        PostalAddress24 builder = new PostalAddress24();
        builder.getAdrLines().addAll(address.getAddressLine());
        if (!isBlank(address.getTown())) {
            builder.setTwnNm(address.getTown());
        }
        if (!isBlank(address.getPostCode())) {
            builder.setPstCd(address.getPostCode());
        }
        if (address.getCountry() != null) {
            builder.setCtry(address.getCountry());
        }

        return OrikaMapper.mapper().map(builder, postalAddres6TargeClass);
    }

    /**
     * Fill amount t.
     *
     * @param <T>               the type parameter
     * @param amount            the amount
     * @param amountTargetClass the amount target class
     * @return the t
     */
    public static <T> T fillAmount(@NonNull MonetaryAmount amount, Class<T> amountTargetClass) {

        ActiveOrHistoricCurrencyAndAmount activeOrHistoricCurrencyAndAmount = new ActiveOrHistoricCurrencyAndAmount();
        activeOrHistoricCurrencyAndAmount.setCcy(amount.getCurrency().getCurrencyCode());
        activeOrHistoricCurrencyAndAmount.setValue(amount.getNumber().numberValue(BigDecimal.class));

        return OrikaMapper.mapper().map(activeOrHistoricCurrencyAndAmount, amountTargetClass);
    }

    /**
     * Create financial institution t.
     *
     * @param <T>                    the type parameter
     * @param agent                  the agent
     * @param institutionTargetClass the institution target class
     * @return the t
     */
    public static <T> T createFinancialInstitution(BankAccount.Agent agent, Class<T> institutionTargetClass) {
        BranchAndFinancialInstitutionIdentification6 builder = new BranchAndFinancialInstitutionIdentification6();
        FinancialInstitutionIdentification18 finInstnIdBuilder = new FinancialInstitutionIdentification18();
        finInstnIdBuilder.setBICFI(agent.getBicfi());

        if (!isBlank(agent.getName())) {
            finInstnIdBuilder.setNm(agent.getName());
        }
        if (isNotBlank(agent.getOtherId())) {
            final GenericFinancialIdentification1 genericFinancialIdentification1 =
                    new GenericFinancialIdentification1();
            genericFinancialIdentification1.setId(agent.getOtherId());
            finInstnIdBuilder.setOthr(genericFinancialIdentification1);
        }
        if (isNotBlank(agent.getMemberId())) {
            final ClearingSystemMemberIdentification2 clearingSystemMemberIdentification2 =
                    new ClearingSystemMemberIdentification2();
            clearingSystemMemberIdentification2.setMmbId(agent.getMemberId());
            finInstnIdBuilder.setClrSysMmbId(clearingSystemMemberIdentification2);
        }
        if (agent.getAddress() != null) {
            final PostalAddress24 address = fillPostalAddress(agent.getAddress(), PostalAddress24.class);
            if (address != null) {
                finInstnIdBuilder.setPstlAdr(address);
            }
        }
        builder.setFinInstnId(finInstnIdBuilder);

        return OrikaMapper.mapper().map(builder, institutionTargetClass);
    }

    /**
     * Create financial institution t.
     *
     * @param <T>                    the type parameter
     * @param partyIdentification    the party identification
     * @param institutionTargetClass the institution target class
     * @return the t
     */
    public static <T> T createFinancialInstitution(PartyIdentification partyIdentification,
                                                   Class<T> institutionTargetClass) {
        BranchAndFinancialInstitutionIdentification6 builder = new BranchAndFinancialInstitutionIdentification6();
        FinancialInstitutionIdentification18 finInstnIdBuilder = new FinancialInstitutionIdentification18();
        PartyIdentification.PartyType partyType = partyIdentification.getPartyType();

        if (partyType instanceof PartyIdentification.Organisation) {
            PartyIdentification.Organisation organisation = (PartyIdentification.Organisation) partyType;
            finInstnIdBuilder.setBICFI(organisation.getBic());
            if (isNotBlank(organisation.getOtherId())) {
                final GenericFinancialIdentification1 genericFinancialIdentification1 =
                        new GenericFinancialIdentification1();
                genericFinancialIdentification1.setId(organisation.getOtherId());
                finInstnIdBuilder.setOthr(genericFinancialIdentification1);
            }
        }

        if (partyType instanceof PartyIdentification.Person) {
            PartyIdentification.Person person = (PartyIdentification.Person) partyType;
            if (isNotBlank(person.getOtherId())) {
                final GenericFinancialIdentification1 genericFinancialIdentification1 =
                        new GenericFinancialIdentification1();
                genericFinancialIdentification1.setId(person.getOtherId());
                finInstnIdBuilder.setOthr(genericFinancialIdentification1);
            }
        }

        if (!isBlank(partyIdentification.getName())) {
            finInstnIdBuilder.setNm(partyIdentification.getName());
        }

        PartyIdentification.Address partyIdentificationAddress = partyIdentification.getAddress();
        if (partyIdentificationAddress != null) {
            final PostalAddress24 address = fillPostalAddress(partyIdentificationAddress, PostalAddress24.class);
            if (address != null) {
                finInstnIdBuilder.setPstlAdr(address);
            }
        }

        builder.setFinInstnId(finInstnIdBuilder);

        return OrikaMapper.mapper().map(builder, institutionTargetClass);
    }


    /**
     * Create bank account t.
     *
     * @param <T>         the type parameter
     * @param bankAccount the bank account
     * @param targetClass the target class
     * @return the t
     */
    public static <T> T createBankAccount(BankAccount bankAccount, Class<T> targetClass) {
        if (bankAccount.hasNotAccount()) {
            return null;
        }

        final CashAccount38 builder = new CashAccount38();
        final BankAccount.Account.SchemeName schemeName = bankAccount.getSchemeName();
        if (!isBlank(bankAccount.getAccountName())) {
            builder.setNm(bankAccount.getAccountName());
        }
        if (!isBlank(bankAccount.getCurrency())) {
            builder.setCcy(bankAccount.getCurrency());
        }
        if (schemeName == BankAccount.Account.SchemeName.IBAN) {
            final AccountIdentification4Choice accountIdentification4Choice = new AccountIdentification4Choice();
            accountIdentification4Choice.setIBAN(bankAccount.getIdentification());
            builder.setId(accountIdentification4Choice);
        } else {
            final AccountIdentification4Choice accountIdentification4Choice = new AccountIdentification4Choice();
            final GenericAccountIdentification1 genericAccountIdentification1 = new GenericAccountIdentification1();
            if (bankAccount instanceof SortcodeAccountNumber) {
                genericAccountIdentification1.setId(((SortcodeAccountNumber) bankAccount).accountNumber());
            } else if (bankAccount instanceof SavingsAccount){
                genericAccountIdentification1.setId(((SavingsAccount) bankAccount).accountNumber());
            } else {
                genericAccountIdentification1.setId(bankAccount.getIdentification());
            }
            accountIdentification4Choice.setOthr(genericAccountIdentification1);
            builder.setId(accountIdentification4Choice);
        }
        if (bankAccount instanceof LoanAccount) {
            final CashAccountType2Choice cashAccountType2Choice = new CashAccountType2Choice();
            cashAccountType2Choice.setCd(com.santander.pagonxt.iso20022.common.accounts.IsoCode.Codes.LOAN.toString());
            builder.setTp(cashAccountType2Choice);
        } else if (bankAccount instanceof SavingsAccount) {
            final CashAccountType2Choice cashAccountType2Choice = new CashAccountType2Choice();
            cashAccountType2Choice.setCd(com.santander.pagonxt.iso20022.common.accounts.IsoCode.Codes.SVGS.toString());
            builder.setTp(cashAccountType2Choice);
        } else if (bankAccount instanceof LocalAccount) {
            bankAccount.getPartenonCode()
                    .map(code -> {
                        final CashAccountType2Choice cashAccountType2Choice = new CashAccountType2Choice();
                        cashAccountType2Choice.setPrtry(code);
                        return cashAccountType2Choice;
                    })
                    .ifPresent(builder::setTp);
        }

        return OrikaMapper.mapper().map(builder, targetClass);
    }

    /**
     * Fill payment subtype t.
     *
     * @param <T>                 the type parameter
     * @param subtype             the subtype
     * @param ctgyPurpTargetClass the ctgy purp target class
     * @return the t
     */
    public static <T> T fillPaymentSubtype(PaymentSubtype subtype, Class<T> ctgyPurpTargetClass) {
        final CategoryPurpose1Choice categoryPurpose1Choice = new CategoryPurpose1Choice();
        if (subtype instanceof Proprietary) {
            categoryPurpose1Choice.setPrtry(subtype.value());

        } else if (subtype instanceof IsoCode) {
            categoryPurpose1Choice.setCd(subtype.value());
        }
        return OrikaMapper.mapper().map(categoryPurpose1Choice, ctgyPurpTargetClass);
    }

    public static <T> Function<List<T>, T> getOrCreatePositionInList(int position, Supplier<T> constructor) {
        return list -> {
            IntStream.rangeClosed(list.size(), position)
                    .forEach(i -> list.add(constructor.get()));

            return list.get(position);
        };
    }
}
