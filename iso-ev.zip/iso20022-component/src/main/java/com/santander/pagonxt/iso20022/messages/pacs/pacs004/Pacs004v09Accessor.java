package com.santander.pagonxt.iso20022.messages.pacs.pacs004;

import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.accounts.BankAccount.Agent;
import com.santander.pagonxt.iso20022.common.codes.ExternalCode;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.fields.Priority;
import com.santander.pagonxt.iso20022.common.fields.ReasonInfo;
import com.santander.pagonxt.iso20022.common.fields.RemittanceInformation;
import com.santander.pagonxt.iso20022.common.fields.ReturnReason;
import com.santander.pagonxt.iso20022.common.helper.AccessorHelper;
import com.santander.pagonxt.iso20022.core.Iso20022MessageAccessor;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.CreditorReferenceInformation2;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Document;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.GroupHeader90;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.MandateRelatedInformation14;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.OriginalGroupInformation29;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.OriginalTransactionReference28;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Party40Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PartyIdentification135;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PaymentReturnReason6;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PaymentReturnV09;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PaymentTransaction112;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PaymentTypeInformation27;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Priority2Code;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.RemittanceInformation16;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.ReturnReason5Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.ServiceLevel8Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.StructuredRemittanceInformation16;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.TransactionParties7;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.santander.pagonxt.iso20022.common.fields.ReasonInfo.AdditionalInformation.additionalInformation;
import static com.santander.pagonxt.iso20022.common.helper.AccessorHelper.externalCode;
import static com.santander.pagonxt.iso20022.common.helper.AccessorHelper.firstInList;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;
import static javax.money.Monetary.getDefaultAmountFactory;
import static org.apache.commons.lang3.StringUtils.isBlank;

/**
 * The type Pacs 004 v 09 accessor.
 */
public class Pacs004v09Accessor extends Iso20022MessageAccessor<Document> {

    /**
     * Instantiates a new Pacs 004 v 09 accessor.
     *
     * @param document the document
     */
    public Pacs004v09Accessor(Document document) {
        this.document = document;
    }

    @Override
    public String messageId() {
        return of(document)
                .map(Document::getPmtRtr)
                .map(PaymentReturnV09::getGrpHdr)
                .map(GroupHeader90::getMsgId)
                .orElse(null);
    }

    @Override
    public String paymentScheme() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getPmtTpInf)
                .map(PaymentTypeInformation27::getSvcLvls)
                .map(firstInList())
                .map(ServiceLevel8Choice::getPrtry)
                .orElse(null);
    }

    @Override
    public String schemeId() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getRmtInf)
                .map(RemittanceInformation16::getStrds)
                .map(firstInList())
                .map(StructuredRemittanceInformation16::getAddtlRmtInves)
                .map(firstInList())
                .orElse(null);
    }

    @Override
    public String paymentSubType() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getPmtTpInf)
                .map(PaymentTypeInformation27::getCtgyPurp)
                .map(AccessorHelper::from)
                .orElse(null);
    }

    @Override
    public String paymentCode() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getPmtTpInf)
                .map(PaymentTypeInformation27::getLclInstrm)
                .map(AccessorHelper::from)
                .orElse(null);
    }

    @Override
    public MonetaryAmount amount() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getRtrdIntrBkSttlmAmt)
                .map(activeCurrencyAndAmount -> getDefaultAmountFactory()
                        .setCurrency(activeCurrencyAndAmount.getCcy())
                        .setNumber(activeCurrencyAndAmount.getValue())
                        .create())
                .orElse(null);
    }

    @Override
    public BankAccount debtorAccount() {
        final OriginalTransactionReference28 orgnlTxRef = ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .orElse(new OriginalTransactionReference28());
        return AccessorHelper.from(orgnlTxRef.getDbtrAgt(), orgnlTxRef.getDbtrAcct());
    }

    @Override
    public BankAccount creditorAccount() {
        final OriginalTransactionReference28 orgnlTxRef = ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .orElse(new OriginalTransactionReference28());
        return AccessorHelper.from(orgnlTxRef.getCdtrAgt(), orgnlTxRef.getCdtrAcct());
    }

    @Override
    public PartyIdentification debtor() {
        final PartyIdentification135 partyIdentification = of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getDbtr)
                .map(Party40Choice::getPty)
                .orElse(null);
        return AccessorHelper.from(partyIdentification);
    }

    @Override
    public PartyIdentification creditor() {
        final PartyIdentification135 partyIdentification = of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getCdtr)
                .map(Party40Choice::getPty)
                .orElse(null);
        return AccessorHelper.from(partyIdentification);
    }

    @Override
    public List<String> debtorReferences() {
        return Optional.ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getRmtInf)
                .map(RemittanceInformation16::getUstrds)
                .orElse(null);
    }

    @Override
    public List<String> creditorReferences() {
        List<StructuredRemittanceInformation16> structuredRemittanceInformation16s = of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getRmtInf)
                .map(RemittanceInformation16::getStrds)
                .orElse(Collections.emptyList());

        return structuredRemittanceInformation16s.stream()
                .map(rmtInf -> Optional.of(rmtInf)
                        .map(StructuredRemittanceInformation16::getCdtrRefInf)
                        .map(CreditorReferenceInformation2::getRef)
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    @Override
    public Agent instructingAgent() {
        return of(firstTransaction())
                .map(PaymentTransaction112::getInstgAgt)
                .map(AccessorHelper::agentFrom)
                .orElse(null);
    }

    @Override
    public Agent instructedAgent() {
        return of(firstTransaction())
                .map(PaymentTransaction112::getInstdAgt)
                .map(AccessorHelper::agentFrom)
                .orElse(null);
    }

    @Override
    public Priority instructionPriority() {
        final String instrPrty = of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getPmtTpInf)
                .map(PaymentTypeInformation27::getInstrPrty)
                .map(Priority2Code::value)
                .orElse("");
        return Priority.valueOf(instrPrty);
    }

    @Override
    public String transactionId() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getRtrId)
                .orElse(null);
    }

    @Override
    public String transactionReference() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getClrSysRef)
                .orElse(null);
    }

    @Override
    public String endToEndId() {
        return Optional.ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlEndToEndId)
                .orElse(null);
    }

    @Override
    public UUID uetr() {
        return UUID.fromString(of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlUETR)
                .orElse(""));
    }

    @Override
    public String instructionId() {
        return of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlInstrId)
                .orElse(null);
    }

    @Override
    public String originalTransactionId() {
        return of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxId)
                .orElse(null);
    }

    @Override
    public String originalMessageId() {
        return of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlGrpInf)
                .map(OriginalGroupInformation29::getOrgnlMsgId)
                .orElse("");
    }

    @Override
    public String originalMessageName() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlGrpInf)
                .map(OriginalGroupInformation29::getOrgnlMsgNmId)
                .orElse(null);
    }

    @Override
    public LocalDate requestedCollectionDate() {
        final OriginalTransactionReference28 orgnlTxRef = ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .orElse(new OriginalTransactionReference28());
        return orgnlTxRef.getReqdColltnDt();
    }

    @Override
    public String tppId() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getMndtRltdInf)
                .map(MandateRelatedInformation14::getElctrncSgntr)
                .orElse(null);
    }

    @Override
    public RemittanceInformation remittanceInformation() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getRmtInf)
                .map(RemittanceInformation16::getStrds)
                .map(firstInList())
                .map(StructuredRemittanceInformation16::getAddtlRmtInves)
                .map(list -> {
                    if (list.size() < 2) return null;
                    if (isBlank(list.get(0)) && isBlank(list.get(1))) return null;
                    return RemittanceInformation.builder()
                            .reference(list.get(0))
                            .unstructured(list.get(1))
                            .build();
                }).orElse(null);
    }

    @Override
    public MonetaryAmount originalAmount() {
        return of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlIntrBkSttlmAmt)
                .map(activeOrHistoricCurrencyAndAmount -> getDefaultAmountFactory()
                        .setNumber(activeOrHistoricCurrencyAndAmount.getValue())
                        .setCurrency(activeOrHistoricCurrencyAndAmount.getCcy())
                        .create())
                .orElse(null);
    }

    @Override
    public LocalDate interBankSttlmDate() {
        return Optional.of(firstTransaction())
                .map(PaymentTransaction112::getIntrBkSttlmDt)
                .orElse(null);
    }

    @Override
    public LocalDate originalTxInternationalBankSettlementDate() {
        return Optional.of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .map(OriginalTransactionReference28::getIntrBkSttlmDt)
                .orElse(null);
    }

    @Override
    public BigDecimal xchgRate() {
        return Optional.of(firstTransaction())
                .map(PaymentTransaction112::getXchgRate)
                .orElse(null);
    }

    @Override
    public MonetaryAmount compensationAmount() {
        return Optional.of(firstTransaction())
                .map(PaymentTransaction112::getCompstnAmt)
                .map(activeOrHistoricCurrencyAndAmount -> getDefaultAmountFactory()
                        .setNumber(activeOrHistoricCurrencyAndAmount.getValue())
                        .setCurrency(activeOrHistoricCurrencyAndAmount.getCcy())
                        .create())
                .orElse(null);
    }

    @Override
    public PartyIdentification ultimateDebtor() {
        final PartyIdentification135 partyIdentification = of(firstTransaction())
                .map(PaymentTransaction112::getRtrChain)
                .map(TransactionParties7::getUltmtDbtr)
                .map(Party40Choice::getPty)
                .orElse(null);
        return AccessorHelper.from(partyIdentification);
    }

    @Override
    public PartyIdentification debtorParty() {
        final PartyIdentification135 partyIdentification = of(firstTransaction())
                .map(PaymentTransaction112::getRtrChain)
                .map(TransactionParties7::getDbtr)
                .map(Party40Choice::getPty)
                .orElse(null);
        return AccessorHelper.from(partyIdentification);
    }

    @Override
    public Agent debtorAgent() {
        TransactionParties7 transactionParties = ofNullable(firstTransaction())
                .map(PaymentTransaction112::getRtrChain)
                .orElse(new TransactionParties7());
        return AccessorHelper.fromAgent(transactionParties.getDbtrAgt());
    }

    @Override
    public PartyIdentification ultimateCreditor() {
        final PartyIdentification135 partyIdentification = of(firstTransaction())
                .map(PaymentTransaction112::getRtrChain)
                .map(TransactionParties7::getUltmtCdtr)
                .map(Party40Choice::getPty)
                .orElse(null);
        return AccessorHelper.from(partyIdentification);
    }

    @Override
    public PartyIdentification creditorParty() {
        final PartyIdentification135 partyIdentification = of(firstTransaction())
                .map(PaymentTransaction112::getRtrChain)
                .map(TransactionParties7::getCdtr)
                .map(Party40Choice::getPty)
                .orElse(null);
        return AccessorHelper.from(partyIdentification);
    }

    @Override
    public Agent creditorAgent() {
        TransactionParties7 transactionParties = ofNullable(firstTransaction())
                .map(PaymentTransaction112::getRtrChain)
                .orElse(new TransactionParties7());
        return AccessorHelper.fromAgent(transactionParties.getCdtrAgt());
    }

    @Override
    public MonetaryAmount returnedInstructedAmount() {
        return ofNullable(firstTransaction())
                .map(PaymentTransaction112::getRtrdInstdAmt)
                .map(activeCurrencyAndAmount -> getDefaultAmountFactory()
                        .setCurrency(activeCurrencyAndAmount.getCcy())
                        .setNumber(activeCurrencyAndAmount.getValue())
                        .create())
                .orElse(null);
    }

    @Override
    public ReasonInfo returnReason() {
        Optional<PaymentReturnReason6> paymentReturnReason6 = ofNullable(firstTransaction())
                .map(PaymentTransaction112::getRtrRsnInves)
                .map(firstInList());

        Optional<ReturnReason5Choice> returnReason5Choice = paymentReturnReason6
                .map(PaymentReturnReason6::getRsn);

        if (returnReason5Choice.isEmpty()) {
            return null;
        }

        final Optional<List<String>> strings = paymentReturnReason6
                .map(PaymentReturnReason6::getAddtlInves);

        ExternalCode externalCode = externalCode(returnReason5Choice.get(), ReturnReason.class);

        if (strings.isPresent() && strings.get().size() >= 2) {
            final List<String> values = strings.get();
            return ReasonInfo.builder()
                    .code(externalCode)
                    .rawCode(ofNullable(values.get(0)).orElse(""))
                    .rawDescription(ofNullable(values.get(1)).orElse(""))
                    .additionalInformation(values.size() > 2 ? additionalInformation()
                            .extraInfo(values.subList(2, values.size())) : null)
                    .build();
        }

        return ReasonInfo.builder()
                .code(externalCode)
                .rawCode("")
                .rawDescription("")
                .build();
    }

    private PaymentTransaction112 firstTransaction() {
        return of(document)
                .map(Document::getPmtRtr)
                .map(PaymentReturnV09::getTxInves)
                .orElse(List.of())
                .get(0);
    }
}
