package com.santander.pagonxt.iso20022.xmladapter;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

/**
 * The type Xml adapter.
 */
public class XMLAdapter {

    private XMLAdapter() {
    }

    /**
     * Unmarshal date local date.
     *
     * @param s the s
     * @return the local date
     */
    public static LocalDate unmarshalDate(String s) {
        return LocalDate.parse(s);
    }

    /**
     * Marshal date string.
     *
     * @param localDate the local date
     * @return the string
     */
    public static String marshalDate(LocalDate localDate) {
        return localDate.format(DateTimeFormatter.ISO_LOCAL_DATE);
    }

    /**
     * Unmarshal date time local date time.
     *
     * @param s the s
     * @return the local date time
     */
    public static LocalDateTime unmarshalDateTime(String s) {
        return LocalDateTime.parse(s);
    }

    /**
     * Marshal date time string.
     *
     * @param localDate the local date
     * @return the string
     */
    public static String marshalDateTime(LocalDateTime localDate) {
        return localDate.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
    }

    /**
     * Unmarshal date time zoned date time.
     *
     * @param s the s
     * @return the local date time
     */
    public static ZonedDateTime unmarshalZonedDateTime(String s) {
        return ZonedDateTime.parse(s);
    }

    /**
     * Marshal date time string.
     *
     * @param localDate the local date
     * @return the string
     */
    public static String marshalZonedDateTime(ZonedDateTime localDate) {
        return localDate.format(DateTimeFormatter.ISO_ZONED_DATE_TIME);
    }
}
