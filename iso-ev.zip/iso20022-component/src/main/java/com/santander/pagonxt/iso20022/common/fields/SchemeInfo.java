package com.santander.pagonxt.iso20022.common.fields;

import lombok.Getter;
import lombok.Value;

@Value
public class SchemeInfo {
    String schemeId;
    Scheme scheme;

    @Getter
    public enum Scheme {
        FP("FPID"),
        CHAPS("CHAPS TRN"),
        SWIFT("SWIFT TRN"),
        CORRESPONDENTBANKS("CORRESPONDENTBANKS TRN"),
        BACS("BACS"),
        INTERNAL("INTERNAL"),
        SEPA("SEPA"),
        GTS("GTS"),
        HH("HH"),
        TARGET2("TARGET2"),
        INT("int");

        public final String prefix;

        Scheme(String prefix) {
            this.prefix = prefix;
        }
    }
}
