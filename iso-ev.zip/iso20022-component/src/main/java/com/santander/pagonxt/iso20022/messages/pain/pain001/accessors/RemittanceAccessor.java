package com.santander.pagonxt.iso20022.messages.pain.pain001.accessors;

import com.santander.pagonxt.iso20022.common.util.StringFieldsUtils;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.*;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.time.LocalDate;

import static java.util.Optional.of;

/**
 * The type Remittance accessor.
 */
public class RemittanceAccessor {

    /**
     * Payment method payment method 3 code.
     *
     * @param remittance the remittance
     * @return the payment method 3 code
     */
    public String paymentMethod(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getPmtMtd)
                .map(PaymentMethod3Code::value)
                .orElse(null);
    }

    /**
     * Payment info id string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String paymentInfoId(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getPmtInfId)
                .orElse(null);
    }

    /**
     * Batch booking boolean.
     *
     * @param remittance the remittance
     * @return the boolean
     */
    public Boolean batchBooking(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::isBtchBookg)
                .orElse(null);
    }

    /**
     * Number of taxes Integer.
     *
     * @param remittance the remittance
     * @return the Integer
     */
    public Integer numberOfTxs(PaymentInstructionInformation3 remittance) {
        String nTax = of(remittance)
                        .map(PaymentInstructionInformation3::getNbOfTxs)
                        .orElse(null);

        return nTax==null?0:Integer.parseInt(nTax);
    }

    /**
     * Control sum big decimal.
     *
     * @param remittance the remittance
     * @return the big decimal
     */
    public BigDecimal controlSum(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getCtrlSum)
                .orElse(null);
    }

    /**
     * Instr priority priority 2 code.
     *
     * @param remittance the remittance
     * @return the priority 2 code
     */
    public String instrPriority(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getPmtTpInf)
                .map(PaymentTypeInformation19::getInstrPrty)
                .map(Priority2Code::value)
                .orElse(null);
    }

    /**
     * Service level string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String informationCode(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getPmtTpInf)
                .map(PaymentTypeInformation19::getSvcLvl)
                .map(info -> {
                    if(StringUtils.isNotEmpty(info.getCd()))
                        return info.getCd();
                        else
                            return info.getPrtry();
                })
                .orElse(null);
    }

    /**
     * Local instrument string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String localInstrumentCode(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getPmtTpInf)
                .map(PaymentTypeInformation19::getLclInstrm)
                .map(info -> {
                    if(StringUtils.isNotEmpty(info.getCd()))
                        return info.getCd();
                    else
                        return info.getPrtry();
                })
                .orElse(null);
    }

    /**
     * Category purpose string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String purpose(PaymentInstructionInformation3 remittance) {

        return of(remittance)
                .map(PaymentInstructionInformation3::getPmtTpInf)
                .map(PaymentTypeInformation19::getCtgyPurp)
                .map(info -> {
                    if(StringUtils.isNotEmpty(info.getCd()))
                        return info.getCd();
                    else
                        return info.getPrtry();
                })
                .orElse(null);
    }

    /**
     * Requested execution date local date.
     *
     * @param remittance the remittance
     * @return the local date
     */
    public LocalDate requestedExecutionDate(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getReqdExctnDt)
                .map(date -> date.toGregorianCalendar().toZonedDateTime().toLocalDate())
                .orElse(null);
    }

    /**
     * Charge bearer charge bearer type 1 code.
     *
     * @param remittance the remittance
     * @return the charge bearer type 1 code
     */
    public String chargeBearer(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getChrgBr)
                .map(ChargeBearerType1Code::value)
                .orElse(null);
    }

    /**
     * Source name string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceName(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtr)
                .map(PartyIdentification32::getNm)
                .orElse(null);
    }

    /**
     * Source customer id optional.
     *
     * @param remittance the remittance
     * @return the optional
     */
    public String sourceCustomerId(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtr)
                .map(PartyIdentification32::getId)
                .map(Party6Choice::getOrgId)
                .map(OrganisationIdentification4::getOthrs)
                .map(list -> list.get(0))
                .map(GenericOrganisationIdentification1::getId)
                .orElse(null);
    }

    /**
     * Source address street string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAddressStreet(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtr)
                .map(PartyIdentification32::getPstlAdr)
                .map(addr -> {
                    StringBuilder str = new StringBuilder();
                    StringFieldsUtils.addSafeFieldWithSeparator(str, addr.getStrtNm()," ");
                    StringFieldsUtils.addSafeFieldWithSeparator(str, addr.getBldgNb(),null);
                    return str.toString();
                })
                .orElse(null);
    }

    /**
     * Source address street string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAddressName(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtr)
                .map(PartyIdentification32::getNm)
                .orElse(null);
    }

    /**
     * Source address town string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAddressTown(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtr)
                .map(PartyIdentification32::getPstlAdr)
                .map(PostalAddress6::getTwnNm)
                .orElse(null);
    }

    /**
     * Source address country sub division string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAddressCountrySubDivision(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtr)
                .map(PartyIdentification32::getPstlAdr)
                .map(PostalAddress6::getCtrySubDvsn)
                .orElse(null);
    }

    /**
     * Source address country string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAddressCountry(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtr)
                .map(PartyIdentification32::getPstlAdr)
                .map(PostalAddress6::getCtry)
                .orElse(null);
    }

    public String sourceAddressPostalCode(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtr)
                .map(PartyIdentification32::getPstlAdr)
                .map(PostalAddress6::getPstCd)
                .orElse(null);
    }

    /**
     * Source address string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAddress(PaymentInstructionInformation3 remittance) {
        StringBuilder builder = new StringBuilder();

        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceAddressStreet(remittance), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceAddressTown(remittance), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceAddressCountrySubDivision(remittance), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceAddressCountry(remittance), null);

        return builder.toString();
    }

    /**
     * Source account id account identification 4 choice.
     *
     * @param remittance the remittance
     * @return the account identification 4 choice
     */
    public String debtorAccount(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtrAcct)
                .map(CashAccount16::getId)
                .map(info -> {
                    if(StringUtils.isNotEmpty(info.getIBAN()))
                        return info.getIBAN();
                    else if(info.getOthr() !=null)
                        return info.getOthr().getId();

                    return null;
                })
                .orElse(null);
    }

    /**
     * Source account currency string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAccountCurrency(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtrAcct)
                .map(CashAccount16::getCcy)
                .orElse(null);
    }

    /**
     * Source agent string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAgent(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getBIC)
                .orElse(null);
    }

    /**
     * Source agent name string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAgentName(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getNm)
                .orElse(null);
    }

    /**
     * Source agent address street string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAgentAddressStreet(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getStrtNm)
                .orElse(null);
    }

    /**
     * Source agent address town string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAgentAddressTown(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getTwnNm)
                .orElse(null);
    }

    /**
     * Source agent address country sub division string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAgentAddressCountrySubDivision(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getCtrySubDvsn)
                .orElse(null);
    }

    /**
     * Source agent address country string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAgentAddressCountry(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getCtry)
                .orElse(null);
    }

    /**
     * Source agent address string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceAgentAddress(PaymentInstructionInformation3 remittance) {

        StringBuilder builder = new StringBuilder();

        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceAgentAddressStreet(remittance), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceAgentAddressTown(remittance), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceAgentAddressCountrySubDivision(remittance), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceAgentAddressCountry(remittance), null);

        return builder.toString();
    }

    /**
     * Source fee account id string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceFeeAccountId(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getChrgsAcct)
                .map(CashAccount16::getId)
                .map(info -> {
                    if(StringUtils.isNotEmpty(info.getIBAN()))
                        return info.getIBAN();
                    else if(info.getOthr() !=null)
                        return info.getOthr().getId();

                    return null;
                })
                .orElse(null);
    }

    /**
     * Source fee account currency string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceFeeAccountCurrency(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getChrgsAcct)
                .map(CashAccount16::getCcy)
                .orElse(null);
    }

    /**
     * Source fee agent string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceFeeAgent(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getChrgsAcctAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getBIC)
                .orElse(null);
    }

    /**
     * Source fee agent name string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceFeeAgentName(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getChrgsAcctAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getNm)
                .orElse(null);
    }

    /**
     * Source fee agent address street string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceFeeAgentAddressStreet(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getChrgsAcctAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getStrtNm)
                .orElse(null);
    }

    /**
     * Source fee agent address town string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceFeeAgentAddressTown(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getChrgsAcctAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getTwnNm)
                .orElse(null);
    }

    /**
     * Source fee agent address country sub division string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceFeeAgentAddressCountrySubDivision(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getChrgsAcctAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getCtrySubDvsn)
                .orElse(null);
    }

    /**
     * Source fee agent address country string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceFeeAgentAddressCountry(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getChrgsAcctAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getCtry)
                .orElse(null);
    }

    /**
     * Source fee agent address string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String sourceFeeAgentAddress(PaymentInstructionInformation3 remittance) {

        StringBuilder builder = new StringBuilder();

        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceFeeAgentAddressStreet(remittance), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceFeeAgentAddressTown(remittance), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceFeeAgentAddressCountrySubDivision(remittance), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,sourceFeeAgentAddressCountry(remittance), null);

        return builder.toString();
    }

    /**
     * Counter value operation amount trade currency string.
     *
     * @param remittance the remittance
     * @return the string
     */
    public String counterValueOperationAmountTradeCurrency(PaymentInstructionInformation3 remittance) {
        return of(remittance)
                .map(PaymentInstructionInformation3::getDbtrAcct)
                .map(CashAccount16::getCcy)
                .orElse(null);
    }


}
