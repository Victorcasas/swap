package com.santander.pagonxt.iso20022.messages.pacs.pacs008;

import com.santander.pagonxt.iso20022.core.Iso20022MessageAccessor;
import com.santander.pagonxt.iso20022.common.helper.AccessorHelper;
import com.santander.pagonxt.iso20022.mapper.OrikaMapper;
import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.fields.CustomCharges;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GenericAccountIdentification1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GroupHeader93;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.InstructionForCreditorAgent1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.InstructionForNextAgent1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PaymentIdentification7;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PaymentTypeInformation28;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.RemittanceInformation16;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ServiceLevel8Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.SettlementInstruction7;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.StructuredRemittanceInformation16;
import com.santander.pagonxt.iso20022.common.codes.ChargeBearer;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.fields.References;
import com.santander.pagonxt.iso20022.common.fields.RegulatoryReport;
import com.santander.pagonxt.iso20022.common.fields.RemittanceInformation;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.AccountIdentification4Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ActiveOrHistoricCurrencyAndAmount;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.BranchAndFinancialInstitutionIdentification6;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.BranchData3;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CashAccount38;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Charges7;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ClearingSystemIdentification2Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ClearingSystemIdentification3Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ClearingSystemMemberIdentification2;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CreditTransferTransaction39;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CreditorReferenceInformation2;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Document;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.FIToFICustomerCreditTransferV08;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.FinancialInstitutionIdentification18;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import static com.santander.pagonxt.iso20022.common.fields.References.ACCOUNTING_REFERENCE_LABEL;
import static com.santander.pagonxt.iso20022.common.fields.References.ORIGINAL_MESSAGE_ID_LABEL;
import static java.util.Collections.emptyList;
import static java.util.Optional.of;
import static javax.money.Monetary.getDefaultAmountFactory;
import static org.codehaus.plexus.util.StringUtils.isBlank;

/**
 * The type Pacs 008 accessor.
 */
public class Pacs008v08Accessor extends Iso20022MessageAccessor<Document> {

    /**
     * The constant CRED.
     */
    public static final String CRED = "CRED";
    /**
     * The constant DEBT.
     */
    public static final String DEBT = "DEBT";
    /**
     * The constant SHAR.
     */
    public static final String SHAR = "SHAR";

    /**
     * Instantiates a new Pacs 008 accessor.
     *
     * @param document the document
     */
    public Pacs008v08Accessor(Document document) {
        this.document = document;
    }

    /**
     * Message id string.
     *
     * @return the string
     */
    @Override
    public String messageId() {
        return of(document)
                .map(Document::getFIToFICstmrCdtTrf)
                .map(FIToFICustomerCreditTransferV08::getGrpHdr)
                .map(GroupHeader93::getMsgId)
                .orElse(null);
    }

    /**
     * End to end id string.
     *
     * @return the string
     */
    @Override
    public String endToEndId() {
        return pmtId()
                .map(PaymentIdentification7::getEndToEndId)
                .orElse(null);
    }

    /**
     * Instruction id string.
     *
     * @return the string
     */
    @Override
    public String instructionId() {
        return pmtId()
                .map(PaymentIdentification7::getInstrId)
                .orElse(null);
    }

    /**
     * Amount monetary amount.
     *
     * @return the monetary amount
     */
    @Override
    public MonetaryAmount amount() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getIntrBkSttlmAmt)
                .map(activeCurrencyAndAmount -> getDefaultAmountFactory()
                        .setCurrency(activeCurrencyAndAmount.getCcy())
                        .setNumber(activeCurrencyAndAmount.getValue())
                        .create())
                .orElse(null);
    }

    /**
     * Debtor party identification.
     *
     * @return the party identification
     */
    @Override
    public PartyIdentification debtor() {
        return AccessorHelper.from(firstTransaction()
                .map(CreditTransferTransaction39::getDbtr)
                .orElse(null));
    }

    /**
     * Creditor party identification.
     *
     * @return the party identification
     */
    @Override
    public PartyIdentification creditor() {
        return AccessorHelper.from(firstTransaction()
                .map(CreditTransferTransaction39::getCdtr)
                .orElse(null));
    }

    /**
     * Debtor account bank account.
     *
     * @return the bank account
     */
    @Override
    public BankAccount debtorAccount() {
        final BranchAndFinancialInstitutionIdentification6 debtorAgt = firstTransaction()
                .map(CreditTransferTransaction39::getDbtrAgt)
                .orElse(null);
        final CashAccount38 debtorAcct = firstTransaction()
                .map(CreditTransferTransaction39::getDbtrAcct)
                .orElse(null);
        return AccessorHelper.from(debtorAgt, debtorAcct);
    }

    /**
     * Creditor account bank account.
     *
     * @return the bank account
     */
    @Override
    public BankAccount creditorAccount() {
        final BranchAndFinancialInstitutionIdentification6 creditorAgt = firstTransaction()
                .map(CreditTransferTransaction39::getCdtrAgt)
                .orElse(null);
        final CashAccount38 creditorAcct = firstTransaction()
                .map(CreditTransferTransaction39::getCdtrAcct)
                .orElse(null);
        return AccessorHelper.from(creditorAgt, creditorAcct);
    }

    /**
     * Instructed agent agent.
     *
     * @return the agent
     */
    @Override
    public BankAccount.Agent instructedAgent() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getInstdAgt)
                .map(AccessorHelper::from)
                .orElse(null);
    }

    /**
     * Instructing agent agent.
     *
     * @return the agent
     */
    @Override
    public BankAccount.Agent instructingAgent() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getInstgAgt)
                .map(AccessorHelper::from)
                .orElse(null);
    }

    /**
     * Instructed reimbursement agent agent.
     *
     * @return the agent
     */
    @Override
    public BankAccount.Agent instructedReimbursementAgent() {
        return of(document)
                .map(Document::getFIToFICstmrCdtTrf)
                .map(FIToFICustomerCreditTransferV08::getGrpHdr)
                .map(GroupHeader93::getSttlmInf)
                .map(SettlementInstruction7::getInstdRmbrsmntAgt)
                .map(AccessorHelper::from)
                .orElse(null);
    }

    /**
     * Instructing reimbursement agent agent.
     *
     * @return the agent
     */
    @Override
    public BankAccount.Agent instructingReimbursementAgent() {
        return getInstructingReimbursementAgent()
                .map(AccessorHelper::from)
                .orElse(null);
    }

    /**
     * Instructing reimbursement agent ncc string.
     *
     * @return the string
     */
    @Override
    public String instructingReimbursementAgentNCC() {
        return getInstructingReimbursementAgent()
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getClrSysId)
                .map(ClearingSystemIdentification2Choice::getCd)
                .orElse(null);
    }

    /**
     * Instructing reimbursement agent member id string.
     *
     * @return the string
     */
    @Override
    public String instructingReimbursementAgentMemberId() {
        return getInstructingReimbursementAgent()
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getMmbId)
                .orElse(null);
    }

    /**
     * Instructing reimbursement agent identification string.
     *
     * @return the string
     */
    @Override
    public String instructingReimbursementAgentIdentification() {
        return getInstructingReimbursementAgentAccount()
                .map(CashAccount38::getId)
                .map(AccountIdentification4Choice::getIBAN)
                .orElse(getInstructingReimbursementAgentAccount()
                        .map(CashAccount38::getId)
                        .map(AccountIdentification4Choice::getOthr)
                        .map(GenericAccountIdentification1::getId)
                        .orElse(null));
    }

    /**
     * Instructed reimbursement agent ncc string.
     *
     * @return the string
     */
    @Override
    public String instructedReimbursementAgentNCC() {
        return getInstructingReimbursementAgent()
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getClrSysId)
                .map(ClearingSystemIdentification2Choice::getCd)
                .orElse(null);
    }

    /**
     * Instructed reimbursement agent member id string.
     *
     * @return the string
     */
    @Override
    public String instructedReimbursementAgentMemberId() {
        return getInstructingReimbursementAgent()
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getMmbId)
                .orElse(null);
    }

    /**
     * Instructed reimbursement agent identification string.
     *
     * @return the string
     */
    @Override
    public String instructedReimbursementAgentIdentification() {
        return getInstructingReimbursementAgentAccount()
                .map(CashAccount38::getId)
                .map(AccountIdentification4Choice::getIBAN)
                .orElse(getInstructingReimbursementAgentAccount()
                        .map(CashAccount38::getId)
                        .map(AccountIdentification4Choice::getOthr)
                        .map(GenericAccountIdentification1::getId)
                        .orElse(null));
    }

    /**
     * Clearing system string.
     *
     * @return the string
     */
    @Override
    public String clearingSystem() {
        final Optional<ClearingSystemIdentification3Choice> clearingSystem = of(document)
                .map(Document::getFIToFICstmrCdtTrf)
                .map(FIToFICustomerCreditTransferV08::getGrpHdr)
                .map(GroupHeader93::getSttlmInf)
                .map(SettlementInstruction7::getClrSys);
        return clearingSystem
                .map(ClearingSystemIdentification3Choice::getCd)
                .orElse(clearingSystem
                        .map(ClearingSystemIdentification3Choice::getPrtry)
                        .orElse(null));
    }

    /**
     * Original amount monetary amount.
     *
     * @return the monetary amount
     */
    @Override
    public MonetaryAmount originalAmount() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getInstdAmt)
                .map(activeCurrencyAndAmount -> getDefaultAmountFactory()
                        .setCurrency(activeCurrencyAndAmount.getCcy())
                        .setNumber(activeCurrencyAndAmount.getValue())
                        .create())
                .orElse(null);
    }

    /**
     * Instructions for next agent list.
     *
     * @return the list
     */
    @Override
    public List<String> instructionsForNextAgent() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getInstrForNxtAgts)
                .orElse(Collections.emptyList())
                .stream()
                .map(InstructionForNextAgent1::getInstrInf)
                .collect(Collectors.toList());
    }

    /**
     * Correspondent account bank account.
     *
     * @return the bank account
     */
    @Override
    public BankAccount correspondentAccount() {
        final BranchAndFinancialInstitutionIdentification6 intermediaryAgent = firstTransaction()
                .map(CreditTransferTransaction39::getIntrmyAgt1)
                .orElse(null);
        final CashAccount38 intermediaryAccount = firstTransaction()
                .map(CreditTransferTransaction39::getIntrmyAgt1Acct)
                .orElse(null);
        return AccessorHelper.from(intermediaryAgent, intermediaryAccount);
    }

    /**
     * Intermediary agent ncc code string.
     *
     * @return the string
     */
    @Override
    public String intermediaryAgentNCCCode() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getIntrmyAgt1)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getClrSysId)
                .map(ClearingSystemIdentification2Choice::getCd)
                .orElse(null);
    }

    /**
     * Debtor agent account bank account.
     *
     * @return the bank account
     */
    @Override
    public BankAccount debtorAgentAccount() {
        final CashAccount38 debtorAgentAccount = firstTransaction()
                .map(CreditTransferTransaction39::getDbtrAgtAcct)
                .orElse(null);
        return AccessorHelper.from(null, debtorAgentAccount);
    }

    /**
     * Creditor agent account bank account.
     *
     * @return the bank account
     */
    @Override
    public BankAccount creditorAgentAccount() {
        final CashAccount38 creditorAgentAccount = firstTransaction()
                .map(CreditTransferTransaction39::getCdtrAcct)
                .orElse(null);
        return AccessorHelper.from(null, creditorAgentAccount);
    }

    /**
     * Charge bearer charge bearer.
     *
     * @return the charge bearer
     */
    @Override
    public ChargeBearer chargeBearer() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getChrgBr)
                .map(ChargeBearer::from)
                .orElse(null);
    }

    /**
     * Gets expenses type.
     *
     * @return the expenses type
     */
    @Override
    public String getExpensesType() {
        String var1 = chargeBearer().name();
        switch (var1.hashCode()) {
            case 2077006:
                if (var1.equals(CRED)) {
                    return "BEN";
                }
                break;
            case 2094227:
                if (var1.equals(DEBT)) {
                    return "OUR";
                }
                break;
            case 2543942:
                if (var1.equals(SHAR)) {
                    return "SHA";
                }
                break;
            default:
                throw new RuntimeException("Unknown expenses type");
        }
        return null;
    }

    /**
     * Gets charges info.
     *
     * @return the charges info
     */
    @Override
    public List<CustomCharges> getChargesInfo() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getChrgsInves)
                .orElse(List.of())
                .stream()
                .map(charges2 ->
                        CustomCharges.builder()
                                .agent(from(charges2.getAgt()))
                                .concept(of(charges2)
                                        .map(Charges7::getAgt)
                                        .map(BranchAndFinancialInstitutionIdentification6::getBrnchId)
                                        .map(BranchData3::getNm)
                                        .orElse(null))
                                .currency(of(charges2)
                                        .map(Charges7::getAmt)
                                        .map(ActiveOrHistoricCurrencyAndAmount::getCcy)
                                        .orElse(null))
                                .amount(of(charges2)
                                        .map(Charges7::getAmt)
                                        .map(ActiveOrHistoricCurrencyAndAmount::getValue)
                                        .orElse(null))
                                .build()
                ).collect(Collectors.toList());
    }

    private <T> BankAccount.Agent from(T branchAndFinancialInstitutionIdentification) {
        return AccessorHelper.from(OrikaMapper.mapper()
                .map(branchAndFinancialInstitutionIdentification, BranchAndFinancialInstitutionIdentification6.class));
    }

    /**
     * Remittance information remittance information.
     *
     * @return the remittance information
     */
    @Override
    public RemittanceInformation remittanceInformation() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getRmtInf)
                .map(RemittanceInformation16::getStrds)
                .map(AccessorHelper.firstInList())
                .map(StructuredRemittanceInformation16::getAddtlRmtInves)
                .map(list -> {
                    if (list.size() < 2) {
                        return null;
                    }
                    if (isBlank(list.get(0)) && isBlank(list.get(1))) {
                        return null;
                    }
                    return RemittanceInformation.builder()
                            .reference(list.get(0))
                            .unstructured(list.get(1))
                            .build();
                }).orElse(null);
    }

    /**
     * Payment subtype string.
     *
     * @return the string
     */
    @Override
    public String paymentSubtype() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getPmtTpInf)
                .map(PaymentTypeInformation28::getCtgyPurp)
                .map(AccessorHelper::from)
                .orElse(null);
    }

    /**
     * Interbank settlement date local date.
     *
     * @return the local date
     */
    @Override
    public LocalDate interbankSettlementDate() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getIntrBkSttlmDt)
                .orElse(null);
    }

    /**
     * Regulatory reporting regulatory report.
     *
     * @return the regulatory report
     */
    @Override
    public RegulatoryReport regulatoryReporting() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getRgltryRptgs)
                .map(AccessorHelper.firstInList())
                .map(AccessorHelper::regulatoryReportingDetails)
                .orElse(null);
    }

    /**
     * Uetr string.
     *
     * @return the string
     */
    @Override
    public UUID uetr() {
        return UUID.fromString(pmtId()
                .map(PaymentIdentification7::getUETR)
                .orElse(""));
    }

    /**
     * Debtor agent ncc code string.
     *
     * @return the string
     */
    @Override
    public String debtorAgentNCCCode() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getDbtrAgt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getClrSysId)
                .map(ClearingSystemIdentification2Choice::getCd)
                .orElse(null);
    }

    /**
     * Creditor agent ncc code string.
     *
     * @return the string
     */
    @Override
    public String creditorAgentNCCCode() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getCdtrAgt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getClrSysId)
                .map(ClearingSystemIdentification2Choice::getCd)
                .orElse(null);
    }

    /**
     * Debtor agent member id string.
     *
     * @return the string
     */
    @Override
    public String debtorAgentMemberId() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getDbtrAgt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getMmbId)
                .orElse(null);
    }

    /**
     * Creditor agent member id string.
     *
     * @return the string
     */
    @Override
    public String creditorAgentMemberId() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getCdtrAgt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getMmbId)
                .orElse(null);
    }

    /**
     * Payment scheme string.
     *
     * @return the string
     */
    @Override
    public String paymentScheme() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getPmtTpInf)
                .map(PaymentTypeInformation28::getSvcLvls)
                .map(AccessorHelper.firstInList())
                .map(ServiceLevel8Choice::getPrtry)
                .orElse(null);
    }

    /**
     * Debtor references list.
     *
     * @return the list
     */
    @Override
    public List<String> debtorReferences() {
        return References.from(
                        firstTransaction()
                                .map(CreditTransferTransaction39::getRmtInf)
                                .map(RemittanceInformation16::getUstrds)
                                .orElse(emptyList()),
                        List.of(
                                ACCOUNTING_REFERENCE_LABEL,
                                ORIGINAL_MESSAGE_ID_LABEL))
                .findUnlabeled();
    }

    /**
     * Creditor references list.
     *
     * @return the list
     */
    @Override
    public List<String> creditorReferences() {
        List<StructuredRemittanceInformation16> structuredRemittanceInformation16s = firstTransaction()
                .map(CreditTransferTransaction39::getRmtInf)
                .map(RemittanceInformation16::getStrds)
                .orElse(emptyList());

        return structuredRemittanceInformation16s.stream()
                .map(rmtInf -> Optional.of(rmtInf)
                        .map(StructuredRemittanceInformation16::getCdtrRefInf)
                        .map(CreditorReferenceInformation2::getRef)
                        .orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toList());
    }

    /**
     * Exchange rate big decimal.
     *
     * @return the big decimal
     */
    @Override
    public BigDecimal exchangeRate() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getXchgRate)
                .orElse(null);
    }

    /**
     * Instructions for creditor agent list.
     *
     * @return the list
     */
    @Override
    public List<String> instructionsForCreditorAgent() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getInstrForCdtrAgts)
                .orElse(Collections.emptyList())
                .stream()
                .map(InstructionForCreditorAgent1::getInstrInf)
                .collect(Collectors.toList());
    }

    private Optional<CreditTransferTransaction39> firstTransaction() {
        return of(of(document)
                .map(Document::getFIToFICstmrCdtTrf)
                .map(FIToFICustomerCreditTransferV08::getCdtTrfTxInves)
                .orElse(List.of())
                .get(0));
    }

    private Optional<PaymentIdentification7> pmtId() {
        return firstTransaction()
                .map(CreditTransferTransaction39::getPmtId);
    }

    private Optional<BranchAndFinancialInstitutionIdentification6> getInstructingReimbursementAgent() {
        return of(document)
                .map(Document::getFIToFICstmrCdtTrf)
                .map(FIToFICustomerCreditTransferV08::getGrpHdr)
                .map(GroupHeader93::getSttlmInf)
                .map(SettlementInstruction7::getInstgRmbrsmntAgt);
    }

    private Optional<CashAccount38> getInstructingReimbursementAgentAccount() {
        return of(document)
                .map(Document::getFIToFICstmrCdtTrf)
                .map(FIToFICustomerCreditTransferV08::getGrpHdr)
                .map(GroupHeader93::getSttlmInf)
                .map(SettlementInstruction7::getInstgRmbrsmntAgtAcct);
    }
}
