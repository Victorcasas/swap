package com.santander.pagonxt.iso20022.messages.pacs.pacs008;

import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.accounts.OtherAccount;
import com.santander.pagonxt.iso20022.common.codes.ChargeBearer;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.fields.RegulatoryReport;
import com.santander.pagonxt.iso20022.common.paymentsubtype.PaymentSubtype;
import com.santander.pagonxt.iso20022.core.Iso20022MessageBuilder;
import com.santander.pagonxt.iso20022.common.helper.BuilderHelper;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ActiveCurrencyAndAmount;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ActiveOrHistoricCurrencyAndAmount;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.BranchAndFinancialInstitutionIdentification6;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CashAccount38;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CategoryPurpose1Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ChargeBearerType1Code;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CreditTransferTransaction39;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Document;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.FIToFICustomerCreditTransferV08;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.FinancialInstitutionIdentification18;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GroupHeader93;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PartyIdentification135;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PaymentIdentification7;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PaymentTypeInformation28;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.RegulatoryReporting3;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.RegulatoryReportingType1Code;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.RemittanceInformation16;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.SettlementInstruction7;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.SettlementMethod1Code;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.StructuredRegulatoryReporting3;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.StructuredRemittanceInformation16;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static java.util.Optional.of;
import static java.util.Optional.ofNullable;
import static org.codehaus.plexus.util.StringUtils.isBlank;

/**
 * The type Pacs 008 builder.
 */
public class Pacs008v08Builder extends Iso20022MessageBuilder<Document> {

    /**
     * Instantiates a new Pacs 008 builder.
     */
    public Pacs008v08Builder() {
        scaffoldDocument();
    }

    /**
     * Build document.
     *
     * @return the document
     */
    @Override
    public Pacs008v08Message build() {
        Pacs008v08Message pacs008v08Message = new Pacs008v08Message(document);
        pacs008v08Message.validateMessage();
        return pacs008v08Message;
    }

    /**
     * Message id pacs 008 builder.
     *
     * @param messageId the message id
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder messageId(String messageId) {
        if (isBlank(messageId)) {
            return this;
        }
        groupHeader().setMsgId(messageId);
        return this;
    }

    /**
     * End to end id pacs 008 builder.
     *
     * @param e2eId the e 2 e id
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder endToEndId(String e2eId) {
        if (isBlank(e2eId)) {
            return this;
        }
        pmtId().setEndToEndId(e2eId);
        pmtId().setTxId(e2eId);
        return this;
    }

    /**
     * Instruction id pacs 008 builder.
     *
     * @param instructionId the instruction id
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder instructionId(String instructionId) {
        if (isBlank(instructionId)) {
            return this;
        }
        pmtId().setInstrId(instructionId);
        return this;
    }

    /**
     * Amount pacs 008 builder.
     *
     * @param amount the amount
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder amount(MonetaryAmount amount) {
        if (amount == null) {
            return this;
        }
        final ActiveCurrencyAndAmount activeCurrencyAndAmount = new ActiveCurrencyAndAmount();
        activeCurrencyAndAmount.setCcy(amount.getCurrency().getCurrencyCode());
        activeCurrencyAndAmount.setValue(BigDecimal.valueOf(amount.getNumber().doubleValue()));
        firstTransaction().setIntrBkSttlmAmt(activeCurrencyAndAmount);
        return this;
    }

    /**
     * Debtor pacs 008 builder.
     *
     * @param partyIdentification the party identification
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder debtor(PartyIdentification partyIdentification) {
        if (partyIdentification == null) {
            return this;
        }
        firstTransaction().setDbtr(BuilderHelper.fillPartyIdentification(partyIdentification, PartyIdentification135.class));
        return this;
    }

    /**
     * Creditor pacs 008 builder.
     *
     * @param partyIdentification the party identification
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder creditor(PartyIdentification partyIdentification) {
        if (partyIdentification == null) {
            return this;
        }
        firstTransaction().setCdtr(BuilderHelper.fillPartyIdentification(partyIdentification, PartyIdentification135.class));
        return this;
    }

    /**
     * Debtor account pacs 008 builder.
     *
     * @param bankAccount the bank account
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder debtorAccount(BankAccount bankAccount) {
        if (bankAccount == null) {
            return this;
        }
        firstTransaction().setDbtrAgt(
                BuilderHelper.createFinancialInstitution(bankAccount.getAgent(),
                        BranchAndFinancialInstitutionIdentification6.class));
        firstTransaction().setDbtrAcct(BuilderHelper.createBankAccount(bankAccount, CashAccount38.class));
        return this;
    }

    /**
     * Creditor account pacs 008 builder.
     *
     * @param bankAccount the bank account
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder creditorAccount(BankAccount bankAccount) {
        if (bankAccount == null) {
            return this;
        }
        firstTransaction().setCdtrAgt(
                BuilderHelper.createFinancialInstitution(bankAccount.getAgent(),
                        BranchAndFinancialInstitutionIdentification6.class));
        firstTransaction().setCdtrAcct(BuilderHelper.createBankAccount(bankAccount, CashAccount38.class));
        return this;
    }

    /**
     * Instructed agent pacs 008 builder.
     *
     * @param instructedAgent the instructed agent
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder instructedAgent(BankAccount.Agent instructedAgent) {
        if (instructedAgent == null || instructedAgent.getBicfi() == null) {
            return this;
        }
        BankAccount account = withoutAccount(instructedAgent);
        firstTransaction().setInstdAgt(
                BuilderHelper.createFinancialInstitution(account.getAgent(),
                        BranchAndFinancialInstitutionIdentification6.class));
        return this;
    }

    /**
     * Instructing agent pacs 008 builder.
     *
     * @param instructingAgent the instructing agent
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder instructingAgent(BankAccount.Agent instructingAgent) {
        if (instructingAgent == null || instructingAgent.getBicfi() == null) {
            return this;
        }
        BankAccount account = withoutAccount(instructingAgent);
        firstTransaction().setInstgAgt(BuilderHelper.createFinancialInstitution(
                account.getAgent(),
                BranchAndFinancialInstitutionIdentification6.class));
        return this;
    }

    /**
     * Instructed reimbursement agent pacs 008 builder.
     *
     * @param agent the agent
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder instructedReimbursementAgent(BankAccount.Agent agent) {
        SettlementInstruction7 sttlmInf = groupHeader().getSttlmInf();
        sttlmInf.setInstdRmbrsmntAgt(BuilderHelper.createFinancialInstitution(
                agent,
                BranchAndFinancialInstitutionIdentification6.class));
        return this;
    }

    /**
     * Instructing reimbursement agent pacs 008 builder.
     *
     * @param agent the agent
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder instructingReimbursementAgent(BankAccount.Agent agent) {
        SettlementInstruction7 sttlmInf = groupHeader().getSttlmInf();
        sttlmInf.setInstgRmbrsmntAgt(BuilderHelper.createFinancialInstitution(
                agent,
                BranchAndFinancialInstitutionIdentification6.class));
        return this;
    }

    /**
     * Original amount pacs 008 builder.
     *
     * @param amount the amount
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder originalAmount(MonetaryAmount amount) {
        if (amount == null) {
            return this;
        }
        final ActiveOrHistoricCurrencyAndAmount activeOrHistoricCurrencyAndAmount =
                new ActiveOrHistoricCurrencyAndAmount();
        activeOrHistoricCurrencyAndAmount.setCcy(amount.getCurrency().getCurrencyCode());
        activeOrHistoricCurrencyAndAmount.setValue(BigDecimal.valueOf(amount.getNumber().doubleValue()));
        firstTransaction().setInstdAmt(activeOrHistoricCurrencyAndAmount);
        return this;
    }

    /**
     * Correspondent account pacs 008 builder.
     *
     * @param corresponsalAccount the corresponsal account
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder correspondentAccount(BankAccount corresponsalAccount) {
        if (corresponsalAccount == null) {
            return this;
        }
        firstTransaction().setIntrmyAgt1(
                BuilderHelper.createFinancialInstitution(corresponsalAccount.getAgent(),
                        BranchAndFinancialInstitutionIdentification6.class));
        firstTransaction().setIntrmyAgt1Acct(BuilderHelper.createBankAccount(corresponsalAccount, CashAccount38.class));
        return this;
    }

    /**
     * Charge bearer pacs 008 builder.
     *
     * @param chargeBearer the charge bearer
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder chargeBearer(ChargeBearer chargeBearer) {
        if (chargeBearer == null) {
            return this;
        }
        firstTransaction().setChrgBr(ChargeBearerType1Code.fromValue(chargeBearer.name()));
        return this;
    }

    /**
     * Remittance information pacs 008 builder.
     *
     * @param subject the subject
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder remittanceInformation(String subject) {
        if (isBlank(subject)) {
            return this;
        }
        final RemittanceInformation16 remittanceInformation16 = new RemittanceInformation16();
        final List<StructuredRemittanceInformation16> strd = remittanceInformation16.getStrds();
        final List<String> ustrd = remittanceInformation16.getUstrds();
        final StructuredRemittanceInformation16 structuredRemittanceInformation16 =
                new StructuredRemittanceInformation16();
        structuredRemittanceInformation16.getAddtlRmtInves().add(subject);
        strd.add(structuredRemittanceInformation16);
        ustrd.add(subject);
        firstTransaction().setRmtInf(remittanceInformation16);
        return this;
    }

    /**
     * Payment subtype pacs 008 builder.
     *
     * @param paymentSubtype the payment subtype
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder paymentSubtype(PaymentSubtype paymentSubtype) {
        if (paymentSubtype == null) {
            return this;
        }
        pmtTpInf().setCtgyPurp(BuilderHelper.fillPaymentSubtype(paymentSubtype, CategoryPurpose1Choice.class));
        return this;
    }

    /**
     * Interbank settlement date pacs 008 builder.
     *
     * @param settlementDate the settlement date
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder interbankSettlementDate(LocalDate settlementDate) {
        if (settlementDate == null) {
            return this;
        }
        firstTransaction().setIntrBkSttlmDt(settlementDate);
        return this;
    }

    /**
     * Regulatory reporting pacs 008 builder.
     *
     * @param regulatoryReport the regulatory report
     * @return the pacs 008 builder
     */
    @Override
    public Pacs008v08Builder regulatoryReporting(RegulatoryReport regulatoryReport) {
        if (regulatoryReport == null) {
            return this;
        }
        final RegulatoryReportingType1Code regulatoryReportingType1Code = ofNullable(regulatoryReport.getTypeCode())
                .map(code -> RegulatoryReportingType1Code.fromValue(code.name())).orElse(null);
        firstRgltryRptg().setDbtCdtRptgInd(regulatoryReportingType1Code);
        firstDtls().setCtry(regulatoryReport.getCountry());
        firstDtls().getInves().add(regulatoryReport.getNarrative());
        return this;
    }

    private void scaffoldDocument() {
        document = new Document();
        final FIToFICustomerCreditTransferV08 fiToFICustomerCreditTransfer = new FIToFICustomerCreditTransferV08();
        final GroupHeader93 groupHeader = new GroupHeader93();
        final SettlementInstruction7 settlementInstruction = new SettlementInstruction7();
        final List<CreditTransferTransaction39> cdtTrfTxInf = fiToFICustomerCreditTransfer.getCdtTrfTxInves();
        final CreditTransferTransaction39 creditTransferTransaction = new CreditTransferTransaction39();

        fiToFICustomerCreditTransfer.setGrpHdr(groupHeader);
        document.setFIToFICstmrCdtTrf(fiToFICustomerCreditTransfer);

        groupHeader.setCreDtTm(LocalDateTime.now());
        groupHeader.setNbOfTxs("1");
        settlementInstruction.setSttlmMtd(SettlementMethod1Code.CLRG);
        groupHeader.setSttlmInf(settlementInstruction);

        final BranchAndFinancialInstitutionIdentification6 dbtrAgt =
                new BranchAndFinancialInstitutionIdentification6();
        final BranchAndFinancialInstitutionIdentification6 cdtrAgt =
                new BranchAndFinancialInstitutionIdentification6();
        final FinancialInstitutionIdentification18 finInstnId = new FinancialInstitutionIdentification18();

        dbtrAgt.setFinInstnId(finInstnId);
        creditTransferTransaction.setDbtrAgt(dbtrAgt);
        cdtrAgt.setFinInstnId(finInstnId);
        creditTransferTransaction.setCdtrAgt(cdtrAgt);

        creditTransferTransaction.setChrgBr(ChargeBearerType1Code.SHAR);
        cdtTrfTxInf.add(creditTransferTransaction);
    }

    private GroupHeader93 groupHeader() {
        return document.getFIToFICstmrCdtTrf().getGrpHdr();
    }

    private PaymentIdentification7 pmtId() {
        final PaymentIdentification7 paymentIdentification7 = of(firstTransaction())
                .map(CreditTransferTransaction39::getPmtId)
                .orElse(new PaymentIdentification7());
        firstTransaction().setPmtId(paymentIdentification7);
        return paymentIdentification7;
    }

    private PaymentTypeInformation28 pmtTpInf() {
        PaymentTypeInformation28 paymentTypeInformation = of(firstTransaction())
                .map(CreditTransferTransaction39::getPmtTpInf)
                .orElse(new PaymentTypeInformation28());
        firstTransaction().setPmtTpInf(paymentTypeInformation);
        return paymentTypeInformation;
    }

    private CreditTransferTransaction39 firstTransaction() {
        return document.getFIToFICstmrCdtTrf().getCdtTrfTxInves().get(0);
    }

    private BankAccount withoutAccount(BankAccount.Agent agent) {
        return OtherAccount.builder()
                .bicfi(ofNullable(agent.getBicfi())
                        .orElse(null))
                .agentMemberId(agent.getMemberId())
                .agentType(agent.getType())
                .build();
    }

    private RegulatoryReporting3 firstRgltryRptg() {
        List<RegulatoryReporting3> regulatoryReporting3List = firstTransaction().getRgltryRptgs();
        if (regulatoryReporting3List.isEmpty()) {
            regulatoryReporting3List.add(new RegulatoryReporting3());
        }
        return regulatoryReporting3List.get(0);
    }

    private StructuredRegulatoryReporting3 firstDtls() {
        List<StructuredRegulatoryReporting3> strRegReporting3List = firstRgltryRptg().getDtls();
        if (strRegReporting3List.isEmpty()) {
            strRegReporting3List.add(new StructuredRegulatoryReporting3());
        }
        return strRegReporting3List.get(0);
    }
}
