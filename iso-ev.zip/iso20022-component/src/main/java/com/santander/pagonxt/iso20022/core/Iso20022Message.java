package com.santander.pagonxt.iso20022.core;

public abstract class Iso20022Message<DOCUMENT> {

    protected static final String DEFINITION_PATH = "/model/messages/pacs/%s.xsd";

    protected final DOCUMENT document;

    protected Iso20022Message(DOCUMENT document) {
        this.document = document;
    }

    public DOCUMENT document() {
        return document;
    }

    public abstract Iso20022MessageAccessor<DOCUMENT> getAccessor();

    public abstract void validateMessage();
}
