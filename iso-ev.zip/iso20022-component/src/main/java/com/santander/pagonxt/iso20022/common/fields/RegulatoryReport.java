package com.santander.pagonxt.iso20022.common.fields;

import lombok.Builder;
import lombok.Data;

/**
 * The type Regulatory report.
 */
@Data
@Builder
public class RegulatoryReport {

    private final RegulatoryReportingTypeCode typeCode;
    private final String country;
    private final String narrative;
}
