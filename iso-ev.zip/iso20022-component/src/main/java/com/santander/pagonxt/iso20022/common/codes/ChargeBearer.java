package com.santander.pagonxt.iso20022.common.codes;

import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ChargeBearerType1Code;

/**
 * The enum Charge bearer.
 */
public enum ChargeBearer {
    /**
     * Debt charge bearer.
     */
    DEBT,
    /**
     * Cred charge bearer.
     */
    CRED,
    /**
     * Shar charge bearer.
     */
    SHAR,
    /**
     * Slev charge bearer.
     */
    SLEV;

    /**
     * From charge bearer.
     *
     * @param chargeBearerType1Code the charge bearer type 1 code
     * @return the charge bearer
     */
    public static ChargeBearer from(ChargeBearerType1Code chargeBearerType1Code) {
        return valueOf(chargeBearerType1Code.value());
    }
}
