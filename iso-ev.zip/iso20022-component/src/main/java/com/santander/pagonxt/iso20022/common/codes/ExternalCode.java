package com.santander.pagonxt.iso20022.common.codes;

/**
 * Represents the ISO20022 codes that were externalized from message Schemas.
 *
 * @see <a href="https://www.iso20022.org/catalogue-messages/additional-content-messages/external-code-sets">External Code Sets</a>
 */
public interface ExternalCode {
    /**
     * Returns whether the implementation is proprietary or not.
     *
     * @return <code>true</code> if the implementation is proprietary; false otherwise
     */
    default boolean isProprietary() {
        return false;
    }

    /**
     * The code. Usually 4 characters long.
     *
     * @return the string
     */
    String code();

    /**
     * Identifier string.
     *
     * @return the string
     */
    String identifier();

    /**
     * Definition string.
     *
     * @return the string
     */
    String definition();
}
