package com.santander.pagonxt.iso20022.common.paymentsubtype;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.Value;

/**
 * The type Proprietary.
 */
@Value
@Builder
@EqualsAndHashCode(callSuper = false)
public class Proprietary implements PaymentSubtype {

    @NonNull String value;

    @Override
    public String value() {
        return value;
    }
}
