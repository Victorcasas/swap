package com.santander.pagonxt.iso20022.common.helper;


import com.santander.pagonxt.iso20022.common.accounts.BankAccount.Agent;
import com.santander.pagonxt.iso20022.mapper.OrikaMapper;
import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.accounts.CreditCard;
import com.santander.pagonxt.iso20022.common.accounts.LoanAccount;
import com.santander.pagonxt.iso20022.common.accounts.PartenonContract;
import com.santander.pagonxt.iso20022.common.accounts.SavingsAccount;
import com.santander.pagonxt.iso20022.common.fields.ChoiceField;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GenericFinancialIdentification1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GenericOrganisationIdentification1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GenericPersonIdentification1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Party38Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PartyIdentification135;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PersonIdentification13;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.PostalAddress24;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.RegulatoryReporting3;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.StructuredRegulatoryReporting3;
import com.santander.pagonxt.iso20022.common.accounts.IbanAccount;
import com.santander.pagonxt.iso20022.common.accounts.OtherAccount;
import com.santander.pagonxt.iso20022.common.accounts.SortcodeAccountNumber;
import com.santander.pagonxt.iso20022.common.codes.ExternalCode;
import com.santander.pagonxt.iso20022.common.codes.Proprietary;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification.Address;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification.Person;
import com.santander.pagonxt.iso20022.common.fields.RegulatoryReport;
import com.santander.pagonxt.iso20022.common.fields.RegulatoryReportingTypeCode;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.AccountIdentification4Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.BranchAndFinancialInstitutionIdentification6;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CashAccount38;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CashAccountType2Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ClearingSystemMemberIdentification2;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.FinancialInstitutionIdentification18;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.GenericAccountIdentification1;
import org.codehaus.plexus.util.StringUtils;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

import static com.santander.pagonxt.iso20022.common.accounts.IsoCode.Codes.LOAN;
import static com.santander.pagonxt.iso20022.common.accounts.IsoCode.Codes.SVGS;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;
import static org.codehaus.plexus.util.StringUtils.isNotBlank;

/**
 * Helper to access common pacs objects among every pacs. First the object is converted into pacs008 object,
 * then the required field is accessed.
 */
public final class AccessorHelper {

    private AccessorHelper() {
    }

    /**
     * Regulatory report regulatory report.
     *
     * @param regulatoryReporting the regulatory reporting
     * @return the regulatory report
     */
    public static RegulatoryReport regulatoryReport(RegulatoryReporting3 regulatoryReporting) {
        return regulatoryReportingDetails(OrikaMapper.mapper().map(regulatoryReporting, RegulatoryReporting3.class));
    }

    /**
     * Tpp id string.
     *
     * @param regulatoryReporting the regulatory reporting
     * @return the string
     */
    public static String tppId(RegulatoryReporting3 regulatoryReporting) {
        return ofNullable(regulatoryReporting)
                .map(RegulatoryReporting3::getDtls)
                .map(firstInList())
                .map(StructuredRegulatoryReporting3::getInves)
                .flatMap(strings -> strings.stream().reduce(String::concat))
                .orElse(null);
    }

    /**
     * Regulatory reporting details regulatory report.
     *
     * @param regulatoryReporting the regulatory reporting
     * @return the regulatory report
     */
    public static RegulatoryReport regulatoryReportingDetails(RegulatoryReporting3 regulatoryReporting) {

        RegulatoryReport.RegulatoryReportBuilder reportBuilder = RegulatoryReport.builder();

        final RegulatoryReportingTypeCode regulatoryReportingTypeCode =
                ofNullable(regulatoryReporting.getDbtCdtRptgInd())
                .map(code -> RegulatoryReportingTypeCode.fromValue(code.name()))
                .orElse(null);
        reportBuilder.typeCode(regulatoryReportingTypeCode);

        reportBuilder.narrative(tppId(regulatoryReporting));

        reportBuilder.country(of(regulatoryReporting)
                .map(RegulatoryReporting3::getDtls)
                .map(firstInList())
                .map(StructuredRegulatoryReporting3::getCtry).orElse(null));

        return reportBuilder.build();
    }

    public static <T> Agent agentFrom(T branchAndFinancialInstitutionIdentification) {
        return from(OrikaMapper.mapper().map(branchAndFinancialInstitutionIdentification, BranchAndFinancialInstitutionIdentification6.class));
    }

    public static Agent from(BranchAndFinancialInstitutionIdentification6 agt) {
        if (agt == null) return null;
        final Agent.AgentBuilder builder = Agent.builder();
        fetchOtherAgentId(agt).ifPresent(builder::otherId);
        fetchAgentName(agt).ifPresent(builder::name);
        fetchAddress(agt).ifPresent(builder::address);
        fetchBICFI(agt).ifPresent(builder::bicfi);
        fetchSortCode(agt).ifPresent(builder::memberId);
        fetchAgentType(agt).ifPresent(builder::type);
        return builder.build();
    }

    public static BankAccount.Agent fromAgent(com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.BranchAndFinancialInstitutionIdentification6 institutionIdentification) {
        return from(OrikaMapper.mapper().map(institutionIdentification, BranchAndFinancialInstitutionIdentification6.class));
    }

    /**
     * From party identification.
     *
     * @param partyIdentification the party identification
     * @return the party identification
     */
    public static PartyIdentification from(PartyIdentification135 partyIdentification) {
        if (partyIdentification == null) {
            return null;
        }

        final PartyIdentification.PartyType partyType;
        if (isPersonIdentification(partyIdentification)) {
            partyType = ofNullable(partyIdentification.getId())
                    .map(Party38Choice::getPrvtId)
                    .map(PersonIdentification13::getOthrs)
                    .map(firstInList())
                    .map(GenericPersonIdentification1::getId)
                    .map(id -> Person.builder()
                            .otherId(id)
                            .build())
                    .orElse(null);

        } else if (isOrganizationIdentification(partyIdentification)) {
            partyType = ofNullable(partyIdentification.getId())
                    .map(Party38Choice::getOrgId)
                    .map(orgId -> {
                        String id = ofNullable(orgId.getOthrs())
                                .map(firstInList())
                                .map(GenericOrganisationIdentification1::getId)
                                .orElse(null);
                        String issr = ofNullable(orgId.getOthrs())
                                .map(firstInList())
                                .map(GenericOrganisationIdentification1::getIssr)
                                .orElse(null);
                        return PartyIdentification.Organisation.builder()
                                .otherId(id)
                                .otherIssuer(issr)
                                .bic(orgId.getAnyBIC())
                                .build();
                    })
                    .orElse(null);

        } else {
            partyType = null;
        }

        return of(partyIdentification)
                .map(partyIdentification125 -> PartyIdentification
                        .builder()
                        .name(partyIdentification125.getNm())
                        .address(fromAddress(partyIdentification))
                        .partyType(partyType)
                        .build())
                .orElse(null);
    }


    private static boolean isPersonIdentification(PartyIdentification135 partyIdentification) {
        return ofNullable(partyIdentification.getId()).isPresent() &&
                ofNullable(partyIdentification.getId().getPrvtId()).isPresent();
    }

    private static boolean isOrganizationIdentification(PartyIdentification135 partyIdentification) {
        return ofNullable(partyIdentification.getId()).isPresent() &&
                ofNullable(partyIdentification.getId().getOrgId()).isPresent();
    }

    /**
     * From bank account.
     *
     * @param agt the agt
     * @param acc the acc
     * @return the bank account
     */
    public static BankAccount from(BranchAndFinancialInstitutionIdentification6 agt,
                                   CashAccount38 acc) {
        if (Objects.isNull(acc) && Objects.nonNull(agt)) {
            return asDefaultAccountWithNoAccount(agt);
        }

        if (isIban(acc)) {
            return asIban(agt, acc);
        }

        if (isAccountTypeProvided(acc)) {
            return asLocalAccount(agt, acc);
        }

        if (isSortCodeAccountNumber(agt, acc)) {
            return asSortCodeAccountNumber(agt, acc);
        }

        if (isLocalAccount(agt, acc)) {
            return asLocalAccount(agt, acc);
        }

        return null;
    }

    public static BankAccount from(final com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.BranchAndFinancialInstitutionIdentification6 agt,
                                   final com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.CashAccount38 acc) {
        return from(
                OrikaMapper.mapper().map(agt, BranchAndFinancialInstitutionIdentification6.class),
                OrikaMapper.mapper().map(acc, CashAccount38.class)
        );
    }

    public static PartyIdentification from(com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PartyIdentification135 party) {
        return from(OrikaMapper.mapper().map(party, PartyIdentification135.class));
    }

    private static BankAccount asDefaultAccountWithNoAccount(BranchAndFinancialInstitutionIdentification6 agt) {
        final String agentType = fetchAgentType(agt).orElse(null);
        final String agentMemberId = fetchAgentMemberId(agt).orElse(null);
        final Address address = fetchAddress(agt).orElse(null);
        final String bic = fetchBICFI(agt).orElse(null);
        final String otherAgentName = fetchAgentName(agt).orElse(null);
        final String otherAgentId = fetchOtherAgentId(agt).orElse(null);

        return OtherAccount.builder()
                .agentType(agentType)
                .agentMemberId(agentMemberId)
                .address(address)
                .bicfi(bic)
                .agentName(otherAgentName)
                .otherAgentId(otherAgentId)
                .build();
    }

    private static Address fromAddress(PartyIdentification135 partyIdentification) {
        return ofNullable(partyIdentification)
                .map(PartyIdentification135::getPstlAdr)
                .map(AccessorHelper::fromAddress)
                .orElse(null);
    }

    /**
     * From address address.
     *
     * @param pstlAddress the pstl address
     * @return the address
     */
    static Address fromAddress(PostalAddress24 pstlAddress) {
        return ofNullable(pstlAddress)
                .map(postalAddress6 -> Address.builder()
                        .addressLine(postalAddress6.getAdrLines())
                        .town(postalAddress6.getTwnNm())
                        .postCode(postalAddress6.getPstCd())
                        .streetName(postalAddress6.getStrtNm())
                        .country(ofNullable(postalAddress6.getCtry()).orElse(null))
                        .build()
                ).orElse(null);
    }

    /**
     * From string.
     *
     * @param <T>    the type parameter
     * @param choice the choice
     * @return the string
     */
    public static <T> String from(T choice) {
        if (choice == null){
            return null;
        }
        return from(OrikaMapper.mapper().map(choice, ChoiceField.class));
    }

    private static String from(ChoiceField choiceField) {
        return of(choiceField)
                .map(cf -> {
                    final String cd = cf.getCd();
                    final String prtry = cf.getPrtry();
                    if (isNotBlank(cd)) {
                        return cd;
                    } else if (isNotBlank(prtry)) {
                        return prtry;
                    }
                    return null;

                })
                .orElse(null);
    }

    /**
     * External code external code.
     *
     * @param <C>          the type parameter
     * @param <T>          the type parameter
     * @param choice       the choice
     * @param externalCode the external code
     * @return the external code
     */
    public static <C, T extends Enum<T>> ExternalCode externalCode(C choice, Class<T> externalCode) {
        if (choice == null) {
            return null;
        }

        ChoiceField choiceField = OrikaMapper.mapper().map(choice, ChoiceField.class);

        if (of(choiceField).map(ChoiceField::getCd).isPresent()) {
            return (ExternalCode) Enum.valueOf(externalCode,
                    of(choiceField)
                            .map(ChoiceField::getCd)
                            .orElseThrow()
            );
        } else {
            return Proprietary.builder().code(
                    of(choiceField)
                            .map(ChoiceField::getPrtry)
                            .orElse(null)
            ).build();
        }
    }

    /**
     * Choice to string string.
     *
     * @param <C>    the type parameter
     * @param choice the choice
     * @return the string
     */
    public static <C> String choiceToString(C choice) {
        if (choice == null) {
            return null;
        }

        ChoiceField choiceField = OrikaMapper.mapper().map(choice, ChoiceField.class);

        return of(choiceField)
                .map(ChoiceField::getCd)
                .orElseGet(() ->
                        of(choiceField)
                                .map(ChoiceField::getPrtry)
                                .orElse(null)
                );
    }

    /**
     * First in list function.
     *
     * @param <T> the type parameter
     * @return the function
     */
    public static <T> Function<List<T>, T> firstInList() {
        return list -> list.isEmpty() ? null : list.get(0);
    }

    private static boolean isIban(CashAccount38 acc) {
        return fetchIBAN(acc).isPresent();
    }

    private static boolean isSortCodeAccountNumber(BranchAndFinancialInstitutionIdentification6 agt,
                                                   CashAccount38 acc) {
        return fetchSortCode(agt).isPresent()
                &&
                fetchOtherAccount(acc).isPresent();
    }

    private static boolean isLocalAccount(BranchAndFinancialInstitutionIdentification6 agt,
                                          CashAccount38 acc) {
        return fetchOtherAccount(acc).isPresent()
                ||
                fetchOtherAgentId(agt).isPresent();
    }

    private static Optional<String> fetchIBAN(CashAccount38 acc) {
        return ofNullable(acc)
                .map(CashAccount38::getId)
                .map(AccountIdentification4Choice::getIBAN);
    }

    private static Optional<String> fetchAccountName(CashAccount38 acc) {
        return ofNullable(acc)
                .map(CashAccount38::getNm);
    }

    private static Optional<String> fetchAccountCurrency(CashAccount38 acc) {
        return ofNullable(acc)
                .map(CashAccount38::getCcy)
                .filter(StringUtils::isNotBlank);
    }

    private static Optional<String> fetchSortCode(BranchAndFinancialInstitutionIdentification6 agt) {
        return ofNullable(agt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getMmbId)
                .filter(StringUtils::isNotBlank);
    }

    private static Optional<String> fetchOtherAccount(CashAccount38 acc) {
        return ofNullable(acc)
                .map(CashAccount38::getId)
                .map(AccountIdentification4Choice::getOthr)
                .map(GenericAccountIdentification1::getId)
                .filter(StringUtils::isNotBlank);
    }

    private static Optional<String> fetchOtherAgentId(BranchAndFinancialInstitutionIdentification6 agt) {
        return ofNullable(agt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getOthr)
                .map(GenericFinancialIdentification1::getId);
    }

    private static Optional<String> fetchAgentMemberId(BranchAndFinancialInstitutionIdentification6 agt) {
        return ofNullable(agt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getMmbId);
    }

    private static boolean isAccountTypeProvided(CashAccount38 acc) {
        return ofNullable(acc)
                .map(CashAccount38::getTp)
                .map(cashAccountType2Choice -> {
                    final ChoiceField choiceField = new ChoiceField();
                    choiceField.setCd(cashAccountType2Choice.getCd());
                    choiceField.setPrtry(cashAccountType2Choice.getPrtry());
                    return choiceField;
                })
                .map(ChoiceField::isPopulated)
                .orElse(Boolean.FALSE);
    }

    private static BankAccount asIban(BranchAndFinancialInstitutionIdentification6 agt,
                                      CashAccount38 acc) {
        final IbanAccount.IbanAccountBuilder builder = IbanAccount.builder();

        fetchIBAN(acc).ifPresent(builder::iban);

        fetchBICFI(agt).ifPresent(builder::bicfi);
        fetchOtherAgentId(agt).ifPresent(builder::otherAgentId);
        fetchAgentName(agt).ifPresent(builder::agentName);
        fetchAddress(agt).ifPresent(builder::address);
        fetchAgentType(agt).ifPresent(builder::agentType);

        fetchAccountName(acc).ifPresent(builder::accountName);
        fetchAccountCurrency(acc).ifPresent(builder::currency);

        return builder.build();
    }

    private static BankAccount asSortCodeAccountNumber(BranchAndFinancialInstitutionIdentification6 agt,
                                                       CashAccount38 acc) {
        final SortcodeAccountNumber.SortcodeAccountNumberBuilder builder = SortcodeAccountNumber.builder();

        fetchSortCode(agt).ifPresent(builder::sortcode);
        fetchOtherAccount(acc).ifPresent(builder::accountNumber);
        fetchAgentType(agt).ifPresent(builder::agentType);

        fetchBICFI(agt).ifPresent(builder::bicfi);
        fetchOtherAgentId(agt).ifPresent(builder::otherAgentId);
        fetchAgentName(agt).ifPresent(builder::agentName);
        fetchAddress(agt).ifPresent(builder::address);

        fetchAccountName(acc).ifPresent(builder::accountName);
        fetchAccountCurrency(acc).ifPresent(builder::currency);

        return builder.build();
    }

    private static BankAccount asLocalAccount(BranchAndFinancialInstitutionIdentification6 agt,
                                              CashAccount38 acc) {
        final String otherAccountId = fetchOtherAccount(acc).orElse(null);
        final String bic = fetchBICFI(agt).orElse(null);
        final String otherAgentId = fetchOtherAgentId(agt).orElse(null);
        final String otherAgentName = fetchAgentName(agt).orElse(null);
        final Address address = fetchAddress(agt).orElse(null);
        final String accountName = fetchAccountName(acc).orElse(null);
        final String currency = fetchAccountCurrency(acc).orElse(null);
        final String agentType = fetchAgentType(agt).orElse(null);
        final CashAccountType2Choice tp = Optional.ofNullable(acc).map(CashAccount38::getTp).orElse(null);
        if (tp != null && (SVGS.toString().equals(tp.getCd()) || SavingsAccount.PARTENON_CODE.equals(tp.getPrtry()))) {
            return SavingsAccount.builder()
                    .account(otherAccountId)
                    .accountName(accountName)
                    .address(address)
                    .bicfi(bic)
                    .agentName(otherAgentName)
                    .otherAgentId(otherAgentId)
                    .currency(currency)
                    .agentType(agentType)
                    .build();
        } else if (tp != null && (LOAN.toString().equals(tp.getCd()))) {
            return LoanAccount.builder()
                    .account(otherAccountId)
                    .accountName(accountName)
                    .address(address)
                    .bicfi(bic)
                    .agentName(otherAgentName)
                    .otherAgentId(otherAgentId)
                    .currency(currency)
                    .agentType(agentType)
                    .build();

        } else if (tp != null && (CreditCard.PARTENON_CODE.equals(tp.getPrtry()))) {
            return CreditCard.builder()
                    .account(otherAccountId)
                    .accountName(accountName)
                    .address(address)
                    .bicfi(bic)
                    .agentName(otherAgentName)
                    .otherAgentId(otherAgentId)
                    .currency(currency)
                    .agentType(agentType)
                    .build();

        } else if (tp != null && (PartenonContract.PARTENON_CODE.equals(tp.getPrtry()))) {
            return PartenonContract.builder()
                    .account(otherAccountId)
                    .accountName(accountName)
                    .address(address)
                    .bicfi(bic)
                    .agentName(otherAgentName)
                    .otherAgentId(otherAgentId)
                    .currency(currency)
                    .agentType(agentType)
                    .build();

        } else if (tp != null && (SortcodeAccountNumber.PARTENON_CODE.equals(tp.getPrtry()))) {
            return asSortCodeAccountNumber(agt, acc);

        }
        return OtherAccount.builder()
                .account(otherAccountId)
                .accountName(accountName)
                .address(address)
                .bicfi(bic)
                .agentName(otherAgentName)
                .otherAgentId(otherAgentId)
                .currency(currency)
                .agentType(agentType)
                .build();
    }

    private static Optional<String> fetchBICFI(BranchAndFinancialInstitutionIdentification6 agt) {
        return ofNullable(agt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getBICFI)
                .filter(StringUtils::isNotBlank);
    }

    private static Optional<String> fetchAgentName(BranchAndFinancialInstitutionIdentification6 agt) {
        return ofNullable(agt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getNm);
    }

    private static Optional<String> fetchAgentType(BranchAndFinancialInstitutionIdentification6 agt) {
        return ofNullable(agt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getClrSysMmbId)
                .map(ClearingSystemMemberIdentification2::getClrSysId)
                .map(AccessorHelper::choiceToString);
    }

    private static Optional<Address> fetchAddress(
            BranchAndFinancialInstitutionIdentification6 agt) {
        return ofNullable(agt)
                .map(BranchAndFinancialInstitutionIdentification6::getFinInstnId)
                .map(FinancialInstitutionIdentification18::getPstlAdr)
                .map(AccessorHelper::fromAddress);
    }
}
