package com.santander.pagonxt.iso20022.core;

import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.codes.ChargeBearer;
import com.santander.pagonxt.iso20022.common.fields.CustomCharges;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.fields.Priority;
import com.santander.pagonxt.iso20022.common.fields.ReasonInfo;
import com.santander.pagonxt.iso20022.common.fields.RegulatoryReport;
import com.santander.pagonxt.iso20022.common.fields.RemittanceInformation;
import com.santander.pagonxt.iso20022.common.fields.Remittance;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

/**
 * The type Iso 20022 message accessor.
 *
 * @param <DOCUMENT> the type parameter
 */
public abstract class Iso20022MessageAccessor<DOCUMENT> {

    /**
     * The Document.
     */
    protected DOCUMENT document;

    /**
     * Message id string.
     *
     * @return the string
     */
    public String messageId() {
        return null;
    }

    /**
     * Instruction priority priority.
     *
     * @return the priority
     */
    public Priority instructionPriority() {
        return null;
    }

    /**
     * Transaction id string.
     *
     * @return the string
     */
    public String transactionId() {
        return null;
    }

    /**
     * Transaction reference string.
     *
     * @return the string
     */
    public String transactionReference() {
        return null;
    }

    /**
     * End to end id string.
     *
     * @return the string
     */
    public String endToEndId() {
        return null;
    }

    /**
     * Instruction id string.
     *
     * @return the string
     */
    public String instructionId() {
        return null;
    }

    /**
     * Scheme id string.
     *
     * @return the string
     */
    public String schemeId() {
        return null;
    }

    /**
     * Payment sub type string.
     *
     * @return the string
     */
    public String paymentSubType() {
        return null;
    }

    /**
     * Payment code string.
     *
     * @return the string
     */
    public String paymentCode() {
        return null;
    }

    /**
     * Amount monetary amount.
     *
     * @return the monetary amount
     */
    public MonetaryAmount amount() {
        return null;
    }

    /**
     * Inter bank sttlm date local date.
     *
     * @return the local date
     */
    public LocalDate interBankSttlmDate() {
        return null;
    }

    /**
     * Original tx international bank settlement date local date.
     *
     * @return the local date
     */
    public LocalDate originalTxInternationalBankSettlementDate() {
        return null;
    }

    /**
     * Xchg rate big decimal.
     *
     * @return the big decimal
     */
    public BigDecimal xchgRate() {
        return null;
    }

    /**
     * Compensation amount monetary amount.
     *
     * @return the monetary amount
     */
    public MonetaryAmount compensationAmount() {
        return null;
    }

    /**
     * Ultimate debtor party identification.
     *
     * @return the party identification
     */
    public PartyIdentification ultimateDebtor() {
        return null;
    }

    /**
     * Debtor party identification.
     *
     * @return the party identification
     */
    public PartyIdentification debtor() {
        return null;
    }

    /**
     * Debtor party party identification.
     *
     * @return the party identification
     */
    public PartyIdentification debtorParty() {
        return null;
    }

    /**
     * Debtor agent bank account . agent.
     *
     * @return the bank account . agent
     */
    public BankAccount.Agent debtorAgent() {
        return null;
    }

    /**
     * Ultimate creditor party identification.
     *
     * @return the party identification
     */
    public PartyIdentification ultimateCreditor() {
        return null;
    }

    /**
     * Creditor party identification.
     *
     * @return the party identification
     */
    public PartyIdentification creditor() {
        return null;
    }

    /**
     * Debtor account bank account.
     *
     * @return the bank account
     */
    public BankAccount debtorAccount() {
        return null;
    }

    /**
     * Creditor account bank account.
     *
     * @return the bank account
     */
    public BankAccount creditorAccount() {
        return null;
    }

    /**
     * Instructed agent bank account . agent.
     *
     * @return the bank account . agent
     */
    public BankAccount.Agent instructedAgent() {
        return null;
    }

    /**
     * Instructing agent bank account . agent.
     *
     * @return the bank account . agent
     */
    public BankAccount.Agent instructingAgent() {
        return null;
    }

    /**
     * Instructed reimbursement agent bank account . agent.
     *
     * @return the bank account . agent
     */
    public BankAccount.Agent instructedReimbursementAgent() {
        return null;
    }

    /**
     * Instructing reimbursement agent bank account . agent.
     *
     * @return the bank account . agent
     */
    public BankAccount.Agent instructingReimbursementAgent() {
        return null;
    }

    /**
     * Instructing reimbursement agent ncc string.
     *
     * @return the string
     */
    public String instructingReimbursementAgentNCC() {
        return null;
    }

    /**
     * Instructing reimbursement agent member id string.
     *
     * @return the string
     */
    public String instructingReimbursementAgentMemberId() {
        return null;
    }

    /**
     * Instructing reimbursement agent identification string.
     *
     * @return the string
     */
    public String instructingReimbursementAgentIdentification() {
        return null;
    }

    /**
     * Instructed reimbursement agent ncc string.
     *
     * @return the string
     */
    public String instructedReimbursementAgentNCC() {
        return null;
    }

    /**
     * Instructed reimbursement agent member id string.
     *
     * @return the string
     */
    public String instructedReimbursementAgentMemberId() {
        return null;
    }

    /**
     * Instructed reimbursement agent identification string.
     *
     * @return the string
     */
    public String instructedReimbursementAgentIdentification() {
        return null;
    }

    /**
     * Clearing system string.
     *
     * @return the string
     */
    public String clearingSystem() {
        return null;
    }

    /**
     * Original amount monetary amount.
     *
     * @return the monetary amount
     */
    public MonetaryAmount originalAmount() {
        return null;
    }

    /**
     * Instructions for next agent list.
     *
     * @return the list
     */
    public List<String> instructionsForNextAgent() {
        return List.of();
    }

    /**
     * Correspondent account bank account.
     *
     * @return the bank account
     */
    public BankAccount correspondentAccount() {
        return null;
    }

    /**
     * Intermediary agent ncc code string.
     *
     * @return the string
     */
    public String intermediaryAgentNCCCode() {
        return null;
    }

    /**
     * Debtor agent account bank account.
     *
     * @return the bank account
     */
    public BankAccount debtorAgentAccount() {
        return null;
    }

    /**
     * Creditor agent account bank account.
     *
     * @return the bank account
     */
    public BankAccount creditorAgentAccount() {
        return null;
    }

    /**
     * Charge bearer charge bearer.
     *
     * @return the charge bearer
     */
    public ChargeBearer chargeBearer() {
        return null;
    }

    /**
     * Gets expenses type.
     *
     * @return the expenses type
     */
    public String getExpensesType() {
        return null;
    }

    /**
     * Gets charges info.
     *
     * @return the charges info
     */
    public List<CustomCharges> getChargesInfo() {
        return List.of();
    }

    /**
     * Original transaction id string.
     *
     * @return the string
     */
    public String originalTransactionId() {
        return null;
    }

    /**
     * Original message id string.
     *
     * @return the string
     */
    public String originalMessageId() {
        return null;
    }

    /**
     * Original message name string.
     *
     * @return the string
     */
    public String originalMessageName() {
        return null;
    }

    /**
     * Requested collection date local date.
     *
     * @return the local date
     */
    public LocalDate requestedCollectionDate() {
        return null;
    }

    /**
     * Tpp id string.
     *
     * @return the string
     */
    public String tppId() {
        return null;
    }

    /**
     * Remittance information remittance information.
     *
     * @return the remittance information
     */
    public RemittanceInformation remittanceInformation() {
        return null;
    }

    /**
     * Payment subtype string.
     *
     * @return the string
     */
    public String paymentSubtype() {
        return null;
    }

    /**
     * Interbank settlement date local date.
     *
     * @return the local date
     */
    public LocalDate interbankSettlementDate() {
        return null;
    }

    /**
     * Regulatory reporting regulatory report.
     *
     * @return the regulatory report
     */
    public RegulatoryReport regulatoryReporting() {
        return null;
    }

    /**
     * Uetr string.
     *
     * @return the string
     */
    public UUID uetr() {
        return null;
    }


    /**
     * Debtor agent ncc code string.
     *
     * @return the string
     */
    public String debtorAgentNCCCode() {
        return null;
    };

    /**
     * Creditor agent ncc code string.
     *
     * @return the string
     */
    public String creditorAgentNCCCode() {
        return null;
    }

    /**
     * Debtor agent member id string.
     *
     * @return the string
     */
    public String debtorAgentMemberId() {
        return null;
    }

    /**
     * Creditor agent member id string.
     *
     * @return the string
     */
    public String creditorAgentMemberId() {
        return null;
    }

    /**
     * Payment scheme string.
     *
     * @return the string
     */
    public String paymentScheme() {
        return null;
    }

    /**
     * Debtor references list.
     *
     * @return the list
     */
    public List<String> debtorReferences() {
        return List.of();
    }

    /**
     * Creditor references list.
     *
     * @return the list
     */
    public List<String> creditorReferences() {
        return List.of();
    }

    /**
     * Exchange rate big decimal.
     *
     * @return the big decimal
     */
    public BigDecimal exchangeRate() {
        return null;
    }

    /**
     * Instructions for creditor agent list.
     *
     * @return the list
     */
    public List<String> instructionsForCreditorAgent() {
        return List.of();
    }

    /**
     * Creditor party party identification.
     *
     * @return the party identification
     */
    public PartyIdentification creditorParty() {
        return null;
    }

    /**
     * Creditor agent bank account . agent.
     *
     * @return the bank account . agent
     */
    public BankAccount.Agent creditorAgent() {
        return null;
    }

    /**
     * Returned instructed amount monetary amount.
     *
     * @return the monetary amount
     */
    public MonetaryAmount returnedInstructedAmount() {
        return null;
    }

    /**
     * Return reason reason info.
     *
     * @return the reason info
     */
    public ReasonInfo returnReason() {
        return null;
    }

    /**
     * Control sum big decimal.
     *
     * @return the big decimal
     */
    public BigDecimal controlSum() {
        return null;
    }

    /**
     * Creation date local date time.
     *
     * @return the local date time
     */
    public LocalDateTime creationDate() {
        return null;
    }

    /**
     * Number of transactions string.
     *
     * @return the string
     */
    public String numberOfTransactions() {
        return null;
    }

    /**
     * Debtor name string.
     *
     * @return the string
     */
    public String debtorName() {
        return null;
    }

    /**
     * Debtor ccy string.
     *
     * @return the string
     */
    public String debtorCcy() {
        return null;
    }

    /**
     * Remittances list.
     *
     * @return the list
     */
    public List<Remittance> remittances() {
        return List.of();
    }
}
