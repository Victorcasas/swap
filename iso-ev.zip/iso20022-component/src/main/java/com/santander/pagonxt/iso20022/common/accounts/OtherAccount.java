package com.santander.pagonxt.iso20022.common.accounts;

import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import lombok.Builder;

import java.util.Optional;


/**
 * The type Other account.
 */
public class OtherAccount extends LocalAccount {

    /**
     * Instantiates a new Other account.
     *
     * @param account       the account
     * @param accountName   the account name
     * @param currency      the currency
     * @param bicfi         the bicfi
     * @param agentName     the agent name
     * @param otherAgentId  the other agent id
     * @param address       the address
     * @param agentType     the agent type
     * @param agentMemberId the agent member id
     */
    @Builder
    public OtherAccount(String account,
                        String accountName,
                        String currency,
                        String bicfi,
                        String agentName,
                        String otherAgentId,
                        PartyIdentification.Address address,
                        String agentType,
                        String agentMemberId) {
        super(account, accountName, currency, bicfi, agentName, otherAgentId, address, agentType, agentMemberId);
    }

    @Override
    public AccountType getAccountType() {
        return new IsoCode(IsoCode.Codes.OTHR);
    }

    @Override
    public Optional<String> getPartenonCode() {
        return Optional.empty();
    }
}
