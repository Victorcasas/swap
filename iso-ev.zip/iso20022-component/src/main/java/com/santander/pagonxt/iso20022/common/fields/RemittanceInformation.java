package com.santander.pagonxt.iso20022.common.fields;

import lombok.Builder;
import lombok.Data;

/**
 * The type Remittance information.
 */
@Builder
@Data
public class RemittanceInformation {
    private String reference;
    private String unstructured;
}
