package com.santander.pagonxt.iso20022.messages.pain.pain001.helpers;

import com.santander.pagonxt.iso20022.common.fields.Payment;
import com.santander.pagonxt.iso20022.messages.pain.pain001.accessors.PaymentAccessor;
import com.santander.pagonxt.iso20022.messages.pain.pain001.accessors.RemittanceAccessor;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.CreditTransferTransactionInformation10;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.PaymentInstructionInformation3;

import java.util.ArrayList;
import java.util.List;

/**
 * Clase encargada de crear la lista de operations
 */
public class PaymentHelper {

    List<Payment> operationList(PaymentInstructionInformation3 remittance, RemittanceAccessor rAcc,
                                PaymentAccessor pAcc) {
        ArrayList<Payment> paymentList = new ArrayList<>();
        buildOperationList(remittance, rAcc, paymentList, pAcc);

        return paymentList;
    }

    void buildOperationList(PaymentInstructionInformation3 remittance, RemittanceAccessor rAcc,
                            ArrayList<Payment> paymentList, PaymentAccessor pAcc) {
        for (CreditTransferTransactionInformation10 payment : remittance.getCdtTrfTxInves()) {
            Payment payOut = buildOperation(remittance, rAcc, payment, pAcc);
            paymentList.add(payOut);
        }
    }

    Payment buildOperation(PaymentInstructionInformation3 remittance, RemittanceAccessor remittanceAccessor,
                           CreditTransferTransactionInformation10 payment, PaymentAccessor paymentAccessor) {
        return Payment.builder()
                .sourceName(remittanceAccessor.sourceName(remittance))
                .sourceCustomerId(remittanceAccessor.sourceCustomerId(remittance))
                .sourceAddressName(remittanceAccessor.sourceAddressName(remittance))
                .sourceAddressStreetName(remittanceAccessor.sourceAddressStreet(remittance))
                .sourceAddressTownName(remittanceAccessor.sourceAddressTown(remittance))
                .sourceAddressPostalCode(remittanceAccessor.sourceAddressPostalCode(remittance))
                .sourceAddressState(remittanceAccessor.sourceAddressCountrySubDivision(remittance))
                .sourceAddressCountry(remittanceAccessor.sourceAddressCountry(remittance))
                .sourceAddress(remittanceAccessor.sourceAddress(remittance))
                .sourceAccountId(remittanceAccessor.debtorAccount(remittance))
                .sourceAccountCurrency(remittanceAccessor.sourceAccountCurrency(remittance))
                .sourceAgent(remittanceAccessor.sourceAgent(remittance))
                .sourceAgentName(remittanceAccessor.sourceAgentName(remittance))
                .sourceAgentAddressStreet(remittanceAccessor.sourceAgentAddressStreet(remittance))
                .sourceAgentAddressTown(remittanceAccessor.sourceAgentAddressTown(remittance))
                .sourceAgentAddressCountrySubDivision(
                        remittanceAccessor.sourceAgentAddressCountrySubDivision(remittance))
                .sourceAgentAddressCountry(remittanceAccessor.sourceAgentAddressCountry(remittance))
                .sourceAgentAddress(remittanceAccessor.sourceAgentAddress(remittance))
                .sourceFeeAccountId(remittanceAccessor.sourceFeeAccountId(remittance))
                .sourceFeeAccountCurrency(remittanceAccessor.sourceFeeAccountCurrency(remittance))
                .sourceFeeAgent(remittanceAccessor.sourceFeeAgent(remittance))
                .sourceFeeAgentName(remittanceAccessor.sourceFeeAgentName(remittance))
                .sourceFeeAgentAddressStreet(remittanceAccessor.sourceFeeAgentAddressStreet(remittance))
                .sourceFeeAgentAddressTown(remittanceAccessor.sourceFeeAgentAddressTown(remittance))
                .sourceFeeAgentAddressCountrySubDivision(
                        remittanceAccessor.sourceFeeAgentAddressCountrySubDivision(remittance))
                .sourceFeeAgentAddressCountry(remittanceAccessor.sourceFeeAgentAddressCountry(remittance))
                .sourceFeeAgentAddress(remittanceAccessor.sourceFeeAgentAddress(remittance))
                .senderReference(paymentAccessor.senderReference(payment))
                .chargeBearer(paymentAccessor.chargeBearer(payment))
                .clientReference(paymentAccessor.clientReference(payment))
                .purpose(paymentAccessor.purpose(payment))
                .transferDescription(paymentAccessor.transferDescription(payment))
                .operationCurrency(paymentAccessor.operationCurrency(payment))
                .operationAmount(paymentAccessor.operationAmount(payment))
                .operationAmountCurrency(paymentAccessor.operationAmountCurrency(payment))
                .destinationName(paymentAccessor.destinationName(payment))
                .destinationAccountId(paymentAccessor.destinationAccountId(payment))
                .destinationAccountCurrency(paymentAccessor.destinationAccountCurrency(payment))
                .destinationCustomerId(paymentAccessor.destinationCustomerId(payment))
                .destinationAgent(paymentAccessor.destinationAgent(payment))
                .destinationAgentLocalCode(paymentAccessor.destinationAgentLocalCode(payment))
                .destinationAgentName(paymentAccessor.destinationAgentName(payment))
                .destinationAgentAddressStreet(paymentAccessor.destinationAgentAddressStreet(payment))
                .destinationAgentAddressTown(paymentAccessor.destinationAgentAddressTown(payment))
                .destinationAgentAddressCountrySubDivision(
                        paymentAccessor.destinationAgentAddressCountrySubDivision(payment))
                .destinationAgentAddressCountry(paymentAccessor.destinationAgentAddressCountry(payment))
                .destinationAgentAddress(paymentAccessor.destinationAgentAddress(payment))
                .destinationAddressStreetName(paymentAccessor.destinationAddressStreet(payment))
                .destinationAddressTownName(paymentAccessor.destinationAddressTown(payment))
                .destinationAddressPostalCode(paymentAccessor.destinationAddressTown(payment))
                .destinationAddressState(paymentAccessor.destinationAddressCountrySubDivision(payment))
                .destinationAddressCountry(paymentAccessor.destinationAddressCountry(payment))
                .destinationAddress(paymentAccessor.destinationAddress(payment))
                .counterValueOperationAmount(paymentAccessor.counterValueOperationAmount(payment))
                .counterValueOperationAmountCurrency(paymentAccessor.counterValueOperationAmountCurrency(payment))
                .counterValueOperationAmountTradeCurrency(
                        paymentAccessor.counterValueOperationAmountTradeCurrency(payment))
                .subject(paymentAccessor.subject(payment))
                .creditorDocumentType(paymentAccessor.getCreditorDocumentType(payment))
                .creditorDocumentNumber(paymentAccessor.getCreditorDocumentNumber(payment))
                .build();
    }

}
