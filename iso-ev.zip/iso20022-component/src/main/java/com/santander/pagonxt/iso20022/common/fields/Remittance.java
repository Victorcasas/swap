package com.santander.pagonxt.iso20022.common.fields;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Remittance.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Remittance {

    private String paymentMethod;
    private String paymentInfoId;
    private Boolean batchBooking;
    private Integer numberOfTxs;
    private BigDecimal controlSum;
    private String instrPriority;
    private String informationCode;
    private String localInstrumentCode;
    private String purpose;
    private LocalDate requestedExecutionDate;
    private String debtorAccount;
    private String chargeBearer;
    private String originCountry;
    private List<Payment> payments;
}
