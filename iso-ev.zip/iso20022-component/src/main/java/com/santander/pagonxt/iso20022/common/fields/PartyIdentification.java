package com.santander.pagonxt.iso20022.common.fields;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Value;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.text.WordUtils;

import java.time.LocalDate;
import java.util.List;
import java.util.Objects;

import static java.lang.Math.min;
import static java.lang.String.join;
import static java.lang.System.lineSeparator;
import static java.util.Arrays.asList;
import static java.util.Collections.emptyList;
import static java.util.Optional.ofNullable;
import static java.util.stream.Collectors.toList;
import static java.util.stream.Collectors.toUnmodifiableList;
import static org.apache.commons.collections4.ListUtils.union;
import static org.apache.commons.lang3.text.WordUtils.wrap;
import static org.codehaus.plexus.util.StringUtils.abbreviate;

/**
 * The type Party identification.
 */
@Builder
@Value
public class PartyIdentification {
    String name;
    Address address;
    PartyType partyType;
    PartyChoice id;

    /**
     * The type Party type.
     */
    public interface PartyType {
        /**
         * Identifier string.
         *
         * @return the string
         */
        String identifier();
    }

    /**
     * The type Person.
     */
    @Value
    @Builder
    @EqualsAndHashCode(callSuper = false)
    public static class Person implements PartyType {
        String otherId;

        @Override
        public String identifier() {
            return otherId;
        }
    }

    /**
     * The type Organisation.
     */
    @Value
    @Builder
    @EqualsAndHashCode(callSuper = false)
    public static class Organisation implements PartyType {
        String bic;
        String otherId;
        String otherIssuer;
        String schemeName;

        @Override
        public String identifier() {
            return ofNullable(bic).orElse(otherId);
        }
    }

    /**
     * The type Address.
     */
    @Data
    @Builder
    public static class Address {
        /**
         * The constant MAX_LINES_ALLOWED.
         */
// iso20022 limit of address lines
        public static final int MAX_LINES_ALLOWED = 7;
        /**
         * The constant MAX_LINE_LENGTH.
         */
// iso20022 limit length per line
        public static final int MAX_LINE_LENGTH = 70;
        private String department;
        private String subDepartment;
        private String streetName;
        private String buildingNumber;
        private String buildingName;
        private String floor;
        private String postBox;
        private String room;
        private String postCode;
        private String town;
        private String townLocationName;
        private String districtName;
        private String countrySubDivision;
        // The code is checked against the list of country names
        // obtained from the United Nations (ISO 3166, Alpha-2 code).
        private String country;
        private List<String> addressLine;
        private String addressType;

        /**
         * From address.
         *
         * @param oneLineAddress the one line address
         * @return the address
         */
        public static Address from(String oneLineAddress) {
            if (StringUtils.isBlank(oneLineAddress)) {
                return null;
            }
            final String wrapped = wrap(oneLineAddress, MAX_LINE_LENGTH);
            final List<String> lines = asList(
                    wrapped.split(lineSeparator())
            );
            final List<String> addressLine =
                    lines.subList(0, min(lines.size(), MAX_LINES_ALLOWED))
                            .stream()
                            .map(line -> line.length() > MAX_LINE_LENGTH ? abbreviate(line, MAX_LINE_LENGTH) : line)
                            .collect(toUnmodifiableList());
            return Address.builder()
                    .addressLine(addressLine)
                    .build();
        }

        /**
         * Gets address in line.
         *
         * @return the address in line
         */
        public String getAddressInLine() {
            return getAddressInLine(", ");
        }

        /**
         * Gets address in line.
         *
         * @param delimiter the delimiter
         * @return the address in line
         */
        public String getAddressInLine(String delimiter) {
            final String countryCode = ofNullable(country).orElse(null);
            List<String> fullAddress = union(getAddressLine(), asList(town, postCode, countryCode));

            List<String> notBlankAddressLine = fullAddress.stream()
                    .filter(StringUtils::isNotBlank)
                    .collect(toList());

            return join(delimiter, notBlankAddressLine);
        }

        /**
         * Is empty boolean.
         *
         * @return the boolean
         */
        public boolean isEmpty() {
            return (addressLine == null || addressLine.isEmpty()) &&
                    StringUtils.isBlank(postCode) &&
                    country == null &&
                    StringUtils.isBlank(town);
        }

        /**
         * Gets address line.
         *
         * @return the address line
         */
        public List<String> getAddressLine() {
            return Objects.requireNonNullElse(addressLine, emptyList());
        }
    }

    /**
     * The type Party choice.
     */
    @Data
    @Builder
    public static class PartyChoice {
        private PersonIdentification prvtId;
    }

    /**
     * The type Person identification.
     */
    @Data
    @Builder
    public static class PersonIdentification {
        private DateAndPlaceOfBirth dtAndPlcOfBirth;
        private List<GenericPersonIdentification> othr;
    }

    /**
     * The type Date and place of birth.
     */
    @Data
    @Builder
    public static class DateAndPlaceOfBirth {
        private LocalDate birthDt;
        private String prvcOfBirth;
        private String cityOfBirth;
        private String birthCountry;
    }

    /**
     * The type Generic person identification.
     */
    @Data
    @Builder
    public static class GenericPersonIdentification {
        private String id;
        private PersonIdentificationSchemeNameChoice schmeNm;
        private String issr;
    }

    /**
     * The type Person identification scheme name choice.
     */
    @Data
    @Builder
    public static class PersonIdentificationSchemeNameChoice {
        /**
         * The Cd.
         */
        protected String cd;
        /**
         * The Prtry.
         */
        protected String prtry;
    }
}
