package com.santander.pagonxt.iso20022.common.accounts;

import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import lombok.Builder;

import java.util.Optional;

import static com.santander.pagonxt.iso20022.common.accounts.IsoCode.Codes.SVGS;

/**
 * The type Savings account.
 */
public class SavingsAccount extends LocalAccount {

    /**
     * The constant PARTENON_CODE.
     */
    public static final String PARTENON_CODE = "5";

    /**
     * Instantiates a new Savings account.
     *
     * @param account       the account
     * @param accountName   the account name
     * @param currency      the currency
     * @param bicfi         the bicfi
     * @param agentName     the agent name
     * @param otherAgentId  the other agent id
     * @param address       the address
     * @param agentType     the agent type
     * @param agentMemberId the agent member id
     */
    @Builder
    public SavingsAccount(String account,
                          String accountName,
                          String currency,
                          String bicfi,
                          String agentName,
                          String otherAgentId,
                          PartyIdentification.Address address,
                          String agentType,
                          String agentMemberId) {
        super(account, accountName, currency, bicfi, agentName, otherAgentId, address, agentType, agentMemberId);
    }

    @Override
    public AccountType getAccountType() {
        return new IsoCode(SVGS);
    }

    @Override
    public Optional<String> getPartenonCode() {
        return Optional.of(PARTENON_CODE);
    }

    @Override
    public String getIdentification() {
        return "SAVING" + accountNumber();
    }

    /**
     * Account number string.
     *
     * @return the string
     */
    public String accountNumber() {
        return super.getIdentification();
    }
}
