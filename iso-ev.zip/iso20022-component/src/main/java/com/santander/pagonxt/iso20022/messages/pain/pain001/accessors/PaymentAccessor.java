package com.santander.pagonxt.iso20022.messages.pain.pain001.accessors;

import com.santander.pagonxt.iso20022.common.util.StringFieldsUtils;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.*;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.List;

import static java.util.Optional.of;

/**
 * The type Payment accessor.
 */
public class PaymentAccessor {

    /**
     * Sender reference string.
     *
     * @param payment the payment
     * @return the string
     */
    public String senderReference(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getPmtId)
                .map(PaymentIdentification1::getEndToEndId)
                .orElse(null);
    }

    /**
     * Charge bearer string.
     *
     * @param payment the payment
     * @return the string
     */
    public String chargeBearer(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getChrgBr)
                .map(ChargeBearerType1Code::value)
                .orElse(null);
    }

    /**
     * Client reference string.
     *
     * @param payment the payment
     * @return the string
     */
    public String clientReference(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getPmtId)
                .map(PaymentIdentification1::getInstrId)
                .orElse(null);
    }

    /**
     * Purpose string.
     *
     * @param payment the payment
     * @return the string
     */
    public String purpose(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getPurp)
                .map(purp -> {
                    if(StringUtils.isNotEmpty(purp.getCd()))
                        return purp.getCd();
                    else
                        return purp.getPrtry();
                })
                .orElse(null);
    }

    /**
     * Transfer description list.
     *
     * @param payment the payment
     * @return the list
     */
    public String transferDescription(CreditTransferTransactionInformation10 payment) {
        return of(of(of(payment)
                .map(CreditTransferTransactionInformation10::getRmtInf)
                .map(RemittanceInformation5::getUstrds)
                .orElse(List.of())
                .get(0))).get().get();
    }

    /**
     * Operation currency string.
     *
     * @param payment the payment
     * @return the string
     */
    public String operationCurrency(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getAmt)
                .map(AmountType3Choice::getEqvtAmt)
                .map(EquivalentAmount2::getCcyOfTrf)
                .orElse(null);
    }

    /**
     * Operation amount big decimal.
     *
     * @param payment the payment
     * @return the big decimal
     */
    public BigDecimal operationAmount(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getAmt)
                .map(AmountType3Choice::getInstdAmt)
                .map(ActiveOrHistoricCurrencyAndAmount::getValue)
                .orElse(null);
    }

    /**
     * Operation amount currency string.
     *
     * @param payment the payment
     * @return the string
     */
    public String operationAmountCurrency(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getAmt)
                .map(AmountType3Choice::getInstdAmt)
                .map(ActiveOrHistoricCurrencyAndAmount::getCcy)
                .orElse(null);
    }

    /**
     * Destination name string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationName(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtr)
                .map(PartyIdentification32::getNm)
                .orElse(null);
    }

    /**
     * Destination account id string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAccountId(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtrAcct)
                .map(CashAccount16::getId)
                .map(info -> {
                    if(StringUtils.isNotEmpty(info.getIBAN()))
                        return info.getIBAN();
                    else if(info.getOthr() !=null)
                        return info.getOthr().getId();

                    return null;
                })
                .orElse(null);
    }

    /**
     * Destination account currency string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAccountCurrency(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtrAcct)
                .map(CashAccount16::getCcy)
                .orElse(null);
    }

    /**
     * Destination customer id string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationCustomerId(CreditTransferTransactionInformation10 payment) {
        PaymentIdentification1 id = payment.getPmtId();
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtr)
                .map(PartyIdentification32::getId)
                .map(Party6Choice::getOrgId)
                .map(OrganisationIdentification4::getOthrs)
                .map(list -> list.get(0))
                .map(GenericOrganisationIdentification1::getId)
                .orElse(null);
    }

    /**
     * Destination agent string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAgent(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getBIC)
                .orElse(null);
    }

    /**
     * Destination agent local code string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAgentLocalCode(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getOthr)
                .map(GenericFinancialIdentification1::getId)
                .orElse(null);
    }

    /**
     * Destination agent name string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAgentName(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getNm)
                .orElse(null);
    }

    /**
     * Destination agent address street string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAgentAddressStreet(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getStrtNm)
                .orElse(null);
    }

    /**
     * Destination agent address town string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAgentAddressTown(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getTwnNm)
                .orElse(null);
    }

    /**
     * Destination agent address country sub division string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAgentAddressCountrySubDivision(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getCtrySubDvsn)
                .orElse(null);
    }

    /**
     * Destination agent address country string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAgentAddressCountry(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtrAgt)
                .map(BranchAndFinancialInstitutionIdentification4::getFinInstnId)
                .map(FinancialInstitutionIdentification7::getPstlAdr)
                .map(PostalAddress6::getCtry)
                .orElse(null);
    }

    /**
     * Destination agent address string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAgentAddress(CreditTransferTransactionInformation10 payment) {

        StringBuilder builder = new StringBuilder();
        StringFieldsUtils.addSafeFieldWithSeparator(builder,destinationAgentAddressStreet(payment), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,destinationAgentAddressTown(payment), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,destinationAgentAddressCountrySubDivision(payment), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,destinationAgentAddressCountry(payment), null);

        return builder.toString();
    }

    /**
     * Destination address street string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAddressStreet(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtr)
                .map(PartyIdentification32::getPstlAdr)
                .map(PostalAddress6::getStrtNm)
                .orElse(null);
    }

    /**
     * Destination address town string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAddressTown(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtr)
                .map(PartyIdentification32::getPstlAdr)
                .map(PostalAddress6::getTwnNm)
                .orElse(null);
    }

    /**
     * Destination address country sub division string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAddressCountrySubDivision(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtr)
                .map(PartyIdentification32::getPstlAdr)
                .map(PostalAddress6::getCtrySubDvsn)
                .orElse(null);
    }

    /**
     * Destination address country string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAddressCountry(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtr)
                .map(PartyIdentification32::getPstlAdr)
                .map(PostalAddress6::getCtry)
                .orElse(null);
    }
    /**
     * Destination address postal code string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAddressPostalCode(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtr)
                .map(PartyIdentification32::getPstlAdr)
                .map(PostalAddress6::getPstCd)
                .orElse(null);
    }

    /**
     * Destination address string.
     *
     * @param payment the payment
     * @return the string
     */
    public String destinationAddress(CreditTransferTransactionInformation10 payment) {

        StringBuilder builder = new StringBuilder();
        StringFieldsUtils.addSafeFieldWithSeparator(builder,destinationAddressStreet(payment), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,destinationAddressTown(payment), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,destinationAddressCountrySubDivision(payment), StringUtils.SPACE);
        StringFieldsUtils.addSafeFieldWithSeparator(builder,destinationAddressCountry(payment), null);

        return builder.toString();
    }

    /**
     * Counter value operation amount big decimal.
     *
     * @param payment the payment
     * @return the big decimal
     */
    public BigDecimal counterValueOperationAmount(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getAmt)
                .map(AmountType3Choice::getEqvtAmt)
                .map(EquivalentAmount2::getAmt)
                .map(ActiveOrHistoricCurrencyAndAmount::getValue)
                .orElse(null);
    }

    /**
     * Counter value operation amount currency string.
     *
     * @param payment the payment
     * @return the string
     */
    public String counterValueOperationAmountCurrency(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getAmt)
                .map(AmountType3Choice::getEqvtAmt)
                .map(EquivalentAmount2::getAmt)
                .map(ActiveOrHistoricCurrencyAndAmount::getCcy)
                .orElse(null);
    }

    /**
     * Counter value operation amount trade currency string.
     *
     * @param payment the payment
     * @return the string
     */
    public String counterValueOperationAmountTradeCurrency(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getAmt)
                .map(AmountType3Choice::getEqvtAmt)
                .map(EquivalentAmount2::getCcyOfTrf)
                .orElse(null);
    }



    public String ultimateDebtor(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getUltmtDbtr)
                .map(PartyIdentification32::getNm)
                .orElse(null);
    }

    public String subject(CreditTransferTransactionInformation10 payment) {
        return of(of(of(payment)
                .map(CreditTransferTransactionInformation10::getRmtInf)
                .map(RemittanceInformation5::getUstrds)
                .orElse(List.of())
                .get(0))).get().get();
    }

    public String getCreditorDocumentType(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtr)
                .map(PartyIdentification32::getId)
                .map(Party6Choice::getOrgId)
                .map(id -> {

                    if(StringUtils.isNotEmpty(id.getBICOrBEI())){
                        return id.getBICOrBEI();
                    }else if( !id.getOthrs().isEmpty() ){
                        if( StringUtils.isNotEmpty(id.getOthrs().get(0).getSchmeNm().getCd())){
                            return id.getOthrs().get(0).getSchmeNm().getCd();
                        }else{
                            return  id.getOthrs().get(0).getSchmeNm().getPrtry();
                        }
                    }

                    return null;
                })
                .orElse(null);
    }

    public String getCreditorDocumentNumber(CreditTransferTransactionInformation10 payment) {
        return of(payment)
                .map(CreditTransferTransactionInformation10::getCdtr)
                .map(PartyIdentification32::getId)
                .map(Party6Choice::getOrgId)
                .map(id -> {
                    if (StringUtils.isNotEmpty(id.getBICOrBEI())) {
                        return id.getBICOrBEI();
                    } else if (!id.getOthrs().isEmpty()) {
                        if (StringUtils.isNotEmpty(id.getOthrs().get(0).getSchmeNm().getCd())) {
                            return id.getOthrs().get(0).getSchmeNm().getCd();
                        } else {
                            return id.getOthrs().get(0).getSchmeNm().getPrtry();
                        }
                    }
                return null;
                })
                .orElse(null);
                }

}
