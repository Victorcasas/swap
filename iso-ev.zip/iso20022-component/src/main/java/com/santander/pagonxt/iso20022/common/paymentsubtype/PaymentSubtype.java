package com.santander.pagonxt.iso20022.common.paymentsubtype;

/**
 * The type Payment subtype.
 */
public interface PaymentSubtype {

    /**
     * Value string.
     *
     * @return the string
     */
    String value();
}
