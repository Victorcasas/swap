package com.santander.pagonxt.iso20022.messages.pacs.pacs004;

import com.santander.pagonxt.iso20022.core.Iso20022Message;
import com.santander.pagonxt.iso20022.core.Iso20022MessageAccessor;
import com.santander.pagonxt.iso20022.core.Iso2022MessageValidator;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Document;

public class Pacs004v09Message extends Iso20022Message<Document> {

    private static final String MESSAGE_DEFINITION = "pacs.004.001.09";

    protected Pacs004v09Message(Document document) {
        super(document);
    }

    @Override
    public Iso20022MessageAccessor<Document> getAccessor() {
        return new Pacs004v09Accessor(document());
    }

    @Override
    public void validateMessage() {
        final var validator = new Iso2022MessageValidator<Document>(
                MESSAGE_DEFINITION,
                String.format(DEFINITION_PATH, MESSAGE_DEFINITION)
        );
        validator.validateDocument(document());
    }
}
