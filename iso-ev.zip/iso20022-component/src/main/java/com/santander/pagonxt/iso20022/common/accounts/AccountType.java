package com.santander.pagonxt.iso20022.common.accounts;

/**
 * The type Account type.
 */
public interface AccountType {

    /**
     * Value string.
     *
     * @return the string
     */
    String value();
}
