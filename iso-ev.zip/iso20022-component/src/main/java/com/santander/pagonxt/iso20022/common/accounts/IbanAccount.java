package com.santander.pagonxt.iso20022.common.accounts;

import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import lombok.Builder;
import lombok.NonNull;

import java.util.Objects;
import java.util.Optional;

/**
 * The type Iban account.
 */
public class IbanAccount extends BankAccount {

    /**
     * The constant PARTENON_CODE.
     */
    public static final String PARTENON_CODE = "2";
    private final String iban;

    /**
     * Instantiates a new Iban account.
     *
     * @param iban          the iban
     * @param accountName   the account name
     * @param currency      the currency
     * @param bicfi         the bicfi
     * @param agentName     the agent name
     * @param agentType     the agent type
     * @param otherAgentId  the other agent id
     * @param address       the address
     * @param agentMemberId the agent member id
     */
    @Builder
    public IbanAccount(@NonNull String iban,
                       String accountName,
                       String currency,
                       String bicfi,
                       String agentName,
                       String agentType,
                       String otherAgentId,
                       PartyIdentification.Address address,
                       String agentMemberId) {
        super(Account.builder()
                        .identification(iban)
                        .name(accountName)
                        .schemeName(Account.SchemeName.IBAN)
                        .currency(currency)
                        .build(),
                Agent.builder()
                        .bicfi(Optional.ofNullable(bicfi)
                                .map(Objects::toString)
                                .orElse(null))
                        .name(agentName)
                        .type(agentType)
                        .address(address)
                        .otherId(otherAgentId)
                        .memberId(agentMemberId)
                        .build());
        this.iban = iban;
    }

    /**
     * Iban string.
     *
     * @return the string
     */
    public String iban() {
        return iban;
    }

    @Override
    public Optional<String> getPartenonCode() {
        return Optional.of(PARTENON_CODE);
    }

    @Override
    public AccountType getAccountType() {
        return null;
    }
}
