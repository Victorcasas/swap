package com.santander.pagonxt.iso20022.common.fields;

/**
 * The enum Regulatory reporting type code.
 */
public enum RegulatoryReportingTypeCode {

    /**
     * Cred regulatory reporting type code.
     */
    CRED,
    /**
     * Debt regulatory reporting type code.
     */
    DEBT,
    /**
     * Both regulatory reporting type code.
     */
    BOTH;

    /**
     * Value string.
     *
     * @return the string
     */
    public String value() {
        return name();
    }

    /**
     * From value regulatory reporting type code.
     *
     * @param v the v
     * @return the regulatory reporting type code
     */
    public static RegulatoryReportingTypeCode fromValue(String v) {
        return valueOf(v);
    }
}
