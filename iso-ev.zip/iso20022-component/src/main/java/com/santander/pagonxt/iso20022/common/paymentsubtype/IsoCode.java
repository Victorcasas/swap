package com.santander.pagonxt.iso20022.common.paymentsubtype;

import lombok.EqualsAndHashCode;
import lombok.Value;

/**
 * The type Iso code.
 */
@Value
@EqualsAndHashCode(callSuper = false)
public class IsoCode implements PaymentSubtype {

    Codes codes;

    @Override
    public String value() {
        return codes.toString();
    }

    /**
     * The enum Codes.
     */
    public enum Codes {
        /**
         * Taxs codes.
         */
        TAXS,
        /**
         * Inte codes.
         */
        INTE,
        /**
         * Sala codes.
         */
        SALA,
        /**
         * Pens codes.
         */
        PENS,
        /**
         * Btr codes.
         */
        BTR
    }
}
