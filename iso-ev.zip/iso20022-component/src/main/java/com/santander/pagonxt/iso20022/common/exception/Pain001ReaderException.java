package com.santander.pagonxt.iso20022.common.exception;

public class Pain001ReaderException extends Exception {

  public Pain001ReaderException(Throwable cause) {
    super(cause);
  }
}
