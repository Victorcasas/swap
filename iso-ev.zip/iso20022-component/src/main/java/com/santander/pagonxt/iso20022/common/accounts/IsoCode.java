package com.santander.pagonxt.iso20022.common.accounts;

import lombok.EqualsAndHashCode;
import lombok.Value;

/**
 * The type Iso code.
 */
@Value
@EqualsAndHashCode(callSuper = false)
public class IsoCode implements AccountType {

    Codes code;

    @Override
    public String value() {
        return code.toString();
    }

    /**
     * The enum Codes.
     */
    public enum Codes {

        /**
         * Cacc codes.
         */
        CACC("Current"),
        /**
         * Cash codes.
         */
        CASH("CashPayment"),
        /**
         * Char codes.
         */
        CHAR("Charges"),
        /**
         * Cish codes.
         */
        CISH("CashIncome"),
        /**
         * Comm codes.
         */
        COMM("Commission"),
        /**
         * Cpac codes.
         */
        CPAC("ClearingParticipantSettlementAccount"),
        /**
         * Llsv codes.
         */
        LLSV("LimitedLiquiditySavingsAccount"),
        /**
         * Loan codes.
         */
        LOAN("Loan"),
        /**
         * The Mgld.
         */
        MGLD("Marginal Lending"),
        /**
         * The Moma.
         */
        MOMA("Money Market"),
        /**
         * Nrex codes.
         */
        NREX("NonResidentExternal"),
        /**
         * Odft codes.
         */
        ODFT("Overdraft"),
        /**
         * Ondp codes.
         */
        ONDP("OverNightDeposit"),
        /**
         * Othr codes.
         */
        OTHR("OtherAccount"),
        /**
         * Sacc codes.
         */
        SACC("Settlement"),
        /**
         * Slry codes.
         */
        SLRY("Salary"),
        /**
         * Svgs codes.
         */
        SVGS("Savings"),
        /**
         * Taxe codes.
         */
        TAXE("Tax"),
        /**
         * Tran codes.
         */
        TRAN("TransactingAccount"),
        /**
         * The Tras.
         */
        TRAS("Cash Trading");

        /**
         * The Desc.
         */
        private final String desc;

        Codes(String desc) {
            this.desc = desc;
        }
    }
}
