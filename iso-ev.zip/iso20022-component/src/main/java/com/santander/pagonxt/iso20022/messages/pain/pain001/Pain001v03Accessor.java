package com.santander.pagonxt.iso20022.messages.pain.pain001;

import com.santander.pagonxt.iso20022.common.fields.Remittance;
import com.santander.pagonxt.iso20022.core.Iso20022MessageAccessor;
import com.santander.pagonxt.iso20022.messages.pain.pain001.accessors.PaymentAccessor;
import com.santander.pagonxt.iso20022.messages.pain.pain001.accessors.RemittanceAccessor;
import com.santander.pagonxt.iso20022.messages.pain.pain001.helpers.RemittanceHelper;
import com.santander.pagonxt.iso20022.messages.pain.pain001.helpers.TransactionHelper;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static java.util.Optional.of;

/**
 * The type Pain 001 accessor.
 */
public class Pain001v03Accessor extends Iso20022MessageAccessor<Document> {

    private final RemittanceAccessor remittanceAccessor;
    private final PaymentAccessor paymentAccessor;

    private final RemittanceHelper remittanceHelper;
    private final TransactionHelper transactionHelper;

    /**
     * Instantiates a new Pain 001 accessor.
     *
     * @param document the document
     */
    public Pain001v03Accessor(Document document) {
        this.document = document;

        remittanceAccessor = new RemittanceAccessor();
        paymentAccessor = new PaymentAccessor();

        remittanceHelper = new RemittanceHelper();
        transactionHelper = new TransactionHelper();
    }


    /**
     * Message id string.
     *
     * @return the string
     */
    @Override
    public String messageId() {
        return groupHeader().map(GroupHeader32::getMsgId).orElse(null);
    }

    /**
     * Control sum big decimal.
     *
     * @return the big decimal
     */
    @Override
    public BigDecimal controlSum() {
        return groupHeader().map(GroupHeader32::getCtrlSum).orElse(null);
    }

    /**
     * Creation date local date time.
     *
     * @return the local date time
     */
   @Override
    public LocalDateTime creationDate() {
        return groupHeader().map(GroupHeader32::getCreDtTm).map(ZonedDateTime::toLocalDateTime).orElse(null);
    }

    /**
     * Number of transactions string.
     *
     * @return the string
     */
    @Override
    public String numberOfTransactions() {
        return groupHeader().map(GroupHeader32::getNbOfTxs).orElse(null);
    }

    /**
     * Debtor name string.
     *
     * @return the string
     */
    @Override
    public String debtorName() {
        return transactionHelper.firstTransaction(this.document)
                .map(PaymentInstructionInformation3::getDbtr)
                .map(PartyIdentification32::getNm)
                .orElse(null);
    }

    /**
     * Debtor ccy string.
     *
     * @return the string
     */
    @Override
    public String debtorCcy() {
        return transactionHelper.firstTransaction(this.document)
                .map(PaymentInstructionInformation3::getDbtrAcct)
                .map(CashAccount16::getCcy)
                .orElse(null);
    }

    /**
     * Remittance list list.
     *
     * @return the string
     */
    @Override
    public List<Remittance> remittances() {
        Optional<List<PaymentInstructionInformation3>> remList = transactionHelper.allTransaction(this.document);
        ArrayList<Remittance> remittanceList = new ArrayList<>();

        if (remList.isPresent()) {
            remittanceHelper.buildRemittanceList(remList, remittanceList, remittanceAccessor, paymentAccessor);
        }

        return remittanceList;
    }

    private Optional<GroupHeader32> groupHeader() {
        return of(document).map(Document::getCstmrCdtTrfInitn).map(CustomerCreditTransferInitiationV03::getGrpHdr);
    }
}
