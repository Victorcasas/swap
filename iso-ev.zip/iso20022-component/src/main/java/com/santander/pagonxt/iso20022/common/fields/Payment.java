package com.santander.pagonxt.iso20022.common.fields;

import java.math.BigDecimal;
import java.util.List;

import com.santander.pagonxt.iso20022.messages.pain.pain001.model.AccountIdentification4Choice;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * The type Operation.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Payment {

    private String sourceName;
    private String sourceCustomerId;
    private String creditorDocumentType;
    private String creditorDocumentNumber;
    private String sourceAddressName;
    private String sourceAddressStreetName;
    private String sourceAddressTownName;
    private String sourceAddressState;
    private String sourceAddressCountry;
    private String sourceAddress;
    private String sourceAddressPostalCode;
    private String sourceAccountId;
    private String sourceAccountCurrency;
    private String sourceAgent;
    private String sourceAgentName;
    private String sourceAgentAddressStreet;
    private String sourceAgentAddressTown;
    private String sourceAgentAddressCountrySubDivision;
    private String sourceAgentAddressCountry;
    private String sourceAgentAddress;
    private String sourceFeeAccountId;
    private String sourceFeeAccountCurrency;
    private String sourceFeeAgent;
    private String sourceFeeAgentName;
    private String sourceFeeAgentAddressStreet;
    private String sourceFeeAgentAddressTown;
    private String sourceFeeAgentAddressCountrySubDivision;
    private String sourceFeeAgentAddressCountry;
    private String sourceFeeAgentAddress;
    private String senderReference;
    private String chargeBearer;
    private String clientReference;
    private String purpose;
    private String transferDescription;
    private String operationCurrency;
    private BigDecimal operationAmount;
    private String operationAmountCurrency;
    private String destinationName;
    private String destinationAccountId;
    private String destinationAccountCurrency;
    private String destinationCustomerId;
    private String destinationAgent;
    private String destinationAgentLocalCode;
    private String destinationAgentName;
    private String destinationAgentAddressStreet;
    private String destinationAgentAddressTown;
    private String destinationAgentAddressCountrySubDivision;
    private String destinationAgentAddressCountry;
    private String destinationAgentAddress;
    private String destinationAddressStreetName;
    private String destinationAddressTownName;
    private String destinationAddressState;
    private String destinationAddressCountry;
    private String destinationAddressPostalCode;
    private String destinationAddress;
    private BigDecimal counterValueOperationAmount;
    private String counterValueOperationAmountCurrency;
    private String counterValueOperationAmountTradeCurrency;
    private String subject;
}
