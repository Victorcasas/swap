package com.santander.pagonxt.iso20022.common.fields;

import lombok.AllArgsConstructor;

import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.util.Collections.singletonList;
import static java.util.stream.Collectors.toList;


/**
 * This is a utility class designed to help with the handling of labeled (and unlabeled) references.
 * Labeled references are strings with the format "/{labelName}/{value}" that have been whitelisted.
 * Unlabeled references are strings with any other format, or not whitelisted.
 */
@AllArgsConstructor
public class References {
    /**
     * The constant ACCOUNTING_REFERENCE_LABEL.
     */
    public static final String ACCOUNTING_REFERENCE_LABEL = "RFO";
    /**
     * The constant ORIGINAL_MESSAGE_ID_LABEL.
     */
    public static final String ORIGINAL_MESSAGE_ID_LABEL = "originalMessageId";
    private static final Pattern isLabeledReferencePattern = Pattern.compile("^/([^/]*)/(.*)$");

    private List<String> references;
    private final List<String> whitelist;

    /**
     * Generates a new instance of this class with an existing list of references
     * and the provided labels whitelist
     *
     * @param references the list of existing references
     * @param whitelist  the labels whitelist
     * @return an instance of this class
     */
    public static References from(List<String> references, List<String> whitelist) {
        return new References(references, whitelist);
    }

    /**
     * Generates a new instance of this class with the provided labels whitelist
     *
     * @param whitelist the labels whitelist
     * @return an instance of this class
     */
    public static References empty(List<String> whitelist) {
        return new References(List.of(), whitelist);
    }

    /**
     * Finds and returns the first labeled reference matching the provided name.
     * A labeled reference meets all of the following criteria:
     * <ul>
     *     <li>Matches the format /{labelName}/{value}</li>
     *     <li>Is whitelisted</li>
     * </ul>
     *
     * @param labelName the label name
     * @return the first labeled reference with a matching label name
     */
    public String findFirst(String labelName) {
        return findAll(labelName).stream()
                .findFirst()
                .orElse(null);
    }

    /**
     * Finds and returns all the labeled references matching the provided name.
     * A labeled reference meets all of the following criteria:
     * <ul>
     *     <li>Matches the format /{labelName}/{value}</li>
     *     <li>Is whitelisted</li>
     * </ul>
     *
     * @param labelName the label name
     * @return all the labeled references with a matching label name
     */
    public List<String> findAll(String labelName) {
        return references.stream()
                .filter(ref -> labeledReferenceMatcher(ref)
                        .filter(matcher -> matcher.group(1).equals(labelName))
                        .isPresent())
                .map(ref -> labeledReferenceMatcher(ref)
                        .map(matcher -> matcher.group(2))
                        .orElse(ref))
                .collect(toList());
    }

    /**
     * Finds and returns all unlabeled references.
     * An unlabeled reference meets either of the following criteria:
     * <ul>
     *     <li>Does not match the format /{labelName}/{value}</li>
     *     <li>Is not whitelisted</li>
     * </ul>
     *
     * @return all the current unlabeled references
     */
    public List<String> findUnlabeled() {
        return references.stream()
                .filter(ref -> labeledReferenceMatcher(ref).isEmpty())
                .collect(toList());
    }

    /**
     * Overrides all the labeled references matching the provided name
     * with a single string
     *
     * @param labelName the label to look for
     * @param value     the value of the reference
     */
    public void set(String labelName, String value) {
        set(labelName, singletonList(value));
    }

    /**
     * Overrides all the labeled references matching the provided name
     * with a new list
     *
     * @param labelName the label to look for
     * @param values    the value of the reference
     */
    public void set(String labelName, List<String> values) {
        this.references = references.stream()
                .filter(ref -> labeledReferenceMatcher(ref)
                        .filter(matcher -> matcher.group(1).equals(labelName))
                        .isEmpty()).collect(java.util.stream.Collectors.toCollection(LinkedList::new));
        this.references.addAll(values.stream()
                .map(withLabel(labelName))
                .collect(toList()));
    }

    /**
     * Overrides all the unlabeled references with a new list
     *
     * @param unlabeledReferences the list of unlabeled references
     */
    public void setUnlabeled(List<String> unlabeledReferences) {
        final var labeledReferences = references.stream()
                .filter(ref -> labeledReferenceMatcher(ref).isPresent())
                .collect(toList());

        this.references = new LinkedList<>();
        this.references.addAll(labeledReferences);
        this.references.addAll(unlabeledReferences);
    }

    /**
     * As list list.
     *
     * @return all the current labeled and unlabeled references
     */
    public List<String> asList() {
        return new LinkedList<>(references);
    }

    private Optional<Matcher> labeledReferenceMatcher(String ref) {
        final var matcher = isLabeledReferencePattern.matcher(ref);
        if (matcher.matches() && whitelist.contains(matcher.group(1))) {
            return Optional.of(matcher);
        }
        return Optional.empty();
    }

    private static Function<String, String> withLabel(String label) {
        return value -> withLabel(label, value);
    }

    private static String withLabel(String label, String value) {
        return String.format("/%s/%s", label, value);
    }
}
