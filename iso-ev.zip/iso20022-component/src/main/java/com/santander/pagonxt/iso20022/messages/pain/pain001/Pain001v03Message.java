package com.santander.pagonxt.iso20022.messages.pain.pain001;

import com.santander.pagonxt.iso20022.core.Iso20022Message;
import com.santander.pagonxt.iso20022.core.Iso20022MessageAccessor;
import com.santander.pagonxt.iso20022.core.Iso2022MessageValidator;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.Document;

/**
 * The type Pain 001 v 03 message.
 */
public class Pain001v03Message extends Iso20022Message<Document> {

    private static final String MESSAGE_DEFINITION = "pain.001.001.03";
    private static final String DEFINITION_PATH = "/model/messages/pain/" + MESSAGE_DEFINITION + ".xsd";

    /**
     * Instantiates a new Pain 001 v 03 message.
     *
     * @param document the document
     */
    public Pain001v03Message(Document document) {
        super(document);
    }

    @Override
    public Iso20022MessageAccessor<Document> getAccessor() {
        return new Pain001v03Accessor(document);
    }

    @Override
    public void validateMessage() {
        final Iso2022MessageValidator<Document> validator = new Iso2022MessageValidator(MESSAGE_DEFINITION, DEFINITION_PATH);
        validator.validateDocument(document);
    }
}
