package com.santander.pagonxt.iso20022.messages.pacs.pacs004;

import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.codes.ChargeBearer;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.fields.ReasonInfo;
import com.santander.pagonxt.iso20022.common.fields.RemittanceInformation;
import com.santander.pagonxt.iso20022.common.fields.SchemeInfo;
import com.santander.pagonxt.iso20022.core.Iso20022MessageBuilder;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.ActiveCurrencyAndAmount;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.ActiveOrHistoricCurrencyAndAmount;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Authorisation1Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.BranchAndFinancialInstitutionIdentification6;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.CashAccount38;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.ChargeBearerType1Code;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.ClearingSystemIdentification3Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.CreditorReferenceInformation2;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Document;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.GroupHeader90;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.MandateRelatedInformation14;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.OriginalGroupHeader18;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.OriginalTransactionReference28;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Party40Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PartyIdentification135;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PaymentReturnReason6;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PaymentReturnV09;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PaymentTransaction112;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.PaymentTypeInformation27;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.RemittanceInformation16;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.ReturnReason5Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.ServiceLevel8Choice;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.SettlementInstruction7;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.SettlementMethod1Code;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.StructuredRemittanceInformation16;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.TransactionParties7;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static com.santander.pagonxt.iso20022.common.helper.AccessorHelper.firstInList;
import static com.santander.pagonxt.iso20022.common.helper.BuilderHelper.createBankAccount;
import static com.santander.pagonxt.iso20022.common.helper.BuilderHelper.createFinancialInstitution;
import static com.santander.pagonxt.iso20022.common.helper.BuilderHelper.fillAmount;
import static com.santander.pagonxt.iso20022.common.helper.BuilderHelper.fillPartyIdentification;
import static com.santander.pagonxt.iso20022.common.helper.BuilderHelper.getOrCreatePositionInList;
import static java.util.Arrays.asList;
import static java.util.Collections.singletonList;
import static java.util.Optional.of;
import static java.util.Optional.ofNullable;
import static java.util.function.Predicate.not;
import static org.apache.commons.lang3.StringUtils.isAllBlank;
import static org.apache.commons.lang3.StringUtils.isNotBlank;
import static org.codehaus.plexus.util.StringUtils.isBlank;

public class Pacs004v09Builder extends Iso20022MessageBuilder<Document> {

    public Pacs004v09Builder() {
        scaffoldDocument();
    }

    @Override
    public Pacs004v09Message build() {
        Pacs004v09Message pacs004v09Message = new Pacs004v09Message(document);
        pacs004v09Message.validateMessage();
        return pacs004v09Message;
    }

    @Override
    public Pacs004v09Builder messageId(String messageId) {
        if (isBlank(messageId)) {
            return this;
        }
        groupHeader().setMsgId(messageId);
        return this;
    }

    @Override
    public Pacs004v09Builder originalMessageId(String originalMessageId) {
        if (isBlank(originalMessageId)) {
            return this;
        }
        originalGroupInfo().setOrgnlMsgId(originalMessageId);
        return this;
    }

    @Override
    public Pacs004v09Builder originalMessageNameId(String originalMessageNameId) {
        if (isBlank(originalMessageNameId)) {
            return this;
        }
        originalGroupInfo().setOrgnlMsgNmId(originalMessageNameId);
        return this;
    }

    @Override
    public Pacs004v09Builder amount(MonetaryAmount amount) {
        if (amount == null) {
            return this;
        }
        final ActiveCurrencyAndAmount activeCurrencyAndAmount = new ActiveCurrencyAndAmount();
        activeCurrencyAndAmount.setCcy(amount.getCurrency().getCurrencyCode());
        activeCurrencyAndAmount.setValue(BigDecimal.valueOf(amount.getNumber().doubleValue()));
        firstTransaction().setRtrdIntrBkSttlmAmt(activeCurrencyAndAmount);
        return this;
    }

    @Override
    public Pacs004v09Builder instructionId(String instructionId) {
        if (isBlank(instructionId)) return this;
        this.firstTransaction().setOrgnlInstrId(instructionId);
        return this;
    }

    @Override
    public Pacs004v09Builder transactionId(String transactionId) {
        if (isBlank(transactionId)) return this;
        firstTransaction().setRtrId(transactionId);
        return this;
    }

    @Override
    public Pacs004v09Builder transactionReference(String txRef) {
        if (isBlank(txRef)) return this;
        firstTransaction().setClrSysRef(txRef);
        return this;
    }

    @Override
    public Pacs004v09Builder endToEndId(String endToEndId) {
        if (isBlank(endToEndId)) endToEndId = "NOT PROVIDED";
        firstTransaction().setOrgnlEndToEndId(endToEndId);
        return this;
    }

    @Override
    public Pacs004v09Builder uetr(UUID uetr) {
        if (uetr == null) return this;
        this.firstTransaction().setOrgnlUETR(String.valueOf(uetr));
        return this;
    }

    @Override
    public Pacs004v09Builder debtorAccount(BankAccount account) {
        if (account == null) return this;
        originalTransactionReference().setDbtrAgt(createFinancialInstitution(account.getAgent(), BranchAndFinancialInstitutionIdentification6.class));
        originalTransactionReference().setDbtrAcct(createBankAccount(account, CashAccount38.class));
        return this;
    }

    @Override
    public Pacs004v09Builder debtor(PartyIdentification partyIdentification) {
        if (partyIdentification == null) return this;
        debtor().setPty(fillPartyIdentification(partyIdentification, PartyIdentification135.class));
        return this;
    }

    @Override
    public Pacs004v09Builder creditor(PartyIdentification partyIdentification) {
        if (partyIdentification == null) return this;
        creditor().setPty(fillPartyIdentification(partyIdentification, PartyIdentification135.class));
        return this;
    }

    @Override
    public Pacs004v09Builder creditorAccount(BankAccount account) {
        if (account == null) return this;
        originalTransactionReference().setCdtrAgt(createFinancialInstitution(account.getAgent(), BranchAndFinancialInstitutionIdentification6.class));
        originalTransactionReference().setCdtrAcct(createBankAccount(account, CashAccount38.class));
        return this;
    }

    @Override
    public Pacs004v09Builder debtorReferences(String... debtorReference) {
        if (isAllBlank(debtorReference)) return this;
        remittanceInformation().getUstrds().clear();
        remittanceInformation().getUstrds().addAll(List.of(debtorReference));
        return this;
    }

    @Override
    public Pacs004v09Builder creditorReferences(String... creditorReference) {
        if (isAllBlank(creditorReference)) return this;
        for (int i = 0; i < creditorReference.length; i++) {
            getCreditorReferenceInformation2(i).setRef(creditorReference[i]);
        }
        return this;
    }

    @Override
    public Pacs004v09Builder paymentScheme(String paymentScheme) {
        if (isBlank(paymentScheme)) return this;
        svcLvl().setPrtry(paymentScheme);
        return this;
    }

    @Override
    public Pacs004v09Builder schemeId(SchemeInfo schemeInfo) {
        if (schemeInfo == null || isBlank(schemeInfo.getSchemeId())) return this;
        strd(0).getAddtlRmtInves().add(schemeInfo.getSchemeId());
        return this;
    }

    @Override
    public Pacs004v09Builder groupOriginalMessageId(String originalMessageId) {
        if (isBlank(originalMessageId)) return this;
        originalGroupInfo().setOrgnlMsgId(originalMessageId);
        return this;
    }

    @Override
    public Pacs004v09Builder groupOriginalMessageNameId(String originalMessageNmId) {
        if (isBlank(originalMessageNmId)) return this;
        originalGroupInfo().setOrgnlMsgNmId(originalMessageNmId);
        return this;
    }

    @Override
    public Pacs004v09Builder groupReturnReason(ReasonInfo reasonInfo) {
        if (reasonInfo == null) return this;
        final ReturnReason5Choice returnReason5Choice = Optional.of(rtrRsnInf())
                .map(PaymentReturnReason6::getRsn)
                .orElse(new ReturnReason5Choice());

        setCdOrPrtryIn(returnReason5Choice, reasonInfo);

        rtrRsnInf().setRsn(returnReason5Choice);

        final List<String> addtlInf = rtrRsnInf().getAddtlInves();
        addtlInf.set(0, isBlank(reasonInfo.getRawCode()) ? null : reasonInfo.getRawCode());
        addtlInf.set(1, isBlank(reasonInfo.getRawDescription()) ? null : reasonInfo.getRawDescription());

        addtlInf.clear();
        addtlInf.addAll(reasonInfo.getAdditionalInformation().extraInfo());
        return this;
    }

    @Override
    public Pacs004v09Builder returnReason(ReasonInfo reasonInfo) {
        if (reasonInfo == null) return this;
        PaymentReturnReason6 returnReason = Optional.of(firstTransaction())
                .map(PaymentTransaction112::getRtrRsnInves)
                .map(firstInList())
                .orElse(new PaymentReturnReason6());


        ReturnReason5Choice returnReason5Choice = new ReturnReason5Choice();
        setCdOrPrtryIn(returnReason5Choice, reasonInfo);
        returnReason.setRsn(returnReason5Choice);

        final List<String> addtlInf = returnReason.getAddtlInves();
        if (addtlInf.isEmpty()) {
            addtlInf.addAll(asList(null, null));
        }
        addtlInf.set(0, isBlank(reasonInfo.getRawCode()) ? null : reasonInfo.getRawCode());
        addtlInf.set(1, isBlank(reasonInfo.getRawDescription()) ? null : reasonInfo.getRawDescription());
        addtlInf.addAll(reasonInfo.getAdditionalInformation().extraInfo());
        returnReason.getAddtlInves().addAll(addtlInf);

        firstTransaction().getRtrRsnInves().add(returnReason);
        return this;
    }

    @Override
    public Pacs004v09Builder requestedCollectionDate(LocalDate originalProcessingDate) {
        originalTransactionReference().setReqdColltnDt(originalProcessingDate);
        return this;
    }

    @Override
    public Pacs004v09Builder tppId(String tppid) {
        if (isBlank(tppid)) return this;

        MandateRelatedInformation14 getMndtRltdInf = Optional.of(originalTransactionReference())
                .map(OriginalTransactionReference28::getMndtRltdInf)
                .orElse(new MandateRelatedInformation14());

        getMndtRltdInf.setElctrncSgntr(tppid);
        originalTransactionReference().setMndtRltdInf(getMndtRltdInf);
        return this;
    }

    @Override
    public Pacs004v09Builder remittanceInformation(RemittanceInformation remittanceInformation) {
        if (remittanceInformation == null) return this;
        final String reference = remittanceInformation.getReference();
        final String unstructured = remittanceInformation.getUnstructured();
        if (isBlank(reference) && isBlank(remittanceInformation.getUnstructured())) {
            return this;
        }
        strd(0).getAddtlRmtInves().add(isNotBlank(reference) ? reference : " ");
        strd(0).getAddtlRmtInves().add(isNotBlank(unstructured) ? remittanceInformation.getUnstructured() : " ");
        return this;
    }

    @Override
    public Pacs004v09Builder authorisation(String auth) {
        authstn().get(0).setPrtry(auth);
        return this;
    }

    @Override
    public Pacs004v09Builder originalAmount(MonetaryAmount originalAmount) {
        if (originalAmount != null) {
            firstTransaction().setOrgnlIntrBkSttlmAmt(fillAmount(originalAmount, ActiveOrHistoricCurrencyAndAmount.class));
        }
        return this;
    }

    @Override
    public Pacs004v09Builder xchgRate(BigDecimal xchgRate) {
        this.firstTransaction().setXchgRate(xchgRate);
        return this;
    }

    @Override
    public Pacs004v09Builder compensationAmount(MonetaryAmount monetaryAmount) {
        this.firstTransaction().setCompstnAmt(fillAmount(monetaryAmount, ActiveOrHistoricCurrencyAndAmount.class));
        return this;
    }

    @Override
    public Pacs004v09Builder chargeBearer(ChargeBearer chargeBearer) {
        if (chargeBearer == null) return this;
        firstTransaction().setChrgBr(ChargeBearerType1Code.fromValue(chargeBearer.name()));
        return this;
    }

    @Override
    public Pacs004v09Builder groupInterBankSettlementDate(LocalDate date) {
        this.groupHeader().setIntrBkSttlmDt(date);
        return this;
    }

    @Override
    public Pacs004v09Builder interBankSttlmDate(LocalDate date) {
        this.firstTransaction().setIntrBkSttlmDt(date);
        return this;
    }

    @Override
    public Pacs004v09Builder originalTxInternationalBankSettlementDate(LocalDate orgnlTxRefIntrBkSttlmDt) {
        if (orgnlTxRefIntrBkSttlmDt == null) return this;
        this.originalTransactionReference().setIntrBkSttlmDt(orgnlTxRefIntrBkSttlmDt);
        return this;
    }

    @Override
    public Pacs004v09Builder txPartiesUltimateDebtor(PartyIdentification ultimateDebtor) {
        if (ultimateDebtor == null) return this;
        txPartiesUltimateDebtor().setPty(fillPartyIdentification(ultimateDebtor, PartyIdentification135.class));
        return this;
    }

    @Override
    public Pacs004v09Builder txPartiesDebtor(PartyIdentification debtor) {
        if (debtor == null) return this;
        txPartiesDebtor().setPty(fillPartyIdentification(debtor, PartyIdentification135.class));
        return this;
    }

    @Override
    public Pacs004v09Builder txPartiesDebtorAgent(BankAccount.Agent debtorAgent) {
        if (debtorAgent == null) return this;
        rtrChain().setDbtrAgt(createFinancialInstitution(debtorAgent, BranchAndFinancialInstitutionIdentification6.class));
        return this;
    }

    @Override
    public Pacs004v09Builder txPartiesUltimateCreditor(PartyIdentification ultimateCreditor) {
        if (ultimateCreditor == null) return this;
        txPartiesUltimateCreditor().setPty(fillPartyIdentification(ultimateCreditor, PartyIdentification135.class));
        return this;
    }

    @Override
    public Pacs004v09Builder txPartiesCreditor(PartyIdentification creditor) {
        if (creditor == null) return this;
        txPartiesCreditor().setPty(fillPartyIdentification(creditor, PartyIdentification135.class));
        return this;
    }

    @Override
    public Pacs004v09Builder txPartiesCreditorAgent(BankAccount.Agent creditorAgent) {
        if (creditorAgent == null) return this;
        rtrChain().setCdtrAgt(createFinancialInstitution(creditorAgent, BranchAndFinancialInstitutionIdentification6.class));
        return this;
    }

    @Override
    public Pacs004v09Builder controlSum(BigDecimal controlSum) {
        if (controlSum == null) return this;
        groupHeader().setCtrlSum(controlSum);
        return this;
    }

    @Override
    public Pacs004v09Builder clearingSystemCode(String clearingSystemCode) {
        ofNullable(clearingSystemCode)
                .map(code -> {
                    final ClearingSystemIdentification3Choice clearingSystemIdentification3Choice =
                            new ClearingSystemIdentification3Choice();
                    clearingSystemIdentification3Choice.setCd(code);
                    return clearingSystemIdentification3Choice;
                })
                .ifPresent(groupHeader().getSttlmInf()::setClrSys);
        return this;
    }

    @Override
    public Pacs004v09Builder clearingSystemProprietary(String clearingSystemProprietary) {
        ofNullable(clearingSystemProprietary)
                .map(code -> {
                    final ClearingSystemIdentification3Choice clearingSystemIdentification3Choice =
                            new ClearingSystemIdentification3Choice();
                    clearingSystemIdentification3Choice.setPrtry(code);
                    return clearingSystemIdentification3Choice;
                })
                .ifPresent(groupHeader().getSttlmInf()::setClrSys);
        return this;
    }

    private void scaffoldDocument() {
        document = new Document();
        final PaymentReturnV09 paymentReturnV09 = new PaymentReturnV09();
        final GroupHeader90 groupHeader90 = new GroupHeader90();
        final SettlementInstruction7 settlementInstruction7 = new SettlementInstruction7();

        settlementInstruction7.setSttlmMtd(SettlementMethod1Code.CLRG);

        groupHeader90.setCreDtTm(LocalDateTime.now());
        groupHeader90.setNbOfTxs("0");
        groupHeader90.setSttlmInf(settlementInstruction7);

        paymentReturnV09.setGrpHdr(groupHeader90);

        document.setPmtRtr(paymentReturnV09);
    }

    private PaymentReturnV09 pmtRtr() {
        return document.getPmtRtr();
    }

    private GroupHeader90 groupHeader() {
        final GroupHeader90 groupHeader90 = ofNullable(pmtRtr())
                .map(PaymentReturnV09::getGrpHdr)
                .orElse(new GroupHeader90());

        pmtRtr().setGrpHdr(groupHeader90);
        return groupHeader90;
    }

    private OriginalGroupHeader18 originalGroupInfo() {
        final OriginalGroupHeader18 originalGroupHeader18 = ofNullable(pmtRtr())
                .map(PaymentReturnV09::getOrgnlGrpInf)
                .orElse(new OriginalGroupHeader18());

        pmtRtr().setOrgnlGrpInf(originalGroupHeader18);
        return originalGroupHeader18;
    }

    private PaymentTransaction112 firstTransaction() {
        final PaymentTransaction112 paymentTransaction112 = Optional.of(pmtRtr())
                .map(PaymentReturnV09::getTxInves)
                .map(firstInList())
                .orElse(new PaymentTransaction112());

        if (pmtRtr().getTxInves().isEmpty()) {
            pmtRtr().getTxInves().add(paymentTransaction112);
            groupHeader().setNbOfTxs("1");
        }
        return paymentTransaction112;
    }

    private OriginalTransactionReference28 originalTransactionReference() {
        OriginalTransactionReference28 originalTransactionReference28 = Optional.of(firstTransaction())
                .map(PaymentTransaction112::getOrgnlTxRef)
                .orElse(new OriginalTransactionReference28());
        firstTransaction().setOrgnlTxRef(originalTransactionReference28);
        return originalTransactionReference28;
    }

    private Party40Choice creditor() {
        Party40Choice party40Choice = Optional.of(originalTransactionReference())
                .map(OriginalTransactionReference28::getCdtr)
                .orElse(new Party40Choice());
        originalTransactionReference().setCdtr(party40Choice);
        return party40Choice;
    }

    private Party40Choice debtor() {
        Party40Choice party40Choice = Optional.of(originalTransactionReference())
                .map(OriginalTransactionReference28::getDbtr)
                .orElse(new Party40Choice());
        originalTransactionReference().setDbtr(party40Choice);
        return party40Choice;
    }

    private RemittanceInformation16 remittanceInformation() {
        RemittanceInformation16 remittanceInformation16 = Optional.of(originalTransactionReference())
                .map(OriginalTransactionReference28::getRmtInf)
                .orElse(new RemittanceInformation16());
        originalTransactionReference().setRmtInf(remittanceInformation16);
        return remittanceInformation16;
    }

    private CreditorReferenceInformation2 getCreditorReferenceInformation2(int position) {
        StructuredRemittanceInformation16 strd = strd(position);
        CreditorReferenceInformation2 creditorReferenceInformation2 = Optional.of(strd)
                .map(StructuredRemittanceInformation16::getCdtrRefInf)
                .orElse(new CreditorReferenceInformation2());

        strd.setCdtrRefInf(creditorReferenceInformation2);
        return creditorReferenceInformation2;
    }

    private StructuredRemittanceInformation16 strd(int position) {
        List<StructuredRemittanceInformation16> structuredRemittanceInformation16s = Optional.of(remittanceInformation())
                .map(RemittanceInformation16::getStrds)
                .filter(not(List::isEmpty))
                .orElse(new ArrayList<>());

        StructuredRemittanceInformation16 strd = Optional.of(structuredRemittanceInformation16s)
                .map(getOrCreatePositionInList(position, StructuredRemittanceInformation16::new))
                .orElse(new StructuredRemittanceInformation16());

        remittanceInformation().getStrds().clear();
        remittanceInformation().getStrds().addAll(structuredRemittanceInformation16s);
        return strd;
    }

    private ServiceLevel8Choice svcLvl() {
        ServiceLevel8Choice serviceLevel8Choice = Optional.of(pmtTpInf())
                .map(PaymentTypeInformation27::getSvcLvls)
                .map(firstInList())
                .orElse(new ServiceLevel8Choice());
        pmtTpInf().getSvcLvls().clear();
        pmtTpInf().getSvcLvls().addAll(List.of(serviceLevel8Choice));
        return serviceLevel8Choice;
    }

    private PaymentTypeInformation27 pmtTpInf() {
        PaymentTypeInformation27 paymentTypeInformation27 = Optional.of(originalTransactionReference())
                .map(OriginalTransactionReference28::getPmtTpInf)
                .orElse(new PaymentTypeInformation27());
        originalTransactionReference().setPmtTpInf(paymentTypeInformation27);
        return paymentTypeInformation27;

    }

    private PaymentReturnReason6 rtrRsnInf() {
        List<PaymentReturnReason6> paymentReturnReason6List = originalGroupInfo().getRtrRsnInves();
        if (paymentReturnReason6List.isEmpty()) {
            paymentReturnReason6List.add(new PaymentReturnReason6());
        }
        final PaymentReturnReason6 paymentReturnReason6 = paymentReturnReason6List.get(0);
        if (paymentReturnReason6.getAddtlInves().isEmpty()) {
            paymentReturnReason6.getAddtlInves().addAll(asList(null, null));
        }
        originalGroupInfo().getRtrRsnInves().clear();
        originalGroupInfo().getRtrRsnInves().addAll(paymentReturnReason6List);
        return paymentReturnReason6;
    }

    private void setCdOrPrtryIn(ReturnReason5Choice returnReason5Choice, ReasonInfo reasonInfo) {
        if (reasonInfo.getCode().isProprietary()) {
            returnReason5Choice.setPrtry(reasonInfo.getCode().toString());
        } else {
            returnReason5Choice.setCd(reasonInfo.getCode().toString());
        }
    }

    private List<Authorisation1Choice> authstn() {
        List<Authorisation1Choice> authorisation1Choices = Optional.of(groupHeader())
                .map(GroupHeader90::getAuthstns)
                .orElse(singletonList(new Authorisation1Choice()));

        if (authorisation1Choices.isEmpty()) {
            authorisation1Choices.add(new Authorisation1Choice());
        }

        return authorisation1Choices;
    }

    private TransactionParties7 rtrChain() {
        TransactionParties7 transactionParties7 = of(firstTransaction())
                .map(PaymentTransaction112::getRtrChain)
                .orElse(new TransactionParties7());

        firstTransaction().setRtrChain(transactionParties7);
        return transactionParties7;
    }

    private Party40Choice txPartiesUltimateDebtor() {
        Party40Choice party40Choice = Optional.of(rtrChain())
                .map(TransactionParties7::getUltmtDbtr)
                .orElse(new Party40Choice());
        rtrChain().setUltmtDbtr(party40Choice);
        return party40Choice;
    }

    private Party40Choice txPartiesDebtor() {
        Party40Choice party40Choice = Optional.of(rtrChain())
                .map(TransactionParties7::getDbtr)
                .orElse(new Party40Choice());
        rtrChain().setDbtr(party40Choice);
        return party40Choice;
    }

    private Party40Choice txPartiesUltimateCreditor() {
        Party40Choice party40Choice = Optional.of(rtrChain())
                .map(TransactionParties7::getUltmtCdtr)
                .orElse(new Party40Choice());
        rtrChain().setUltmtCdtr(party40Choice);
        return party40Choice;
    }

    private Party40Choice txPartiesCreditor() {
        Party40Choice party40Choice = Optional.of(rtrChain())
                .map(TransactionParties7::getCdtr)
                .orElse(new Party40Choice());
        rtrChain().setCdtr(party40Choice);
        return party40Choice;
    }

}
