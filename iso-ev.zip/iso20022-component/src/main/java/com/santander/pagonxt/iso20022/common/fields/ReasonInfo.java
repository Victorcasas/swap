package com.santander.pagonxt.iso20022.common.fields;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.santander.pagonxt.iso20022.common.codes.ExternalCode;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.NonNull;
import lombok.ToString;
import lombok.Value;
import org.apache.commons.lang3.StringUtils;

import java.beans.ConstructorProperties;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import static org.apache.commons.lang3.StringUtils.abbreviate;
import static org.apache.commons.lang3.StringUtils.isNoneBlank;

// todo should we rename the ReasonInfo to something else?
@Value
public class ReasonInfo {

    public static final int MAX_WIDTH = 105;

    @NonNull ExternalCode code;
    @NonNull String rawCode;
    @NonNull String rawDescription;
    AdditionalInformation additionalInformation;

    @Builder
    @JsonCreator
    @ConstructorProperties({"code", "rawCode", "rawDescription", "additionalInformation"})
    public ReasonInfo(@NonNull ExternalCode code, @NonNull String rawCode, @NonNull String rawDescription, AdditionalInformation additionalInformation) {
        this.code = code;
        this.rawCode = abbreviate(rawCode, MAX_WIDTH);
        this.rawDescription = abbreviate(rawDescription, MAX_WIDTH);
        this.additionalInformation = additionalInformation == null ? AdditionalInformation.additionalInformation() : additionalInformation;
    }

    @ToString
    @EqualsAndHashCode
    public static class AdditionalInformation {
        /*
         * number of positions in the AddtlInf Iso20022 message field reserved
         * for other purposes (rawCode, rawDescription, schemeId, tppId)
         */
        public static final int RESERVED_POSITIONS = 4;
        private List<String> extraInfo = new ArrayList<>();

        private AdditionalInformation() {
        }

        public static AdditionalInformation additionalInformation() {
            return new AdditionalInformation();
        }

        public AdditionalInformation add(String extra) {
            if (isNoneBlank(extra)) {
                extraInfo.add(extra);
            }
            return this;
        }

        public AdditionalInformation extraInfo(List<String> extraInfo) {
            this.extraInfo = extraInfo == null ? new ArrayList<>() : extraInfo.stream().filter(StringUtils::isNoneBlank)
                    .collect(Collectors.toList());
            return this;
        }

        public List<String> extraInfo() {
            return extraInfo;
        }

        public List<String> getExtraInfo() {
            return extraInfo;
        }

        public void setExtraInfo(List<String> extraInfo) {
            this.extraInfo = extraInfo;
        }
    }
}
