package com.santander.pagonxt.iso20022.common.fields;

import com.santander.pagonxt.iso20022.common.codes.ExternalCode;

public enum ReturnReason implements ExternalCode {
    AC01("IncorrectAccountNumber", "Format of the account number specified is not correct"),
    AC03("InvalidCreditorAccountNumber", "Wrong IBAN in SCT"),
    AC04("ClosedAccountNumber", "Account number specified has been closed on the bank of account's books"),
    AC06("BlockedAccount", "Account specified is blocked, prohibiting posting of transactions against it."),
    AC13("InvalidDebtorAccountType", "Debtor account type is missing or invalid"),
    AC14("InvalidAgent", "An agent in the payment chain is invalid."),
    AC15("AccountDetailsChanged", "Account details have changed."),
    AC16("AccountInSequestration", "Account is in sequestration."),
    AC17("AccountInLiquidation", "Account is in liquidation."),
    AG01("TransactionForbidden", "Transaction forbidden on this type of account (formerly NoAgreement)"),
    AG02("InvalidBankOperationCode", "Bank Operation code specified in the message is not valid for receiver"),
    AM01("ZeroAmount", "Specified message amount is equal to zero"),
    AM02("NotAllowedAmount", "Specific transaction/message amount is greater than allowed maximum"),
    AM03("NotAllowedCurrency", "Specified message amount is an non processable currency outside of existing agreement"),
    AM04("InsufficientFunds", "Amount of funds available to cover specified message amount is insufficient."),
    AM05("Duplication", "Duplication"),
    AM06("TooLowAmount", "Specified transaction amount is less than agreed minimum."),
    AM07("BlockedAmount", "Amount specified in message has been blocked by regulatory authorities."),
    AM09("WrongAmount", "Amount received is not the amount agreed or expected"),
    AM10("InvalidControlSum", "Sum of instructed amounts does not equal the control sum."),
    ARDT("AlreadyReturnedTransaction", "Already returned original SCT"),
    BE01("InconsistenWithEndCustomer", "Identification of end customer is not consistent with associated account number (formerly CreditorConsistency)."),
    BE04("MissingCreditorAddress", "Specification of creditor's address, which is required for payment, is missing/not correct (formerly IncorrectCreditorAddress)."),
    BE05("UnrecognisedInitiatingParty", "Party who initiated the message is not recognised by the end customer"),
    BE06("UnknownEndCustomer", "End customer specified is not known at associated Sort/National Bank Code or does no longer exist in the books"),
    BE07("MissingDebtorAddress", "Specification of debtor's address, which is required for payment, is missing/not correct."),
    BE08("BankError", "Returned as a result of a bank error."),
    CN01("AuthorisationCancelled", "Authorisation is cancelled."),
    CNOR("CreditorBankIsNotRegistered ", "Creditor bank is not registered under this BIC in the CSM"),
    CURR("IncorrectCurrency", "Currency of the payment is incorrect"),
    CUST("RequestedByCustomer", "Cancellation requested by the Debtor"),
    DNOR("DebtorBankIsNotRegistered", "Debtor bank is not registered under this BIC in the CSM"),
    DS28("ReturnForTechnicalReason", "Return following technical problems resulting in erroneous transaction."),
    DT01("InvalidDate", "Invalid date (eg, wrong settlement date)"),
    ED01("CorrespondentBankNotPossible", "Correspondent bank not possible."),
    ED03("BalanceInfoRequest", "Balance of payments complementary info is requested"),
    ED05("SettlementFailed", "Settlement of the transaction has failed."),
    EMVL("EMVLiabilityShift", "The card payment is fraudulent and was not processed with EMV technology for an EMV card. "),
    ERIN("ERIOptionNotSupported", "The Extended Remittance Information (ERI) option is not supported."),
    FF05("InvalidLocalInstrumentCode", "Local Instrument code is missing or invalid"),
    FOCR("FollowingCancellationRequest", "Return following a cancellation request"),
    FR01("Fraud", "Returned as a result of fraud."),
    FRTR("FinalResponseMandateCancelled", "Final response/tracking is recalled as mandate is cancelled."),
    MD01("NoMandate", "No Mandate"),
    MD02("MissingMandatoryInformationInMandate", "Mandate related information data required by the scheme is missing."),
    MD06("RefundRequestByEndCustomer", "Return of funds requested by end customer"),
    MD07("EndCustomerDeceased", "End customer is deceased."),
    MS02("NotSpecifiedReasonCustomerGenerated", "Reason has not been specified by end customer"),
    MS03("NotSpecifiedReasonAgentGenerated", "Reason has not been specified by agent."),
    NARR("Narrative", "Reason is provided as narrative information in the additional reason information."),
    NOAS("NoAnswerFromCustomer", "No response from Beneficiary"),
    NOCM("NotCompliant", "Customer account is not compliant with regulatory requirements, for example FICA (in South Africa) or any other regulatory requirements which render an account inactive for certain processing."),
    NOOR("NoOriginalTransactionReceived", "Original SCT never received"),
    PINL("PINLiabilityShift", "The card payment is fraudulent (lost and stolen fraud) and was processed as EMV transaction without PIN verification."),
    RC01("BankIdentifierIncorrect", "Bank Identifier code specified in the message has an incorrect format (formerly IncorrectFormatForRoutingCode)."),
    RC07("InvalidCreditorBICIdentifier ", "Incorrrect BIC of the beneficiary Bank in the SCTR"),
    RF01("NotUniqueTransactionReference", "Transaction reference is not unique within the message."),
    RR01("MissingDebtorAccountOrIdentification", "Specification of the debtor’s account or unique identification needed for reasons of regulatory requirements is insufficient or missing"),
    RR02("MissingDebtorNameOrAddress", "Specification of the debtor’s name and/or address needed for regulatory requirements is insufficient or missing."),
    RR03("MissingCreditorNameOrAddress", "Specification of the creditor’s name and/or address needed for regulatory requirements is insufficient or missing."),
    RR04("RegulatoryReason ", "Regulatory Reason"),
    RUTA("ReturnUponUnableToApply", "Return following investigation request and no remediation possible."),
    SL01("SpecificServiceOfferedByDebtorAgent", "Due to specific service offered by the Debtor Agent"),
    SL02("SpecificServiceOfferedByCreditorAgent", "Due to specific service offered by the Creditor Agent"),
    SL11("CreditorNotOnWhitelistOfDebtor", "Whitelisting service offered by the Debtor Agent; Debtor has not included the Creditor on its “Whitelist“ (yet). In the Whitelist the Debtor may list all allowed Creditors to debit Debtor bank account."),
    SL12("CreditorOnBlacklistOfDebtor", "Blacklisting service offered by the Debtor Agent; Debtor included the Creditor on his “Blacklist“. In the Blacklist the Debtor may list all Creditors not allowed to debit Debtor bank account."),
    SL13("MaximumNumberOfDirectDebitTransactionsExceeded", "Due to Maximum allowed Direct Debit Transactions per period service offered by the Debtor Agent."),
    SL14("MaximumDirectDebitTransactionAmountExceeded", "Due to Maximum allowed Direct Debit Transaction amount service offered by the Debtor Agent."),
    SP01("PaymentStopped", "Payment is stopped by account holder."),
    SP02("PreviouslyStopped", "Previously stopped by means of a stop payment advise."),
    SVNR("ServiceNotRendered", "The card payment is returned since a cash amount rendered was not correct or goods or a service was not rendered to the customer, e.g. in an e-commerce situation."),
    TM01("CutOffTime", "Associated message was received after agreed processing cut-off time."),
    TRAC("RemovedFromTracking", "Return following direct debit being removed from tracking process."),
    UPAY("UnduePayment", "Payment is not justified."),

    /**
     * ***** DO NOT USE THE CODES BELOW *****
     *
     * @deprecated These codes serve a very specific purpose for Olympics project and should not be used in any other scenario.
     * FIXME Codes to be removed as part of chore #176609733.
     */
    @Deprecated
    AB01("AbortedClearingTimeout", "Clearing process aborted due to timeout."),
    @Deprecated
    AB02("AbortedClearingFatalError", "Clearing process aborted due to a fatal error."),
    @Deprecated
    AB03("AbortedSettlementTimeout", "Settlement aborted due to timeout."),
    @Deprecated
    AB04("AbortedSettlementFatalError", "Settlement process aborted due to a fatal error."),
    @Deprecated
    AB05("TimeoutCreditorAgent", "Transaction stopped due to timeout at the Creditor Agent."),
    @Deprecated
    AB06("TimeoutInstructedAgent", "Transaction stopped due to timeout at the Instructed Agent."),
    @Deprecated
    AB07("OfflineAgent", "Agent of message is not online. Generic usage if it cannot be determined who exactly is not online."),
    @Deprecated
    AB08("OfflineCreditorAgent", "Creditor Agent is not online."),
    @Deprecated
    AB09("ErrorCreditorAgent", "Transaction stopped due to error at the Creditor Agent."),
    @Deprecated
    AB10("ErrorInstructedAgent", "Transaction stopped due to error at the Instructed Agent."),
    @Deprecated
    AB11("TimeoutDebtorAgent", "Transaction stopped due to timeout at the Debtor Agent."),
    @Deprecated
    AC02("InvalidDebtorAccountNumber", "Debtor account number invalid or missing"),
    @Deprecated
    AC05("ClosedDebtorAccountNumber", "Debtor account number closed"),
    @Deprecated
    AC07("ClosedCreditorAccountNumber", "Creditor account number closed"),
    @Deprecated
    AC08("InvalidBranchCode", "Branch code is invalid or missing"),
    @Deprecated
    AC09("InvalidAccountCurrency", "Account currency is invalid or missing"),
    @Deprecated
    AC10("InvalidDebtorAccountCurrency", "Debtor account currency is invalid or missing"),
    @Deprecated
    AC11("InvalidCreditorAccountCurrency", "Creditor account currency is invalid or missing"),
    @Deprecated
    AC12("InvalidAccountType", "Account type missing or invalid. Generic usage if cannot specify between group and payment information levels"),
    @Deprecated
    AG03("TransactionNotSupported", "Transaction type not supported/authorized on this account"),
    @Deprecated
    AG04("InvalidAgentCountry", "Agent country code is missing or invalid. Generic usage if cannot specify between group and payment information levels."),
    @Deprecated
    AG05("InvalidDebtorAgentCountry", "Debtor agent country code is missing or invalid"),
    @Deprecated
    AG06("InvalidCreditorAgentCountry", "Creditor agent country code is missing or invalid"),
    @Deprecated
    AG07("UnsuccesfulDirectDebit", "Debtor account cannot be debited for a generic reason. Code value may be used in general purposes and as a replacement for AM04 if debtor bank does not reveal its customer's insufficient funds for privacy reasons"),
    @Deprecated
    AG08("InvalidAccessRights", "Transaction failed due to invalid or missing user or access right"),
    @Deprecated
    AG09("PaymentNotReceived", "Original payment never received."),
    @Deprecated
    AG10("AgentSuspended", "Agent of message is suspended from the Real Time Payment system. Generic usage if it cannot be determined who exactly is suspended."),
    @Deprecated
    AG11("CreditorAgentSuspended", "Creditor Agent of message is suspended from the Real Time Payment system."),
    @Deprecated
    AG12("NotAllowedBookTransfer", "Payment orders made by transferring funds from one account to another at the same financial institution (bank or payment institution) are not allowed."),
    @Deprecated
    AG13("ForbiddenReturnPayment", "Returned payments derived from previously returned transactions are not allowed."),
    @Deprecated
    AGNT("IncorrectAgent", "Agent in the payment workflow is incorrect"),
    @Deprecated
    AM11("InvalidTransactionCurrency", "Transaction currency is invalid or missing"),
    @Deprecated
    AM12("InvalidAmount", "Amount is invalid or missing"),
    @Deprecated
    AM13("AmountExceedsClearingSystemLimit", "Transaction amount exceeds limits set by clearing system"),
    @Deprecated
    AM14("AmountExceedsAgreedLimit", "Transaction amount exceeds limits agreed between bank and client"),
    @Deprecated
    AM15("AmountBelowClearingSystemMinimum", "Transaction amount below minimum set by clearing system"),
    @Deprecated
    AM16("InvalidGroupControlSum", "Control Sum at the Group level is invalid"),
    @Deprecated
    AM17("InvalidPaymentInfoControlSum", "Control Sum at the Payment Information level is invalid"),
    @Deprecated
    AM18("InvalidNumberOfTransactions", "Number of transactions is invalid or missing. Generic usage if cannot specify between group and payment information levels."),
    @Deprecated
    AM19("InvalidGroupNumberOfTransactions", "Number of transactions at the Group level is invalid or missing"),
    @Deprecated
    AM20("InvalidPaymentInfoNumberOfTransactions", "Number of transactions at the Payment Information level is invalid"),
    @Deprecated
    AM21("LimitExceeded", "Transaction amount exceeds limits agreed between bank and client."),
    @Deprecated
    AM22("ZeroAmountNotApplied", "Unable to apply zero amount to designated account. For example, where the rules of a service allow the use of zero amount payments, however the back-office system is unable to apply the funds to the account. If the rules of a service prohibit the use of zero amount payments, then code AM01 is used to report the error condition."),
    @Deprecated
    AM23("AmountExceedsSettlementLimit", "Transaction amount exceeds settlement limit."),
    @Deprecated
    BE09("InvalidCountry", "Country code is missing or Invalid. Generic usage if cannot specifically identify debtor or creditor"),
    @Deprecated
    BE10("InvalidDebtorCountry", "Debtor country code is missing or invalid"),
    @Deprecated
    BE11("InvalidCreditorCountry", "Creditor country code is missing or invalid"),
    @Deprecated
    BE12("InvalidCountryOfResidence", "Country code of residence is missing or Invalid. Generic usage if cannot specifically identify debtor or creditor"),
    @Deprecated
    BE13("InvalidDebtorCountryOfResidence", "Country code of debtor's residence is missing or Invalid"),
    @Deprecated
    BE14("InvalidCreditorCountryOfResidence", "Country code of creditor's residence is missing or Invalid"),
    @Deprecated
    BE15("InvalidIdentificationCode", "Identification code missing or invalid. Generic usage if cannot specifically identify debtor or creditor."),
    @Deprecated
    BE16("InvalidDebtorIdentificationCode", "Debtor or Ultimate Debtor identification code missing or invalid"),
    @Deprecated
    BE17("InvalidCreditorIdentificationCode", "Creditor or Ultimate Creditor identification code missing or invalid"),
    @Deprecated
    BE18("InvalidContactDetails", "Contact details missing or invalid"),
    @Deprecated
    BE19("InvalidChargeBearerCode", "Charge bearer code for transaction type is invalid"),
    @Deprecated
    BE20("InvalidNameLength", "Name length exceeds local rules for payment type."),
    @Deprecated
    BE21("MissingName", "Name missing or invalid. Generic usage if cannot specifically identify debtor or creditor."),
    @Deprecated
    BE22("MissingCreditorName", "Creditor name is missing"),
    @Deprecated
    CERI("CheckERI", "Credit transfer is not tagged as an Extended Remittance Information (ERI) transaction but contains ERI."),
    @Deprecated
    CH03("RequestedExecutionDateOrRequestedCollectionDateTooFarInFuture", "Value in Requested Execution Date or Requested Collection Date is too far in the future"),
    @Deprecated
    CH04("RequestedExecutionDateOrRequestedCollectionDateTooFarInPast", "Value in Requested Execution Date or Requested Collection Date is too far in the past"),
    @Deprecated
    CH07("ElementIsNotToBeUsedAtB-andC-Level", "Element is not to be used at B- and C-Level"),
    @Deprecated
    CH09("MandateChangesNotAllowed", "Mandate changes are not allowed"),
    @Deprecated
    CH10("InformationOnMandateChangesMissing", "Information on mandate changes are missing"),
    @Deprecated
    CH11("CreditorIdentifierIncorrect", "Value in Creditor Identifier is incorrect"),
    @Deprecated
    CH12("CreditorIdentifierNotUnambiguouslyAtTransaction-Level", "Creditor Identifier is ambiguous at Transaction Level"),
    @Deprecated
    CH13("OriginalDebtorAccountIsNotToBeUsed", "Original Debtor Account is not to be used"),
    @Deprecated
    CH14("OriginalDebtorAgentIsNotToBeUsed", "Original Debtor Agent is not to be used"),
    @Deprecated
    CH15("ElementContentIncludesMoreThan140Charac­ters", "Content Remittance Information/Structured includes more than 140 characters"),
    @Deprecated
    CH16("ElementContentFormallyIncorrect", "Content is incorrect"),
    @Deprecated
    CH17("ElementNotAdmitted", "Element is not allowed"),
    @Deprecated
    CH19("ValuesWillBeSetToNextTARGETday", "Values in Interbank Settlement Date or Requested Collection Date will be set to the next TARGET day"),
    @Deprecated
    CH20("DecimalPointsNotCompatibleWithCurrency", "Number of decimal points not compatible with the currency"),
    @Deprecated
    CH21("RequiredCompulsoryElementMissing", "Mandatory element is missing"),
    @Deprecated
    CH22("COREandB2BwithinOnemessage", "SDD CORE and B2B not permitted within one message"),
    @Deprecated
    DS01("ElectronicSignaturesCorrect", "The electronic signature(s) is/are correct"),
    @Deprecated
    DS02("OrderCancelled", "An authorized user has cancelled the order"),
    @Deprecated
    DS03("OrderNotCancelled", "The user’s attempt to cancel the order was not successful"),
    @Deprecated
    DS04("OrderRejected", "The order was rejected by the bank side (for reasons concerning content)"),
    @Deprecated
    DS05("OrderForwardedForPostprocessing", "The order was correct and could be forwarded for postprocessing"),
    @Deprecated
    DS06("TransferOrder", "The order was transferred to VEU"),
    @Deprecated
    DS07("ProcessingOK", "All actions concerning the order could be done by the EBICS bank server"),
    @Deprecated
    DS08("DecompressionError", "The decompression of the file was not successful"),
    @Deprecated
    DS09("DecryptionError", "The decryption of the file was not successful"),
    @Deprecated
    DS0A("DataSignRequested", "Data signature is required."),
    @Deprecated
    DS0B("UnknownDataSignFormat", "Data signature for the format is not available or invalid."),
    @Deprecated
    DS0C("SignerCertificateRevoked", "The signer certificate is revoked."),
    @Deprecated
    DS0D("SignerCertificateNotValid", "The signer certificate is not valid (revoked or not active)."),
    @Deprecated
    DS0E("IncorrectSignerCertificate", "The signer certificate is not present."),
    @Deprecated
    DS0F("SignerCertificationAuthoritySignerNotValid", "The authority of the signer certification sending the certificate is unknown."),
    @Deprecated
    DS0G("NotAllowedPayment", "Signer is not allowed to sign this operation type."),
    @Deprecated
    DS0H("NotAllowedAccount", "Signer is not allowed to sign for this account."),
    @Deprecated
    DS0K("NotAllowedNumberOfTransaction", "The number of transaction is over the number allowed for this signer."),
    @Deprecated
    DS10("Signer1CertificateRevoked", "The certificate is revoked for the first signer."),
    @Deprecated
    DS11("Signer1CertificateNotValid", "The certificate is not valid (revoked or not active) for the first signer."),
    @Deprecated
    DS12("IncorrectSigner1Certificate", "The certificate is not present for the first signer."),
    @Deprecated
    DS13("SignerCertificationAuthoritySigner1NotValid", "The authority of signer certification sending the certificate is unknown for the first signer."),
    @Deprecated
    DS14("UserDoesNotExist", "The user is unknown on the server"),
    @Deprecated
    DS15("IdenticalSignatureFound", "The same signature has already been sent to the bank"),
    @Deprecated
    DS16("PublicKeyVersionIncorrect", "The public key version is not correct. This code is returned when a customer sends signature files to the financial institution after conversion from an older program version (old ES format) to a new program version (new ES format) without having carried out re-initialisation with regard to a public key change."),
    @Deprecated
    DS17("DifferentOrderDataInSignatures", "Order data and signatures don’t match"),
    @Deprecated
    DS18("RepeatOrder", "File cannot be tested, the complete order has to be repeated. This code is returned in the event of a malfunction during the signature check, e.g. not enough storage space."),
    @Deprecated
    DS19("ElectronicSignatureRightsInsufficient", "The user’s rights (concerning his signature) are insufficient to execute the order"),
    @Deprecated
    DS20("Signer2CertificateRevoked", "The certificate is revoked for the second signer."),
    @Deprecated
    DS21("Signer2CertificateNotValid", "The certificate is not valid (revoked or not active) for the second signer."),
    @Deprecated
    DS22("IncorrectSigner2Certificate", "The certificate is not present for the second signer."),
    @Deprecated
    DS23("SignerCertificationAuthoritySigner2NotValid", "The authority of signer certification sending the certificate is unknown for the second signer."),
    @Deprecated
    DS24("WaitingTimeExpired", "Waiting time expired due to incomplete order"),
    @Deprecated
    DS25("OrderFileDeleted", "The order file was deleted by the bank server (for multiple reasons)"),
    @Deprecated
    DS26("UserSignedMultipleTimes", "The same user has signed multiple times"),
    @Deprecated
    DS27("UserNotYetActivated", "The user is not yet activated (technically)"),
    @Deprecated
    DT02("InvalidCreationDate", "Invalid creation date and time in Group Header (eg, historic date)"),
    @Deprecated
    DT03("InvalidNonProcessingDate", "Invalid non bank processing date (eg, weekend or local public holiday)"),
    @Deprecated
    DT04("FutureDateNotSupported", "Future date not supported"),
    @Deprecated
    DT05("InvalidCutOffDate", "Associated message, payment information block or transaction was received after agreed processing cut-off date, i.e., date in the past."),
    @Deprecated
    DT06("ExecutionDateChanged", "Execution Date has been modified in order for transaction to be processed"),
    @Deprecated
    DU01("DuplicateMessageID", "Message Identification is not unique."),
    @Deprecated
    DU02("DuplicatePaymentInformationID", "Payment Information Block is not unique."),
    @Deprecated
    DU03("DuplicateTransaction", "Transaction is not unique."),
    @Deprecated
    DU04("DuplicateEndToEndID", "End To End ID is not unique."),
    @Deprecated
    DU05("DuplicateInstructionID", "Instruction ID is not unique."),
    @Deprecated
    DUPL("DuplicatePayment", "Payment is a duplicate of another payment"),
    @Deprecated
    ED06("SettlementSystemNotAvailable", "Interbank settlement system not available."),
    @Deprecated
    FF01("InvalidFileFormat", "File Format incomplete or invalid"),
    @Deprecated
    FF02("SyntaxError", "Syntax error reason is provided as narrative information in the additional reason information."),
    @Deprecated
    FF03("InvalidPaymentTypeInformation", "Payment Type Information is missing or invalid. Generic usage if cannot specify Service Level or Local Instrument code"),
    @Deprecated
    FF04("InvalidServiceLevelCode", "Service Level code is missing or invalid"),
    @Deprecated
    FF06("InvalidCategoryPurposeCode", "Category Purpose code is missing or invalid"),
    @Deprecated
    FF07("InvalidPurpose", "Purpose is missing or invalid"),
    @Deprecated
    FF08("InvalidEndToEndId", "End to End Id missing or invalid"),
    @Deprecated
    FF09("InvalidChequeNumber", "Cheque number missing or invalid"),
    @Deprecated
    FF10("BankSystemProcessingError", "File or transaction cannot be processed due to technical issues at the bank side"),
    @Deprecated
    FF11("ClearingRequestAborted", "Clearing request rejected due it being subject to an abort operation."),
    @Deprecated
    G000("PaymentTransferredAndTracked", "In an FI To FI Customer Credit Transfer: The Status Originator transferred the payment to the next Agent or to a Market Infrastructure. The payment transfer is tracked. No further updates will follow from the Status Originator. In a Financial Institution Credit Transfer with cover: The Status Originator performed the account booking and transferred the cover transaction to the next Reimbursement Agent or to a Market Infrastructure. The payment transfer is tracked. No further updates will follow from the Status Originator."),
    @Deprecated
    G001("PaymentTransferredAndNotTracked", "In an FI To FI Customer Credit Transfer: The Status Originator transferred the payment to the next Agent or to a Market Infrastructure. The payment transfer is not tracked. No further updates will follow from the Status Originator. In a Financial Institution Credit Transfer with cover: The Status Originator performed the account booking and transferred the cover transaction to the next Reimbursement Agent or to a Market Infrastructure. The payment transfer is not tracked. No further updates will follow from the Status Originator."),
    @Deprecated
    G002("CreditDebitNotConfirmed", "In a FIToFI Customer Credit Transfer: Credit to the creditor’s account may not be confirmed same day. Update will follow from the Status Originator. In a Financial Institution Credit Transfer with cover: Debit/credit to nostro account may not be confirmed same day or Financial Institution Credit Transfer may not be transferred same day. Update will follow from the Status Originator."),
    @Deprecated
    G003("CreditPendingDocuments", "In a FIToFI Customer Credit Transfer: Credit to creditor’s account is pending receipt of required documents. The Status Originator has requested creditor to provide additional documentation. Update will follow from the Status Originator. In a Financial Institution Credit Transfer with cover: Status Originator has requested a previous Agent to provide additional information/correct information. Update will follow from the Status Originator."),
    @Deprecated
    G004("CreditPendingFunds", "In a FIToFI Customer Credit Transfer: Credit to the creditor’s account is pending, status Originator is waiting for funds provided via a cover. Update will follow from the Status Originator."),
    @Deprecated
    G005("DeliveredWithServiceLevel", "Payment has been delivered to creditor agent with service level."),
    @Deprecated
    G006("DeliveredWIthoutServiceLevel", "Payment has been delivered to creditor agent without service level."),
    @Deprecated
    ID01("CorrespondingOriginalFileStillNotSent", "Signature file was sent to the bank but the corresponding original file has not been sent yet."),
    @Deprecated
    MD05("CollectionNotDue", "Creditor or creditor's agent should not have collected the direct debit"),
    @Deprecated
    NERI("NoERI", "Credit transfer is tagged as an Extended Remittance Information (ERI) transaction but does not contain ERI."),
    @Deprecated
    RC02("InvalidBankIdentifier", "Bank identifier is invalid or missing. Generic usage if cannot specify between debit or credit account"),
    @Deprecated
    RC03("InvalidDebtorBankIdentifier", "Debtor bank identifier is invalid or missing"),
    @Deprecated
    RC04("InvalidCreditorBankIdentifier", "Creditor bank identifier is invalid or missing"),
    @Deprecated
    RC05("InvalidBICIdentifier", "BIC identifier is invalid or missing. Generic usage if cannot specify between debit or credit account."),
    @Deprecated
    RC06("InvalidDebtorBICIdentifier", "Debtor BIC identifier is invalid or missing"),
    @Deprecated
    RC08("InvalidClearingSystemMemberIdentifier", "ClearingSystemMemberidentifier is invalid or missing. Generic usage if cannot specify between debit or credit account"),
    @Deprecated
    RC09("InvalidDebtorClearingSystemMemberIdentifier", "Debtor ClearingSystemMember identifier is invalid or missing"),
    @Deprecated
    RC10("InvalidCreditorClearingSystemMemberIdentifier", "Creditor ClearingSystemMember identifier is invalid or missing"),
    @Deprecated
    RC11("InvalidIntermediaryAgent", "Intermediary Agent is invalid or missing"),
    @Deprecated
    RC12("MissingCreditorSchemeId", "Creditor Scheme Id is invalid or missing"),
    @Deprecated
    RCON("RMessageConflict", "Conflict with R-Message"),
    @Deprecated
    RECI("ReceiverCustomerInformation", "Further information regarding the intended recipient."),
    @Deprecated
    RR05("RegulatoryInformationInvalid", "Regulatory or Central Bank Reporting information missing, incomplete or invalid."),
    @Deprecated
    RR06("TaxInformationInvalid", "Tax information missing, incomplete or invalid."),
    @Deprecated
    RR07("RemittanceInformationInvalid", "Remittance information structure does not comply with rules for payment type."),
    @Deprecated
    RR08("RemittanceInformationTruncated", "Remittance information truncated to comply with rules for payment type."),
    @Deprecated
    RR09("InvalidStructuredCreditorReference", "Structured creditor reference invalid or missing."),
    @Deprecated
    RR10("InvalidCharacterSet", "Character set supplied not valid for the country and payment type."),
    @Deprecated
    RR11("InvalidDebtorAgentServiceID", "Invalid or missing identification of a bank proprietary service."),
    @Deprecated
    RR12("InvalidPartyID", "Invalid or missing identification required within a particular country or payment type."),
    @Deprecated
    S000("ValidRequestForCancellationAcknowledged", "Request for Cancellation is acknowledged following validation."),
    @Deprecated
    S001("UETRFlaggedForCancellation", "Unique End-to-end Transaction Reference (UETR) relating to a payment has been identified as being associated with a Request for Cancellation."),
    @Deprecated
    S002("NetworkStopOfUETR", "Unique End-to-end Transaction Reference (UETR) relating to a payment has been prevent from traveling across a messaging network."),
    @Deprecated
    S003("RequestForCancellationForwarded", "Request for Cancellation has been forwarded to the payment processing/last payment processing agent."),
    @Deprecated
    S004("RequestForCancellationDeliveryAcknowledgement", "Request for Cancellation has been acknowledged as delivered to payment processing/last payment processing agent."),
    @Deprecated
    SL03("ServiceofClearingSystem", "Due to a specific service offered by the clearing system."),
    @Deprecated
    TA01("TransmissonAborted", "The transmission of the file was not successful – it had to be aborted (for technical reasons)"),
    @Deprecated
    TD01("NoDataAvailable", "There is no data available (for download)"),
    @Deprecated
    TD02("FileNonReadable", "The file cannot be read (e.g. unknown format)"),
    @Deprecated
    TD03("IncorrectFileStructure", "The file format is incomplete or invalid"),
    @Deprecated
    TK01("TokenInvalid", "Token is invalid."),
    @Deprecated
    TK02("SenderTokenNotFound", "Token used for the sender does not exist."),
    @Deprecated
    TK03("ReceiverTokenNotFound", "Token used for the receiver does not exist."),
    @Deprecated
    TK09("TokenMissing", "Token required for request is missing."),
    @Deprecated
    TKCM("TokenCounterpartyMismatch", "Token found with counterparty mismatch."),
    @Deprecated
    TKSG("TokenSingleUse", "Single Use Token already used."),
    @Deprecated
    TKSP("TokenSuspended", "Token found with suspended status."),
    @Deprecated
    TKVE("TokenValueLimitExceeded", "Token found with value limit rule violation."),
    @Deprecated
    TKXP("TokenExpired", "Token expired."),
    @Deprecated
    TS01("TransmissionSuccessful", "The (technical) transmission of the file was successful."),
    @Deprecated
    TS04("TransferToSignByHand", "The order was transferred to pass by accompanying note signed by hand");

    String identifier;
    String definition;

    ReturnReason(String identifier, String definition) {
        this.identifier = identifier;
        this.definition = definition;
    }

    @Override
    public String code() {
        return name();
    }

    @Override
    public String identifier() {
        return identifier;
    }

    @Override
    public String definition() {
        return definition;
    }

    @Override
    public String toString() {
        return code();
    }
}
