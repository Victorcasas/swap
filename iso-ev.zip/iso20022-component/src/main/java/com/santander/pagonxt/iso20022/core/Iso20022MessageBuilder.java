package com.santander.pagonxt.iso20022.core;

import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.codes.ChargeBearer;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.fields.ReasonInfo;
import com.santander.pagonxt.iso20022.common.fields.RegulatoryReport;
import com.santander.pagonxt.iso20022.common.fields.RemittanceInformation;
import com.santander.pagonxt.iso20022.common.fields.SchemeInfo;
import com.santander.pagonxt.iso20022.common.paymentsubtype.PaymentSubtype;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.Pacs004v09Builder;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Document;

import javax.money.MonetaryAmount;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

/**
 * The interface Iso 20022 message builder.
 *
 * @param <DOCUMENT> the type parameter
 */
public abstract class Iso20022MessageBuilder<DOCUMENT> {

    /**
     * The Document.
     */
    protected DOCUMENT document;

    /**
     * Build iso 20022 message.
     *
     * @return the iso 20022 message
     */
    public abstract Iso20022Message<DOCUMENT> build();

    /**
     * Message id iso 20022 message builder.
     *
     * @param messageId the message id
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> messageId(String messageId) {
        return this;
    }

    /**
     * Transaction id iso 20022 message builder.
     *
     * @param transactionId the transaction id
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> transactionId(String transactionId) {
        return this;
    }

    /**
     * Transaction reference iso 20022 message builder.
     *
     * @param txRef the tx ref
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> transactionReference(String txRef){
        return this;
    }

    /**
     * End to end id iso 20022 message builder.
     *
     * @param e2eId the e 2 e id
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> endToEndId(String e2eId) {
        return this;
    }

    /**
     * Instruction id iso 20022 message builder.
     *
     * @param instructionId the instruction id
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> instructionId(String instructionId) {
        return this;
    }

    /**
     * Amount iso 20022 message builder.
     *
     * @param amount the amount
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> amount(MonetaryAmount amount) {
        return this;
    }

    /**
     * Debtor iso 20022 message builder.
     *
     * @param partyIdentification the party identification
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> debtor(PartyIdentification partyIdentification) {
        return this;
    }

    /**
     * Creditor iso 20022 message builder.
     *
     * @param partyIdentification the party identification
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> creditor(PartyIdentification partyIdentification) {
        return this;
    }

    /**
     * Debtor account iso 20022 message builder.
     *
     * @param bankAccount the bank account
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> debtorAccount(BankAccount bankAccount) {
        return this;
    }

    /**
     * Creditor account iso 20022 message builder.
     *
     * @param bankAccount the bank account
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> creditorAccount(BankAccount bankAccount) {
        return this;
    }

    /**
     * Instructed agent iso 20022 message builder.
     *
     * @param agent the agent
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> instructedAgent(BankAccount.Agent agent) {
        return this;
    }

    /**
     * Instructing agent iso 20022 message builder.
     *
     * @param agent the agent
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> instructingAgent(BankAccount.Agent agent) {
        return this;
    }

    /**
     * Instructed reimbursement agent iso 20022 message builder.
     *
     * @param agent the agent
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> instructedReimbursementAgent(BankAccount.Agent agent) {
        return this;
    }

    /**
     * Instructing reimbursement agent iso 20022 message builder.
     *
     * @param agent the agent
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> instructingReimbursementAgent(BankAccount.Agent agent) {
        return this;
    }

    /**
     * Original amount iso 20022 message builder.
     *
     * @param amount the amount
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> originalAmount(MonetaryAmount amount) {
        return this;
    }

    /**
     * Correspondent account iso 20022 message builder.
     *
     * @param corresponsalAccount the corresponsal account
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> correspondentAccount(BankAccount corresponsalAccount) {
        return this;
    }

    /**
     * Xchg rate iso 20022 message builder.
     *
     * @param xchgRate the xchg rate
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> xchgRate(BigDecimal xchgRate) {
        return this;
    }

    /**
     * Compensation amount iso 20022 message builder.
     *
     * @param monetaryAmount the monetary amount
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> compensationAmount(MonetaryAmount monetaryAmount) {
        return this;
    }

    /**
     * Charge bearer iso 20022 message builder.
     *
     * @param chargeBearer the charge bearer
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> chargeBearer(ChargeBearer chargeBearer) {
        return this;
    }

    /**
     * Remittance information iso 20022 message builder.
     *
     * @param subject the subject
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> remittanceInformation(String subject) {
        return this;
    }

    /**
     * Payment subtype iso 20022 message builder.
     *
     * @param paymentSubtype the payment subtype
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> paymentSubtype(PaymentSubtype paymentSubtype) {
        return this;
    }

    /**
     * Interbank settlement date iso 20022 message builder.
     *
     * @param settlementDate the settlement date
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> interbankSettlementDate(LocalDate settlementDate) {
        return this;
    }

    /**
     * Regulatory reporting iso 20022 message builder.
     *
     * @param regulatoryReport the regulatory report
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> regulatoryReporting(RegulatoryReport regulatoryReport) {
        return this;
    }

    /**
     * Original message id iso 20022 message builder.
     *
     * @param originalMessageId the original message id
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> originalMessageId(String originalMessageId) {
        return this;
    }

    /**
     * Original message name id iso 20022 message builder.
     *
     * @param originalMessageNameId the original message name id
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> originalMessageNameId(String originalMessageNameId) {
        return this;
    }

    /**
     * Uetr iso 20022 message builder.
     *
     * @param uetr the uetr
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> uetr(UUID uetr) {
        return this;
    }

    /**
     * Debtor references iso 20022 message builder.
     *
     * @param debtorReference the debtor reference
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> debtorReferences(String... debtorReference) {
        return this;
    }

    /**
     * Creditor references iso 20022 message builder.
     *
     * @param creditorReference the creditor reference
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> creditorReferences(String... creditorReference){
        return this;
    }

    /**
     * Payment scheme iso 20022 message builder.
     *
     * @param paymentScheme the payment scheme
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> paymentScheme(String paymentScheme) {
        return this;
    }

    /**
     * Scheme id iso 20022 message builder.
     *
     * @param schemeInfo the scheme info
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> schemeId(SchemeInfo schemeInfo) {
        return this;
    }

    /**
     * Group original message id iso 20022 message builder.
     *
     * @param originalMessageId the original message id
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> groupOriginalMessageId(String originalMessageId) {
        return this;
    }

    /**
     * Group original message name id iso 20022 message builder.
     *
     * @param originalMessageNmId the original message nm id
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> groupOriginalMessageNameId(String originalMessageNmId) {
        return this;
    }

    /**
     * Group return reason iso 20022 message builder.
     *
     * @param reasonInfo the reason info
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> groupReturnReason(ReasonInfo reasonInfo) {
        return this;
    }

    /**
     * Return reason iso 20022 message builder.
     *
     * @param reasonInfo the reason info
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> returnReason(ReasonInfo reasonInfo) {
        return this;
    }

    /**
     * Requested collection date iso 20022 message builder.
     *
     * @param originalProcessingDate the original processing date
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> requestedCollectionDate(LocalDate originalProcessingDate) {
        return this;
    }

    /**
     * Tpp id iso 20022 message builder.
     *
     * @param tppid the tppid
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> tppId(String tppid) {
        return this;
    }

    /**
     * Remittance information iso 20022 message builder.
     *
     * @param remittanceInformation the remittance information
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> remittanceInformation(RemittanceInformation remittanceInformation) {
        return this;
    }

    /**
     * Authorisation iso 20022 message builder.
     *
     * @param auth the auth
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> authorisation(String auth) {
        return this;
    }

    /**
     * Group inter bank settlement date iso 20022 message builder.
     *
     * @param date the date
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> groupInterBankSettlementDate(LocalDate date) {
        return this;
    }

    /**
     * Inter bank sttlm date iso 20022 message builder.
     *
     * @param date the date
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> interBankSttlmDate(LocalDate date) {
        return this;
    }

    /**
     * Original tx international bank settlement date iso 20022 message builder.
     *
     * @param orgnlTxRefIntrBkSttlmDt the orgnl tx ref intr bk sttlm dt
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> originalTxInternationalBankSettlementDate(LocalDate orgnlTxRefIntrBkSttlmDt) {
        return this;
    }

    /**
     * Tx parties ultimate debtor iso 20022 message builder.
     *
     * @param ultimateDebtor the ultimate debtor
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> txPartiesUltimateDebtor(PartyIdentification ultimateDebtor) {
        return this;
    }

    /**
     * Tx parties debtor iso 20022 message builder.
     *
     * @param debtor the debtor
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> txPartiesDebtor(PartyIdentification debtor) {
        return this;
    }

    /**
     * Tx parties debtor agent iso 20022 message builder.
     *
     * @param debtorAgent the debtor agent
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> txPartiesDebtorAgent(BankAccount.Agent debtorAgent) {
        return this;
    }

    /**
     * Tx parties ultimate creditor iso 20022 message builder.
     *
     * @param ultimateCreditor the ultimate creditor
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> txPartiesUltimateCreditor(PartyIdentification ultimateCreditor) {
        return this;
    }

    /**
     * Tx parties creditor iso 20022 message builder.
     *
     * @param creditor the creditor
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> txPartiesCreditor(PartyIdentification creditor) {
        return this;
    }

    /**
     * Tx parties creditor agent iso 20022 message builder.
     *
     * @param creditorAgent the creditor agent
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> txPartiesCreditorAgent(BankAccount.Agent creditorAgent) {
        return this;
    }

    /**
     * Control sum iso 20022 message builder.
     *
     * @param controlSum the control sum
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> controlSum(BigDecimal controlSum) {
        return this;
    }

    /**
     * Clearing system code iso 20022 message builder.
     *
     * @param clearingSystemCode the clearing system code
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> clearingSystemCode(String clearingSystemCode) {
        return this;
    }

    /**
     * Clearing system proprietary iso 20022 message builder.
     *
     * @param clearingSystemProprietary the clearing system proprietary
     * @return the iso 20022 message builder
     */
    public Iso20022MessageBuilder<DOCUMENT> clearingSystemProprietary(String clearingSystemProprietary) {
        return this;
    }
}
