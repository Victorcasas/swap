package com.santander.pagonxt.iso20022.messages.pacs.pacs008;

import com.santander.pagonxt.iso20022.core.Iso20022Message;
import com.santander.pagonxt.iso20022.core.Iso20022MessageAccessor;
import com.santander.pagonxt.iso20022.core.Iso2022MessageValidator;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Document;

public class Pacs008v08Message extends Iso20022Message<Document> {

    private static final String MESSAGE_DEFINITION = "pacs.008.001.08";

    public Pacs008v08Message(Document document) {
        super(document);
    }

    @Override
    public Iso20022MessageAccessor<Document> getAccessor() {
        return new Pacs008v08Accessor(document());
    }

    @Override
    public void validateMessage() {
        final var validator = new Iso2022MessageValidator<Document>(
                MESSAGE_DEFINITION,
                String.format(DEFINITION_PATH, MESSAGE_DEFINITION)
        );
        validator.validateDocument(document());
    }
}
