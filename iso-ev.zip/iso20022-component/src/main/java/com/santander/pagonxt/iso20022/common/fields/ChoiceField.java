package com.santander.pagonxt.iso20022.common.fields;

import lombok.Data;

import static org.apache.commons.lang3.StringUtils.isNotBlank;


/**
 * The type Choice field.
 */
@Data
public class ChoiceField {
    private String prtry;
    private String cd;

    /**
     * Is populated boolean.
     *
     * @return the boolean
     */
    public boolean isPopulated() {
        return isNotBlank(prtry) || isNotBlank(cd);
    }
}
