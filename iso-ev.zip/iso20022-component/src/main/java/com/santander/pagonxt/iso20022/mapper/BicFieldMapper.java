package com.santander.pagonxt.iso20022.mapper;

import ma.glasnost.orika.DefaultFieldMapper;
import ma.glasnost.orika.metadata.Type;

/**
 * The type Bic field mapper.
 */
public class BicFieldMapper implements DefaultFieldMapper {

    @Override
    public String suggestMappedField(String fromProperty, Type<?> fromPropertyType) {
        if (fromPropertyType.isString()) {
            if ("BIC".equals(fromProperty)) {
                return "BICFI";
            }
            if ("BICFI".equals(fromProperty)) {
                return "BIC";
            }
        }
        return null;
    }
}
