package com.santander.pagonxt.iso20022.common.accounts;

import com.santander.pagonxt.iso20022.common.fields.PartyIdentification.Address;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;
import lombok.Value;

import java.util.Optional;

import static java.util.Optional.ofNullable;
import static org.apache.commons.lang3.StringUtils.isBlank;

/**
 * The type Bank account.
 */
@AllArgsConstructor
@Getter
@EqualsAndHashCode
@ToString
public abstract class BankAccount {

    /**
     * The Account.
     */
    private final Account account;
    /**
     * The Agent.
     */
    private final Agent agent;

    /**
     * Gets partenon code.
     *
     * @return the partenon code
     */
    public abstract Optional<String> getPartenonCode();

    /**
     * Gets account type.
     *
     * @return the account type
     */
    public abstract AccountType getAccountType();

    /**
     * Gets bicfi.
     *
     * @return the bicfi
     */
    public String getBicfi() {
        return ofNullable(agent).map(Agent::getBicfi).orElse(null);
    }

    /**
     * Gets agent name.
     *
     * @return the agent name
     */
    public String getAgentName() {
        return ofNullable(agent).map(Agent::getName).orElse(null);
    }

    /**
     * Gets other agent id.
     *
     * @return the other agent id
     */
    public String getOtherAgentId() {
        return ofNullable(agent).map(Agent::getOtherId).orElse(null);
    }

    /**
     * Gets scheme name.
     *
     * @return the scheme name
     */
    public Account.SchemeName getSchemeName() {
        return ofNullable(account).map(Account::getSchemeName).orElse(null);
    }

    /**
     * Gets account name.
     *
     * @return the account name
     */
    public String getAccountName() {
        return ofNullable(account).map(Account::getName).orElse(null);
    }

    /**
     * Gets identification.
     *
     * @return the identification
     */
    public String getIdentification() {
        return ofNullable(account).map(Account::getIdentification).orElse(null);
    }

    /**
     * Gets currency.
     *
     * @return the currency
     */
    public String getCurrency() {
        return ofNullable(account).map(Account::getCurrency).orElse(null);
    }

    /**
     * Has not account boolean.
     *
     * @return the boolean
     */
    public boolean hasNotAccount() {
        return isBlank(account.getName())
                && isBlank(account.getIdentification())
                && isBlank(account.getCurrency());
    }

    /**
     * The type Agent.
     */
    @Value
    @Builder
    public static class Agent {
        String name;
        String type;
        String bicfi;
        String memberId;
        String otherId;
        Address address;
    }

    /**
     * The type Account.
     */
    @Value
    @Builder
    public static class Account {
        String name;
        String identification;
        SchemeName schemeName;
        String currency;

        /**
         * The enum Scheme name.
         */
        public enum SchemeName {
            /**
             * Sort code account number scheme name.
             */
            SORT_CODE_ACCOUNT_NUMBER,
            /**
             * Iban scheme name.
             */
            IBAN,
            /**
             * Local account scheme name.
             */
            LOCAL_ACCOUNT
        }
    }
}
