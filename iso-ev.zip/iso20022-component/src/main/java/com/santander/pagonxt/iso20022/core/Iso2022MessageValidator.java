package com.santander.pagonxt.iso20022.core;

import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Document;
import lombok.extern.slf4j.Slf4j;
import org.xml.sax.SAXException;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.namespace.QName;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import java.io.OutputStream;

/**
 * The type Pacs 008 validator.
 */
@Slf4j
public class Iso2022MessageValidator<DOCUMENT> {

    private final String messageDefinition;
    private final String definitionPath;

    public Iso2022MessageValidator(String messageDefinition, String definitionPath) {
        this.definitionPath = definitionPath;
        this.messageDefinition = messageDefinition;
    }

    /**
     * Validate document.
     *
     * @param document the document
     */
    public void validateDocument(DOCUMENT document) {
        if (document == null) {
            throw new RuntimeException("Process stopped, trying to validate null document");
        }
        final JAXBContext context;
        try {
            context = JAXBContext.newInstance(document.getClass());
        } catch (JAXBException e) {
            throw new RuntimeException(e);
        }
        marshallDocument(document, context);
    }

    private void marshallDocument(DOCUMENT document, JAXBContext context) {
        SchemaFactory sf = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
        Schema schema;
        try {
            schema = sf.newSchema(
                    new StreamSource(Iso2022MessageValidator.class.getResourceAsStream(definitionPath)));
        } catch (SAXException e) {
            throw new RuntimeException(e);
        }

        try {
            Marshaller marshaller = context.createMarshaller();
            marshaller.setSchema(schema);
            marshaller.marshal(new JAXBElement<>(new QName(
                    "urn:iso:std:iso:20022:tech:xsd:" + messageDefinition,
                    "Document"),
                    (Class<DOCUMENT>) document.getClass(), document), getUselessOutputStream());
        } catch (JAXBException e) {
            throw new RuntimeException(e);
        }
    }

    private OutputStream getUselessOutputStream() {
        return new OutputStream() {
            @Override
            public void write(int b) {
                //Do nothing
            }
        };
    }
}
