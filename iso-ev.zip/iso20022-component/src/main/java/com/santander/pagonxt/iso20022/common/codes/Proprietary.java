package com.santander.pagonxt.iso20022.common.codes;

import lombok.AllArgsConstructor;
import lombok.Builder;

/**
 * Implementation for custom/proprietary codes.
 * <p>
 * The field prtry in the ISO message will be populated instead of cd when using this implementation.
 */
@AllArgsConstructor
@Builder
public class Proprietary implements ExternalCode {

    private final String code;

    @Override
    public boolean isProprietary() {
        return true;
    }

    @Override
    public String code() {
        return code;
    }

    @Override
    public String identifier() {
        return null;
    }

    @Override
    public String definition() {
        return null;
    }

    @Override
    public String toString() {
        return code();
    }
}
