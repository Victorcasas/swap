package com.santander.pagonxt.iso20022.mapper;

import ma.glasnost.orika.CustomMapper;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.MappingContext;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import ma.glasnost.orika.metadata.Type;
import ma.glasnost.orika.metadata.TypeBuilder;

import java.util.List;

/**
 * The type Orika mapper.
 */
public final class OrikaMapper {
    private final MapperFacade mapperFacade;

    private OrikaMapper() {
        mapperFacade = configure();
    }

    /**
     * Gets instance.
     *
     * @return the instance
     */
    public static OrikaMapper getInstance() {
        return InstanceHolder.INSTANCE;
    }

    /**
     * Gets mapper facade.
     *
     * @return the mapper facade
     */
    public MapperFacade getMapperFacade() {
        return mapperFacade;
    }

    /**
     * Mapper mapper facade.
     *
     * @return the mapper facade
     */
    public static MapperFacade mapper() {
        return getInstance().getMapperFacade();
    }

    private static class InstanceHolder {
        private static final OrikaMapper INSTANCE = new OrikaMapper();
    }

    /**
     * Configure mapper facade.
     *
     * @return the mapper facade
     */
    public MapperFacade configure() {
        final MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

        mapperFactory.registerDefaultFieldMapper(new BicFieldMapper());

        Type<List<String>> listOfStringType = new TypeBuilder<List<String>>() {
        }.build();

        mapperFactory
                .classMap(listOfStringType, listOfStringType)
                .mapNulls(false)
                .customize(new CustomMapper<>() {
                    @Override
                    public void mapAtoB(List<String> a, List<String> b, MappingContext context) {
                        if (a == null || b == null) {
                            return;
                        }
                        b.addAll(a);
                    }

                    @Override
                    public void mapBtoA(List<String> b, List<String> a, MappingContext context) {
                        if (a == null || b == null) {
                            return;
                        }
                        a.addAll(b);
                    }
                })
                .register();

        return mapperFactory.getMapperFacade();
    }
}
