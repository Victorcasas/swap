package com.santander.pagonxt.iso20022.messages.pain.pain001;

import com.santander.pagonxt.iso20022.common.exception.Pain001ReaderException;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.Document;
import lombok.AccessLevel;
import lombok.NoArgsConstructor;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.InputStream;

@NoArgsConstructor(access = AccessLevel.PRIVATE)
public class Pain001Reader {

  public static Pain001v03Message readXml(InputStream inputStreamPain001) throws Pain001ReaderException {
    try {
      final JAXBContext jaxbContext = JAXBContext.newInstance(Document.class);
      final Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

      var documentPain001 = (Document) jaxbUnmarshaller.unmarshal(inputStreamPain001);

      return new Pain001v03Message(documentPain001);
    } catch (JAXBException e) {
      throw new Pain001ReaderException(e);
    }
  }

}
