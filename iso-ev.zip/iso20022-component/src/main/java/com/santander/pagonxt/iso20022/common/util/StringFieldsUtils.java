package com.santander.pagonxt.iso20022.common.util;

import org.apache.commons.lang3.StringUtils;

public class StringFieldsUtils {
    /**
     * Funcion que añade un campo con su separador siempre que el dicho campo no sea null
     * En el caso de quie el separador sea null no se añadira tampoco (ultimo campo/fin de cadena)
     * @param builder
     * @param field
     * @param separator
     * @return
     */
    public static StringBuilder addSafeFieldWithSeparator(StringBuilder builder, String field, String separator){

        if(StringUtils.isNotEmpty(field) && StringUtils.isNotEmpty(separator))
            builder.append(field).append(separator);
        else if(StringUtils.isNotEmpty(field))
            builder.append(field);

        return builder;
    }
}
