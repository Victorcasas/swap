package com.santander.pagonxt.iso20022.common.accounts;

import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import lombok.Builder;

import java.util.Optional;

import static com.santander.pagonxt.iso20022.common.accounts.IsoCode.Codes.OTHR;

/**
 * The type Credit card.
 */
public class CreditCard extends LocalAccount {

    /**
     * The constant PARTENON_CODE.
     */
    public static final String PARTENON_CODE = "4";

    /**
     * Instantiates a new Credit card.
     *
     * @param account       the account
     * @param accountName   the account name
     * @param currency      the currency
     * @param bicfi         the bicfi
     * @param agentName     the agent name
     * @param otherAgentId  the other agent id
     * @param address       the address
     * @param agentType     the agent type
     * @param agentMemberId the agent member id
     */
    @Builder
    public CreditCard(String account,
                      String accountName,
                      String currency,
                      String bicfi,
                      String agentName,
                      String otherAgentId,
                      PartyIdentification.Address address,
                      String agentType,
                      String agentMemberId) {
        super(account, accountName, currency, bicfi, agentName, otherAgentId, address, agentType, agentMemberId);
    }

    @Override
    public AccountType getAccountType() {
        return new IsoCode(OTHR);
    }

    @Override
    public Optional<String> getPartenonCode() {
        return Optional.of(PARTENON_CODE);
    }
}
