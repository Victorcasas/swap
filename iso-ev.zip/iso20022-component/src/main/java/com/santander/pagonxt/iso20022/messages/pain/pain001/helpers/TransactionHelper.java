package com.santander.pagonxt.iso20022.messages.pain.pain001.helpers;

import com.santander.pagonxt.iso20022.messages.pain.pain001.model.CustomerCreditTransferInitiationV03;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.Document;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.PaymentInstructionInformation3;

import java.util.List;
import java.util.Optional;

import static java.util.Optional.of;

public class TransactionHelper {

    public Optional<PaymentInstructionInformation3> firstTransaction(Document document) {
        return of(of(document)
                .map(Document::getCstmrCdtTrfInitn)
                .map(CustomerCreditTransferInitiationV03::getPmtInves)
                .orElse(List.of())
                .get(0));
    }

    public Optional<List<PaymentInstructionInformation3>> allTransaction(Document document) {
        return of(of(document)
                .map(Document::getCstmrCdtTrfInitn)
                .map(CustomerCreditTransferInitiationV03::getPmtInves)
                .orElse(List.of()));
    }

    public Optional<PaymentInstructionInformation3> peekTransactionAtPos(Document document, Integer pos) {
        return of(of(document)
                .map(Document::getCstmrCdtTrfInitn)
                .map(CustomerCreditTransferInitiationV03::getPmtInves)
                .orElse(List.of())
                .get(pos));
    }
}
