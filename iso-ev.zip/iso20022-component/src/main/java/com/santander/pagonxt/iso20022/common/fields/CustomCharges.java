package com.santander.pagonxt.iso20022.common.fields;


import com.santander.pagonxt.iso20022.common.accounts.BankAccount.Agent;

import java.math.BigDecimal;

/**
 * The type Custom charges.
 */
public class CustomCharges {

    private final Agent agent;
    private final String concept;
    private final String currency;
    private final BigDecimal amount;

    /**
     * Builder custom charges . custom charges builder.
     *
     * @return the custom charges . custom charges builder
     */
    public static CustomChargesBuilder builder() {
        return new CustomChargesBuilder();
    }

    /**
     * Instantiates a new Custom charges.
     *
     * @param agent    the agent
     * @param concept  the concept
     * @param currency the currency
     * @param amount   the amount
     */
    public CustomCharges(final Agent agent, final String concept, final String currency, final BigDecimal amount) {
        this.agent = agent;
        this.concept = concept;
        this.currency = currency;
        this.amount = amount;
    }

    /**
     * Gets agent.
     *
     * @return the agent
     */
    public Agent getAgent() {
        return this.agent;
    }

    /**
     * Gets concept.
     *
     * @return the concept
     */
    public String getConcept() {
        return this.concept;
    }

    /**
     * Gets currency.
     *
     * @return the currency
     */
    public String getCurrency() {
        return this.currency;
    }

    /**
     * Gets amount.
     *
     * @return the amount
     */
    public BigDecimal getAmount() {
        return this.amount;
    }

    /**
     * The type Custom charges builder.
     */
    public static class CustomChargesBuilder {
        private Agent agent;
        private String concept;
        private String currency;
        private BigDecimal amount;

        /**
         * Instantiates a new Custom charges builder.
         */
        CustomChargesBuilder() {
        }

        /**
         * Agent custom charges . custom charges builder.
         *
         * @param agent the agent
         * @return the custom charges . custom charges builder
         */
        public CustomChargesBuilder agent(final Agent agent) {
            this.agent = agent;
            return this;
        }

        /**
         * Concept custom charges . custom charges builder.
         *
         * @param concept the concept
         * @return the custom charges . custom charges builder
         */
        public CustomChargesBuilder concept(final String concept) {
            this.concept = concept;
            return this;
        }

        /**
         * Currency custom charges . custom charges builder.
         *
         * @param currency the currency
         * @return the custom charges . custom charges builder
         */
        public CustomChargesBuilder currency(final String currency) {
            this.currency = currency;
            return this;
        }

        /**
         * Amount custom charges . custom charges builder.
         *
         * @param amount the amount
         * @return the custom charges . custom charges builder
         */
        public CustomChargesBuilder amount(final BigDecimal amount) {
            this.amount = amount;
            return this;
        }

        /**
         * Build custom charges.
         *
         * @return the custom charges
         */
        public CustomCharges build() {
            return new CustomCharges(this.agent, this.concept, this.currency, this.amount);
        }

        public String toString() {
            return "CustomCharges.CustomChargesBuilder(agent=" + this.agent + ", concept=" + this.concept +
                    ", currency=" + this.currency + ", amount=" + this.amount + ")";
        }
    }
}
