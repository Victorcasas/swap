package com.santander.pagonxt.iso20022.common.accounts;

import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;

import java.util.Objects;
import java.util.Optional;

/**
 * The type Local account.
 */
public abstract class LocalAccount extends BankAccount {

    /**
     * Instantiates a new Local account.
     *
     * @param account       the account
     * @param accountName   the account name
     * @param currency      the currency
     * @param bicfi         the bicfi
     * @param agentName     the agent name
     * @param otherAgentId  the other agent id
     * @param address       the address
     * @param agentType     the agent type
     * @param agentMemberId the agent member id
     */
    public LocalAccount(String account,
                        String accountName,
                        String currency,
                        String bicfi,
                        String agentName,
                        String otherAgentId,
                        PartyIdentification.Address address,
                        String agentType,
                        String agentMemberId) {
        super(Account.builder()
                        .identification(account)
                        .name(accountName)
                        .schemeName(Account.SchemeName.LOCAL_ACCOUNT)
                        .currency(currency)
                        .build(),
                Agent.builder()
                        .bicfi(Optional.ofNullable(bicfi)
                                .map(Objects::toString)
                                .orElse(null))
                        .name(agentName)
                        .address(address)
                        .otherId(otherAgentId)
                        .type(agentType)
                        .memberId(agentMemberId)
                        .build());
    }
}
