package com.santander.pagonxt.iso20022.common.fields;

public enum Priority {

    URGT,
    HIGH,
    NORM,
    LOWW
}
