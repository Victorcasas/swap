package com.santander.pagonxt.iso20022.messages.pain.pain001;

import com.santander.pagonxt.iso20022.common.exception.Pain001ReaderException;
import com.santander.pagonxt.iso20022.core.Iso20022MessageAccessor;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.Document;
import org.junit.jupiter.api.Test;

import java.io.InputStream;
import java.math.BigDecimal;

import static org.assertj.core.api.Assertions.assertThat;

class Pain001v03AccessorTest {

    @Test
    void checkValidPainFields() throws Pain001ReaderException {

        ClassLoader classLoader = getClass().getClassLoader();
        final InputStream inputFile = classLoader.getResourceAsStream("fixtures/messages/pain/pain001/GTS.I.PAIN01.0003.11");
        final Pain001v03Message message = Pain001Reader.readXml(inputFile);

        assertThat(message).isNotNull();
        assertThat(message.getAccessor()).isNotNull();

        Iso20022MessageAccessor<Document> acc = message.getAccessor();

        assertThat(acc.creationDate().toString())
                .isNotNull()
                .isEqualTo("2021-09-15T11:56:17.394");

        assertThat(acc.messageId())
                .isNotNull()
                .isEqualTo("00000OYPQC");

        assertThat(acc.debtorCcy())
                .isNotNull()
                .isEqualTo("GBP");

        assertThat(acc.controlSum())
                .isNotNull()
                .isEqualTo(BigDecimal.valueOf(13012.08));

        assertThat(acc.numberOfTransactions())
                .isNotNull()
                .isEqualTo("7");

        assertThat(acc.remittances().size())
                .isNotNull()
                .isEqualTo(1);

        assertThat(acc.remittances().get(0).getOriginCountry())
                .isNotNull()
                .isEqualTo("GB");

        assertThat(acc.remittances().get(0).getDebtorAccount())
                .isNotNull()
                .isEqualTo("10190775");

        assertThat(acc.remittances().get(0).getNumberOfTxs())
                .isNotNull()
                .isEqualTo(0);

        assertThat(acc.remittances().get(0).getRequestedExecutionDate())
                .isNotNull()
                .isEqualTo("2021-09-15");

        assertThat(acc.debtorName())
                .isNotNull()
                .isEqualTo("AABBCC BANCO SANTANDER  UNITEDF KINGDOM");


    }

}
