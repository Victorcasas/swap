package com.santander.pagonxt.iso20022.messages.pain.pain001;


import com.santander.pagonxt.iso20022.common.exception.Pain001ReaderException;
import com.santander.pagonxt.iso20022.messages.pain.pain001.model.Document;
import org.junit.jupiter.api.Test;

import javax.xml.bind.JAXBException;
import java.io.IOException;

import static com.santander.pagonxt.iso20022.IsoMessagesScaffolding.buildNotValidPain001Document;
import static com.santander.pagonxt.iso20022.IsoMessagesScaffolding.buildValidPain001Document;
import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

class Pain001v03ValidatorTest {

    @Test
    void shouldNotValidateInvalidPain001Document_andThrowMarshalException() throws JAXBException {
        //given
        final Document pain001 = buildNotValidPain001Document();
        final Pain001v03Message pain001v03Message = new Pain001v03Message(pain001);

        //when
        //then
        assertThatThrownBy(pain001v03Message::validateMessage)
                .isInstanceOf(RuntimeException.class);
    }

    /**
     * Should validate valid pacs 008 document.
     *
     * @throws IOException the io exception
     */
    @Test
    void shouldValidateValidPain001Document() throws IOException, JAXBException, Pain001ReaderException {
        //given
        final Document pain001 = buildValidPain001Document();

        assertThat(pain001).isNotNull();
        assertThat(pain001.getCstmrCdtTrfInitn()).isNotNull();
        //when
        //then
        assertDoesNotThrow(() -> new Pain001v03Message(pain001).validateMessage());
    }

    /**
     * Should throw not validate when document is null.
     */
    @Test
    void shouldThrowNotValidateWhenDocumentIsNull() {
        //given
        final Pain001v03Message pain001v03Message = new Pain001v03Message(null);
        //when
        //then
        assertThatThrownBy(pain001v03Message::validateMessage)
                .isInstanceOf(RuntimeException.class)
                .hasMessage("Process stopped, trying to validate null document");
    }
}
