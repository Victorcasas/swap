package com.santander.pagonxt.iso20022.messages.pacs.pacs004;

import com.santander.pagonxt.iso20022.IsoMessagesScaffolding;
import com.santander.pagonxt.iso20022.common.codes.ChargeBearer;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.math.BigDecimal;

import static net.javacrumbs.jsonunit.fluent.JsonFluentAssert.assertThatJson;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

class Pacs004v09BuilderTest extends IsoMessagesScaffolding {

    @Test
    void shouldBuildAValidPacs004WithBuildMethod() throws IOException {
        final Pacs004v09Message pacs004v09Message = new Pacs004v09Builder()
                .messageId(MESSAGE_ID)
                .originalMessageId(ORIGINAL_MESSAGE_ID)
                .originalMessageNameId(ORIGINAL_MESSAGE_NAME_ID)
                .amount(AMOUNT)
                .instructionId(INSTRUCTION_ID)
                .transactionId(TRANSACTION_ID)
                .transactionReference(TRANSACTION_REFERENCE)
                .endToEndId(E2E_ID)
                .uetr(UETR)
                .debtorAccount(DEBTOR_ACCOUNT)
                .debtor(DEBTOR)
                .creditor(CREDITOR)
                .creditorAccount(CREDITOR_ACCOUNT)
                .debtorReferences(DEBTOR_REFERENCES)
                .creditorReferences(CREDITOR_REFERENCES)
                .paymentScheme(PAYMENT_SCHEME)
                .schemeId(SCHEME_ID)
                .groupOriginalMessageId(ORIGINAL_MESSAGE_ID)
                .groupOriginalMessageNameId(ORIGINAL_MESSAGE_NAME_ID)
                .groupReturnReason(REASON)
                .returnReason(REASON)
                .requestedCollectionDate(REQUESTED_COLLECTION_DATE)
                .tppId(TPP_ID)
                .authorisation(AUTHORIZATION)
                .originalAmount(AMOUNT.multiply(2.5))
                .xchgRate(EXCHANGE_RATE)
                .compensationAmount(AMOUNT.multiply(1.5))
                .chargeBearer(ChargeBearer.SHAR)
                .interBankSttlmDate(REQUESTED_COLLECTION_DATE)
                .originalTxInternationalBankSettlementDate(REQUESTED_COLLECTION_DATE)
                .txPartiesUltimateDebtor(DEBTOR)
                .txPartiesDebtor(DEBTOR)
                .txPartiesDebtorAgent(INSTRUCTED_AGENT)
                .txPartiesUltimateCreditor(CREDITOR)
                .txPartiesCreditor(CREDITOR)
                .txPartiesCreditorAgent(INSTRUCTING_AGENT)
                .controlSum(new BigDecimal("3.9"))
                .clearingSystemCode("SHAR")
                .clearingSystemProprietary("S")
                .build();

        assertDoesNotThrow(pacs004v09Message::validateMessage);
        assertThatJson(objectMapper.writeValueAsString(pacs004v09Message.document()))
                .whenIgnoringPaths("pmtRtr.grpHdr.creDtTm")
                .isEqualTo(readString("fixtures/messages/pacs/pacs004/expectedPacs004v09.json"));
    }
}