package com.santander.pagonxt.iso20022.messages.pacs.pacs008;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.accounts.IbanAccount;
import com.santander.pagonxt.iso20022.common.codes.ChargeBearer;
import com.santander.pagonxt.iso20022.common.fields.CustomCharges;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.fields.RegulatoryReport;
import com.santander.pagonxt.iso20022.common.fields.RegulatoryReportingTypeCode;
import com.santander.pagonxt.iso20022.common.fields.RemittanceInformation;
import com.santander.pagonxt.iso20022.core.Iso20022MessageAccessor;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Document;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import static com.santander.pagonxt.iso20022.IsoMessagesScaffolding.readString;
import static net.javacrumbs.jsonunit.fluent.JsonFluentAssert.assertThatJson;
import static org.assertj.core.api.Assertions.assertThat;

/**
 * The type Pacs 008 accessor test.
 */
class Pacs008v08AccessorTest {

    private static ObjectMapper mapper;

    /**
     * Sets up.
     */
    @BeforeAll
    static void setUp() {
        mapper = new ObjectMapper()
                .setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .registerModule(new JavaTimeModule());
    }

    /**
     * Should be able to access fields of pacs 008.
     *
     * @throws IOException the io exception
     */
    @Test
    void shouldBeAbleToAccessFieldsOfPacs008() throws IOException {
        //given
        final Document document =
                mapper.readValue(readString("fixtures/messages/pacs/pacs008/validPacs008v08.json"), Document.class);
        final Pacs008v08Message pacs008v08Message = new Pacs008v08Message(document);
        final PartyIdentification expectedDebtor = PartyIdentification.builder()
                .name("Debtor")
                .address(PartyIdentification.Address.builder()
                        .postCode("postCode")
                        .town("miltonKeynes")
                        .streetName("debtor-street")
                        .country("GB")
                        .addressLine(List.of("addressline1", "addressline2"))
                        .build())
                .partyType(PartyIdentification.Person.builder()
                        .otherId("debitor-id")
                        .build())
                .build();
        final PartyIdentification expectedCreditor = PartyIdentification.builder()
                .name("Creditor")
                .address(PartyIdentification.Address.builder()
                        .postCode("postCode")
                        .town("miltonKeynes")
                        .country("GB")
                        .addressLine(List.of("addressline1", "addressline2"))
                        .build())
                .partyType(PartyIdentification.Person.builder()
                        .otherId("creditor-id")
                        .build())
                .build();
        final BankAccount expectedDebtorAccount = IbanAccount.builder()
                .iban("RO18WBWQ8PZVK6RLBRNN56JV")
                .agentType("agentType")
                .build();
        final BankAccount expectedCreditorAccount = IbanAccount.builder()
                .iban("IL402173464146167671248")
                .agentType("cd")
                .bicfi("ABBYGB21")
                .build();
        final RegulatoryReport expectedRegulatoryReport = RegulatoryReport.builder()
                .country("ES")
                .narrative("narrative")
                .typeCode(RegulatoryReportingTypeCode.BOTH)
                .build();
        final RemittanceInformation expectedRemittanceInformation = RemittanceInformation.builder()
                .reference("add1")
                .unstructured("add2")
                .build();
        final BankAccount expectedCorrespondentAccount = IbanAccount.builder()
                .iban("IL402173464146167671249")
                .agentType("cd")
                .build();
        final BankAccount debtorAgentAccount = IbanAccount.builder()
                .iban("IL402173464146167671269")
                .build();
        final BankAccount creditorAgentAccount = IbanAccount.builder()
                .iban("IL402173464146167671248")
                .build();
        final BankAccount.Agent instructingAgent = BankAccount.Agent.builder()
                .bicfi("ABBYGB23")
                .build();
        final BankAccount.Agent instructedAgent = BankAccount.Agent.builder()
                .build();
        final BankAccount.Agent instructingReimbursementAgent = BankAccount.Agent.builder()
                .type("cd")
                .memberId("instructingMemberId")
                .build();
        final BankAccount.Agent instructedReimbursementAgent = BankAccount.Agent.builder()
                .type("cd")
                .memberId("instructedMemberId")
                .build();
        final CustomCharges expectedCharges = CustomCharges.builder()
                .agent(BankAccount.Agent.builder()
                        .bicfi("ABBYGB21")
                        .memberId("chargesAgentId")
                        .type("cd")
                        .build())
                .amount(BigDecimal.valueOf(99.9))
                .currency("EUR")
                .build();

        //when
        final Iso20022MessageAccessor accessor = pacs008v08Message.getAccessor();

        //then
        assertThat(accessor.messageId())
                .isNotNull()
                .isEqualTo("message-id");
        assertThat(accessor.endToEndId())
                .isNotNull()
                .isEqualTo("end-to-end-id");
        assertThat(accessor.instructionId())
                .isNotNull()
                .isEqualTo("instruction-id");
        assertThat(accessor.amount().getCurrency().getCurrencyCode())
                .isNotNull()
                .isEqualTo("GBP");
        assertThat(accessor.amount().getNumber().doubleValue())
                .isNotNull()
                .isEqualTo(10.04);
        Assertions.assertThat(accessor.debtor())
                .isNotNull()
                .isEqualTo(expectedDebtor);
        Assertions.assertThat(accessor.creditor())
                .isNotNull()
                .isEqualTo(expectedCreditor);
        Assertions.assertThat(accessor.debtorAccount())
                .isNotNull()
                .isEqualTo(expectedDebtorAccount);
        Assertions.assertThat(accessor.creditorAccount())
                .isNotNull()
                .isEqualTo(expectedCreditorAccount);
        Assertions.assertThat(accessor.instructedAgent())
                .isNotNull()
                .isEqualTo(instructedAgent);
        Assertions.assertThat(accessor.instructingAgent())
                .isNotNull()
                .isEqualTo(instructingAgent);
        Assertions.assertThat(accessor.instructedReimbursementAgent())
                .isNotNull()
                .isEqualTo(instructedReimbursementAgent);
        Assertions.assertThat(accessor.instructingReimbursementAgent())
                .isNotNull()
                .isEqualTo(instructingReimbursementAgent);
        assertThat(accessor.originalAmount().getNumber().doubleValue())
                .isNotNull()
                .isEqualTo(1.04);
        assertThat(accessor.originalAmount().getCurrency().getCurrencyCode())
                .isNotNull()
                .isEqualTo("GBP");
        Assertions.assertThat(accessor.correspondentAccount())
                .isNotNull()
                .isEqualTo(expectedCorrespondentAccount);
        Assertions.assertThat(accessor.chargeBearer())
                .isNotNull()
                .isEqualTo(ChargeBearer.SHAR);
        Assertions.assertThat(accessor.remittanceInformation())
                .isNotNull()
                .isEqualTo(expectedRemittanceInformation);
        assertThat(accessor.paymentSubtype())
                .isNotNull()
                .isEqualTo("CD");
        assertThat(accessor.interbankSettlementDate())
                .isNotNull()
                .isEqualTo(LocalDate.of(2020, 2, 19));
        Assertions.assertThat(accessor.regulatoryReporting())
                .isNotNull()
                .isEqualTo(expectedRegulatoryReport);
        assertThat(accessor.instructingReimbursementAgentNCC())
                .isNotNull()
                .isEqualTo("cd");
        assertThat(accessor.instructingReimbursementAgentMemberId())
                .isNotNull()
                .isEqualTo("instructingMemberId");
        assertThat(accessor.instructingReimbursementAgentIdentification())
                .isNotNull()
                .isEqualTo("IL402173464146167671239");
        assertThat(accessor.instructedReimbursementAgentNCC())
                .isNotNull()
                .isEqualTo("cd");
        assertThat(accessor.instructedReimbursementAgentMemberId())
                .isNotNull()
                .isEqualTo("instructingMemberId");
        assertThat(accessor.instructedReimbursementAgentIdentification())
                .isNotNull()
                .isEqualTo("IL402173464146167671239");
        assertThat(accessor.clearingSystem())
                .isNotNull()
                .isEqualTo("CAM");
        assertThat(accessor.originalAmount().getCurrency().getCurrencyCode())
                .isNotNull()
                .isEqualTo("GBP");
        assertThat(accessor.originalAmount().getNumber().doubleValue())
                .isNotNull()
                .isEqualTo(1.04);
        assertThat(accessor.instructionsForNextAgent())
                .isNotNull()
                .isEqualTo(List.of("instructionsForNextAgent"));
        assertThat(accessor.intermediaryAgentNCCCode())
                .isNotNull()
                .isEqualTo("cd");
        Assertions.assertThat(accessor.debtorAgentAccount())
                .isNotNull()
                .isEqualTo(debtorAgentAccount);
        Assertions.assertThat(accessor.creditorAgentAccount())
                .isNotNull()
                .isEqualTo(creditorAgentAccount);
        assertThat(accessor.getExpensesType())
                .isNotNull()
                .isEqualTo("SHA");
        assertThatJson(accessor.getChargesInfo())
                .isEqualTo(List.of(expectedCharges));
        assertThat(accessor.uetr())
                .isNotNull()
                .isEqualTo(UUID.fromString("3d884a5b-7211-4aba-bc49-d088ea4a9275"));
        assertThat(accessor.creditorAgentNCCCode())
                .isNotNull()
                .isEqualTo("cd");
        assertThat(accessor.debtorAgentMemberId())
                .isNotNull()
                .isEqualTo("agentMemberId");
        assertThat(accessor.creditorAgentMemberId())
                .isNotNull()
                .isEqualTo("creditorAgentMemberId");
        assertThat(accessor.paymentScheme())
                .isNotNull()
                .isEqualTo("SWIFT");
        assertThat(accessor.debtorReferences())
                .isNotNull()
                .isEqualTo(List.of("usrtd1", "ustrd2"));
        assertThat(accessor.creditorReferences())
                .isNotNull()
                .isEqualTo(List.of());
        assertThat(accessor.exchangeRate())
                .isNotNull()
                .isEqualTo(BigDecimal.valueOf(1.0));
        assertThat(accessor.instructionsForCreditorAgent())
                .isNotNull()
                .isEqualTo(List.of("instructionsForCreditorAgent"));
    }
}
