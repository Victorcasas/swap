package com.santander.pagonxt.iso20022.messages.pain.pain001;


import com.santander.pagonxt.iso20022.common.exception.Pain001ReaderException;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.io.InputStream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

public class Pain001v03ReaderTest {

   @Test
    void shouldBeAbleToReadPainXMLFile() throws IOException, Pain001ReaderException {
        ClassLoader classLoader = getClass().getClassLoader();
        final InputStream inputFile = classLoader.getResourceAsStream("fixtures/messages/pain/pain001/GTS.I.PAIN01.0003.11");
        final Pain001v03Message message = Pain001Reader.readXml(inputFile);

        assertThat(message).isNotNull();
       assertThat(message.getAccessor()).isNotNull();
       message.validateMessage();



    }

    @Test
    void dontBeAbleToReadPainXMLFile() throws IOException, Pain001ReaderException {
        ClassLoader classLoader = getClass().getClassLoader();
        final InputStream inputFile = classLoader.getResourceAsStream("fixtures/messages/pain/pain001/EMPTYFILE");
        assertThatThrownBy(() -> {Pain001Reader.readXml(inputFile);})
                .isInstanceOf(Pain001ReaderException.class);


    }

}
