package com.santander.pagonxt.iso20022.messages.pacs.pacs008;

import com.santander.pagonxt.iso20022.IsoMessagesScaffolding;
import com.santander.pagonxt.iso20022.common.codes.ChargeBearer;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ActiveCurrencyAndAmount;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.ActiveOrHistoricCurrencyAndAmount;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.CreditTransferTransaction39;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.DateAndPlaceOfBirth1;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Document;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.FinancialInstitutionIdentification18;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

/**
 * The type Pacs 008 builder test.
 */
class Pacs008v08BuilderTest extends IsoMessagesScaffolding {

    /**
     * Should generate minimum data pacs 008 with build method.
     */
    @Test
    void shouldBuildAValidPacs008WithBuildMethod() {
        //given
        //when
        final Pacs008v08Message pacs008v08Message = new Pacs008v08Builder()
                .amount(AMOUNT)
                .debtor(DEBTOR)
                .endToEndId(E2E_ID)
                .creditor(CREDITOR)
                .messageId(MESSAGE_ID)
                .originalAmount(AMOUNT)
                .instructionId(INSTRUCTION_ID)
                .debtorAccount(DEBTOR_ACCOUNT)
                .remittanceInformation(SUBJECT)
                .chargeBearer(ChargeBearer.CRED)
                .creditorAccount(CREDITOR_ACCOUNT)
                .interbankSettlementDate(SETTLEMENT_DATE)
                .instructedAgent(INSTRUCTED_AGENT)
                .instructingAgent(INSTRUCTING_AGENT)
                .paymentSubtype(PAYMENT_SUBTYPE)
                .regulatoryReporting(REGULATORY_REPORT)
                .correspondentAccount(CORRESPONDENT_ACCOUNT)
                .instructedReimbursementAgent(INSTRUCTED_AGENT)
                .instructingReimbursementAgent(INSTRUCTING_AGENT)
                .build();

        //then
        final CreditTransferTransaction39 actualFirstTransaction =
                pacs008v08Message.document().getFIToFICstmrCdtTrf().getCdtTrfTxInves().get(0);

        assertDoesNotThrow(pacs008v08Message::validateMessage);
        assertIdentificationData(pacs008v08Message.document(), actualFirstTransaction);
        assertAmountData(actualFirstTransaction.getIntrBkSttlmAmt(), actualFirstTransaction.getInstdAmt());
        assertDebtorData(actualFirstTransaction);
        assertCreditorData(actualFirstTransaction);
        assertInstructionAgentData(actualFirstTransaction, pacs008v08Message.document());
        assertIntermediaryAgentData(actualFirstTransaction);
        assertRemittanceInformation(actualFirstTransaction);
        assertPaymentSubtypeData(actualFirstTransaction);
        assertInterbankSettlementDate(actualFirstTransaction);
        assertThat(actualFirstTransaction.getChrgBr().value())
                .isNotNull()
                .isEqualTo(ChargeBearer.CRED.toString());
        assertRegulatoryReportingData(actualFirstTransaction);
    }

    private void assertRegulatoryReportingData(CreditTransferTransaction39 actualFirstTransaction) {
        assertThat(actualFirstTransaction.getRgltryRptgs().get(0).getDbtCdtRptgInd().value())
                .isNotNull()
                .isEqualTo(REGULATORY_REPORT.getTypeCode().value());
        assertThat(actualFirstTransaction.getRgltryRptgs().get(0).getDtls().get(0).getCtry())
                .isNotNull()
                .isEqualTo(COUNTRY);
        assertThat(actualFirstTransaction.getRgltryRptgs().get(0).getDtls().get(0).getInves().get(0))
                .isNotNull()
                .isEqualTo(NARRATIVE);
    }

    private void assertInterbankSettlementDate(CreditTransferTransaction39 actualFirstTransaction) {
        assertThat(actualFirstTransaction.getIntrBkSttlmDt())
                .isNotNull()
                .isEqualTo(SETTLEMENT_DATE);
    }

    private void assertPaymentSubtypeData(CreditTransferTransaction39 actualFirstTransaction) {
        assertThat(actualFirstTransaction.getPmtTpInf().getCtgyPurp().getCd())
                .isNotNull()
                .isEqualTo(PAYMENT_SUBTYPE.value());
    }

    private void assertRemittanceInformation(CreditTransferTransaction39 actualFirstTransaction) {
        assertThat(actualFirstTransaction.getRmtInf().getUstrds().get(0))
                .isNotNull()
                .isEqualTo(SUBJECT);
        assertThat(actualFirstTransaction.getRmtInf().getStrds().get(0).getAddtlRmtInves().get(0))
                .isNotNull()
                .isEqualTo(SUBJECT);
    }

    private void assertIntermediaryAgentData(CreditTransferTransaction39 actualFirstTransaction) {
        assertThat(actualFirstTransaction.getIntrmyAgt1().getFinInstnId().getBICFI())
                .isNotNull()
                .isEqualTo(CORRESPONDENT_ACCOUNT.getBicfi());
        assertThat(actualFirstTransaction.getIntrmyAgt1().getFinInstnId().getNm())
                .isNotNull()
                .isEqualTo(CORRESPONDENT_ACCOUNT.getAgentName());
        assertThat(actualFirstTransaction.getIntrmyAgt1().getFinInstnId().getPstlAdr().getAdrLines())
                .isNotNull()
                .isEqualTo(CORRESPONDENT_ACCOUNT.getAgent().getAddress().getAddressLine());
    }

    private void assertInstructionAgentData(CreditTransferTransaction39 actualFirstTransaction,
                                            Document document) {
        final FinancialInstitutionIdentification18 instructedAgentData =
                document.getFIToFICstmrCdtTrf().getGrpHdr().getSttlmInf().getInstdRmbrsmntAgt().getFinInstnId();
        final FinancialInstitutionIdentification18 instructingAgentData =
                document.getFIToFICstmrCdtTrf().getGrpHdr().getSttlmInf().getInstgRmbrsmntAgt().getFinInstnId();
        assertThat(actualFirstTransaction.getInstdAgt().getFinInstnId().getBICFI())
                .isNotNull()
                .isEqualTo(Pacs008v08BuilderTest.INSTRUCTED_AGENT.getBicfi());
        assertThat(actualFirstTransaction.getInstgAgt().getFinInstnId().getBICFI())
                .isNotNull()
                .isEqualTo(Pacs008v08BuilderTest.INSTRUCTING_AGENT.getBicfi());
        assertThat(instructedAgentData.getBICFI())
                .isNotNull()
                .isEqualTo(Pacs008v08BuilderTest.INSTRUCTED_AGENT.getBicfi());
        assertThat(instructedAgentData.getNm())
                .isNotNull()
                .isEqualTo(Pacs008v08BuilderTest.INSTRUCTED_AGENT.getName());
        assertThat(instructedAgentData.getPstlAdr().getAdrLines())
                .isNotNull()
                .isEqualTo(Pacs008v08BuilderTest.INSTRUCTED_AGENT.getAddress().getAddressLine());
        assertThat(instructingAgentData.getBICFI())
                .isNotNull()
                .isEqualTo(Pacs008v08BuilderTest.INSTRUCTING_AGENT.getBicfi());
        assertThat(instructingAgentData.getNm())
                .isNotNull()
                .isEqualTo(Pacs008v08BuilderTest.INSTRUCTING_AGENT.getName());
        assertThat(instructingAgentData.getPstlAdr().getAdrLines())
                .isNotNull()
                .isEqualTo(Pacs008v08BuilderTest.INSTRUCTING_AGENT.getAddress().getAddressLine());
    }

    private void assertIdentificationData(Document document, CreditTransferTransaction39 actualFirstTransaction) {
        assertThat(document.getFIToFICstmrCdtTrf().getGrpHdr().getMsgId())
                .isNotNull()
                .isEqualTo(MESSAGE_ID);
        assertThat(actualFirstTransaction.getPmtId().getEndToEndId())
                .isNotNull()
                .isEqualTo(E2E_ID);
        assertThat(actualFirstTransaction.getPmtId().getTxId())
                .isNotNull()
                .isEqualTo(E2E_ID);
        assertThat(actualFirstTransaction.getPmtId().getInstrId())
                .isNotNull()
                .isEqualTo(INSTRUCTION_ID);
    }

    private void assertAmountData(ActiveCurrencyAndAmount intrBkSttlmAmt,
                                  ActiveOrHistoricCurrencyAndAmount instdAmt) {
        assertThat(intrBkSttlmAmt.getCcy())
                .isNotNull()
                .isEqualTo(AMOUNT.getCurrency().getCurrencyCode());
        assertThat(intrBkSttlmAmt.getValue())
                .isNotNull()
                .isEqualTo(BigDecimal.valueOf(AMOUNT.getNumber().doubleValue()));
        assertThat(instdAmt.getCcy())
                .isNotNull()
                .isEqualTo(AMOUNT.getCurrency().getCurrencyCode());
    }

    private void assertDebtorData(CreditTransferTransaction39 actualFirstTransaction) {
        assertThat(actualFirstTransaction.getDbtr().getNm())
                .isNotNull()
                .isEqualTo(DEBTOR.getName());
        assertThat(actualFirstTransaction.getDbtr().getPstlAdr().getTwnNm())
                .isNotNull()
                .isEqualTo(ADDRESS.getTown());
        assertThat(actualFirstTransaction.getDbtr().getPstlAdr().getPstCd())
                .isNotNull()
                .isEqualTo(ADDRESS.getPostCode());
        assertThat(actualFirstTransaction.getDbtr().getPstlAdr().getCtry())
                .isNotNull()
                .isEqualTo(ADDRESS.getCountry());
        assertThat(actualFirstTransaction.getDbtrAcct().getId().getOthr().getId())
                .isNotNull()
                .isEqualTo(ACCOUNT_NUMBER_1);
        assertThat(actualFirstTransaction.getDbtr().getId().getPrvtId().getOthrs().get(0).getId())
                .isNotNull()
                .isEqualTo(DEBTOR.getPartyType().identifier());
        assertThat(actualFirstTransaction.getDbtrAgt().getFinInstnId().getBICFI())
                .isNotNull()
                .isEqualTo(BICFI_1);
        assertThat(actualFirstTransaction.getDbtrAgt().getFinInstnId().getNm())
                .isNotNull()
                .isEqualTo(DEBTOR_AGENT_NAME);
        assertThat(actualFirstTransaction.getDbtrAgt().getFinInstnId().getPstlAdr().getAdrLines())
                .isNotNull()
                .isEqualTo(ADDRESS_LINE_0);
        assertDateAndPlaceOfBirth(actualFirstTransaction);
    }

    private void assertDateAndPlaceOfBirth(CreditTransferTransaction39 actualFirstTransaction) {
        final DateAndPlaceOfBirth1 actualDtAndPlcOfBirth =
                actualFirstTransaction.getDbtr().getId().getPrvtId().getDtAndPlcOfBirth();
        assertThat(actualDtAndPlcOfBirth.getBirthDt())
                .isNotNull()
                .isEqualTo(LocalDate.of(2021, 10, 1));
        assertThat(actualDtAndPlcOfBirth.getCityOfBirth())
                .isNotNull()
                .isEqualTo(TOWN);
        assertThat(actualDtAndPlcOfBirth.getCtryOfBirth())
                .isNotNull()
                .isEqualTo(COUNTRY);
    }

    private void assertCreditorData(CreditTransferTransaction39 actualFirstTransaction) {
        assertThat(actualFirstTransaction.getCdtr().getNm())
                .isNotNull()
                .isEqualTo(CREDITOR.getName());
        assertThat(actualFirstTransaction.getCdtr().getPstlAdr().getTwnNm())
                .isNotNull()
                .isEqualTo(ADDRESS.getTown());
        assertThat(actualFirstTransaction.getCdtr().getPstlAdr().getPstCd())
                .isNotNull()
                .isEqualTo(ADDRESS.getPostCode());
        assertThat(actualFirstTransaction.getCdtr().getPstlAdr().getCtry())
                .isNotNull()
                .isEqualTo(ADDRESS.getCountry());
        assertThat(actualFirstTransaction.getCdtrAcct().getId().getOthr().getId())
                .isNotNull()
                .isEqualTo(ACCOUNT_NUMBER_2);
        assertThat(actualFirstTransaction.getCdtr().getId().getPrvtId().getOthrs().get(0).getId())
                .isNotNull()
                .isEqualTo(CREDITOR.getPartyType().identifier());
        assertThat(actualFirstTransaction.getCdtrAgt().getFinInstnId().getBICFI())
                .isNotNull()
                .isEqualTo(BICFI_2);
        assertThat(actualFirstTransaction.getCdtrAgt().getFinInstnId().getNm())
                .isNotNull()
                .isEqualTo(CREDITOR_AGENT_NAME);
        assertThat(actualFirstTransaction.getCdtrAgt().getFinInstnId().getPstlAdr().getAdrLines())
                .isNotNull()
                .isEqualTo(ADDRESS_LINE_0);
    }
}