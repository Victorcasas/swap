package com.santander.pagonxt.iso20022.messages.pacs.pacs004;

import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Document;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static com.santander.pagonxt.iso20022.IsoMessagesScaffolding.buildNotValidPacs004Document;
import static com.santander.pagonxt.iso20022.IsoMessagesScaffolding.buildValidPacs004Document;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

class Pacs004v09ValidatorTest {

    @Test
    void shouldNotValidateInvalidPacs004Document_andThrowMarshalException() {
        //given
        final Document pacs004 = buildNotValidPacs004Document();
        final Pacs004v09Message pacs004v09Message = new Pacs004v09Message(pacs004);

        //when
        //then
        assertThatThrownBy(pacs004v09Message::validateMessage)
                .isInstanceOf(RuntimeException.class);
    }

    /**
     * Should validate valid pacs 008 document.
     *
     * @throws IOException the io exception
     */
    @Test
    void shouldValidateValidPacs004Document() throws IOException {
        //given
        final Document pacs004 = buildValidPacs004Document();

        //when
        //then
        assertDoesNotThrow(() -> new Pacs004v09Message(pacs004).validateMessage());
    }

    /**
     * Should throw not validate when document is null.
     */
    @Test
    void shouldThrowNotValidateWhenDocumentIsNull() {
        //given
        final Pacs004v09Message pacs004v09Message = new Pacs004v09Message(null);
        //when
        //then
        assertThatThrownBy(pacs004v09Message::validateMessage)
                .isInstanceOf(RuntimeException.class)
                .hasMessage("Process stopped, trying to validate null document");
    }
}
