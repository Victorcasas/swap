package com.santander.pagonxt.iso20022.xmladapter;

import com.santander.pagonxt.iso20022.xmladapter.XMLAdapter;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.time.LocalDateTime;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * The type Xml adapter test.
 */
class XMLAdapterTest {

    /**
     * Unmarshal date.
     */
    @Test
    void unmarshalDate() {
        final LocalDate expectedDate = LocalDate.of(2021, 10, 3);

        final LocalDate actualDate = XMLAdapter.unmarshalDate("2021-10-03");

        assertThat(actualDate)
                .isNotNull()
                .isEqualTo(expectedDate);
    }

    /**
     * Marshal date.
     */
    @Test
    void marshalDate() {
        final String expectedDateString = "2021-10-03";

        final String actualDateString = XMLAdapter.marshalDate(LocalDate.of(2021, 10, 3));

        assertThat(actualDateString)
                .isNotNull()
                .isEqualTo(expectedDateString);
    }

    /**
     * Unmarshal date time.
     */
    @Test
    void unmarshalDateTime() {
        final LocalDateTime expectedDateTime =
                LocalDateTime.of(2021, 10, 3, 10, 40);

        final LocalDateTime actualDateTime = XMLAdapter.unmarshalDateTime("2021-10-03T10:40");

        assertThat(actualDateTime)
                .isNotNull()
                .isEqualTo(expectedDateTime);
    }

    /**
     * Marshal date time.
     */
    @Test
    void marshalDateTime() {
        final String expectedDateTimeString = "2021-10-03T10:40:00";

        final String actualDateTimeString =
                XMLAdapter.marshalDateTime(LocalDateTime.of(2021, 10, 3, 10, 40));

        assertThat(actualDateTimeString)
                .isNotNull()
                .isEqualTo(expectedDateTimeString);
    }
}