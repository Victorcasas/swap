package com.santander.pagonxt.iso20022;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.accounts.SortcodeAccountNumber;
import com.santander.pagonxt.iso20022.common.codes.Proprietary;
import com.santander.pagonxt.iso20022.common.exception.Pain001ReaderException;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.fields.ReasonInfo;
import com.santander.pagonxt.iso20022.common.fields.RegulatoryReport;
import com.santander.pagonxt.iso20022.common.fields.RegulatoryReportingTypeCode;
import com.santander.pagonxt.iso20022.common.fields.SchemeInfo;
import com.santander.pagonxt.iso20022.common.paymentsubtype.IsoCode;
import com.santander.pagonxt.iso20022.common.paymentsubtype.PaymentSubtype;
import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Document;
import org.apache.commons.io.IOUtils;

import javax.money.MonetaryAmount;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import static com.santander.pagonxt.iso20022.common.fields.SchemeInfo.Scheme.FP;
import static javax.money.Monetary.getDefaultAmountFactory;

/**
 * The type Iso messages scaffolding.
 */
public class IsoMessagesScaffolding {

    /**
     * The E 2 e id.
     */
    protected static final String E2E_ID = "e2e-id";
    /**
     * The Message id.
     */
    protected static final String MESSAGE_ID = "message-id";
    protected static final String ORIGINAL_MESSAGE_ID = "original-message-id";
    protected static final String ORIGINAL_MESSAGE_NAME_ID = "original-message-name-id";
    protected static final UUID UETR = UUID.fromString("f2ff2344-cdc0-4c52-bbae-f1703b0dd2cb");
    /**
     * The Instruction id.
     */
    protected static final String INSTRUCTION_ID = "instructionId";
    protected static final String TRANSACTION_ID = "instructionId";
    protected static final String TRANSACTION_REFERENCE = "instructionId";
    /**
     * The Bicfi 1.
     */
    protected static final String BICFI_1 = "ABBYGB20";
    /**
     * The Bicfi 2.
     */
    protected static final String BICFI_2 = "ABBYGB21";
    /**
     * The Bicfi 3.
     */
    protected static final String BICFI_3 = "ABBYGB22";
    /**
     * The Sortcode 1.
     */
    protected static final String SORTCODE_1 = "000000";
    /**
     * The Sortcode 2.
     */
    protected static final String SORTCODE_2 = "666666";
    /**
     * The Sortcode 3.
     */
    protected static final String SORTCODE_3 = "777777";
    /**
     * The Account number 1.
     */
    protected static final String ACCOUNT_NUMBER_1 = "12345678";
    /**
     * The Account number 2.
     */
    protected static final String ACCOUNT_NUMBER_2 = "87654321";
    /**
     * The Account number 3.
     */
    protected static final String ACCOUNT_NUMBER_3 = "12348765";
    /**
     * The Other id.
     */
    protected static final String OTHER_ID = "other-id";
    /**
     * The Town.
     */
    protected static final String TOWN = "Madrid";
    /**
     * The Country.
     */
    protected static final String COUNTRY = "ES";
    /**
     * The Subject.
     */
    protected static final String SUBJECT = "subject";
    /**
     * The constant NARRATIVE.
     */
    protected static final String NARRATIVE = "narrative";
    /**
     * The Debtor agent name.
     */
    protected static final String DEBTOR_AGENT_NAME = "debtor-agent-name";
    /**
     * The Creditor agent name.
     */
    protected static final String CREDITOR_AGENT_NAME = "creditor-agent-name";
    protected static final String TPP_ID = "tppid";
    protected static final String AUTHORIZATION = "auth";
    /**
     * The Address line 0.
     */
    protected static final List<String> ADDRESS_LINE_0 = List.of("addressLine-0");
    /**
     * The Settlement date.
     */
    protected static final LocalDate SETTLEMENT_DATE = LocalDate.of(2021, 10, 1);

    protected static final LocalDate REQUESTED_COLLECTION_DATE = LocalDate.of(2021, 9, 30);
    /**
     * The Payment subtype.
     */
    protected static final PaymentSubtype PAYMENT_SUBTYPE = new IsoCode(IsoCode.Codes.TAXS);
    /**
     * The Amount.
     */
    protected static final MonetaryAmount AMOUNT = getDefaultAmountFactory()
            .setCurrency("EUR")
            .setNumber(1.0)
            .create();

    protected static final BigDecimal EXCHANGE_RATE = new BigDecimal("2.0");
    /**
     * The Address.
     */
    protected static final PartyIdentification.Address ADDRESS = PartyIdentification.Address.builder()
            .postCode("28752")
            .town(TOWN)
            .country(COUNTRY)
            .build();
    /**
     * The Debtor.
     */
    protected static final PartyIdentification DEBTOR = PartyIdentification.builder()
            .name("debtorName")
            .address(ADDRESS)
            .partyType(PartyIdentification.Person.builder()
                    .otherId("other-id")
                    .build())
            .id(PartyIdentification.PartyChoice.builder()
                    .prvtId(PartyIdentification.PersonIdentification.builder()
                            .dtAndPlcOfBirth(PartyIdentification.DateAndPlaceOfBirth.builder()
                                    .birthDt(LocalDate.of(2021, 10, 1))
                                    .birthCountry(COUNTRY)
                                    .cityOfBirth(TOWN)
                                    .build())
                            .build())
                    .build())
            .build();
    /**
     * The Creditor.
     */
    protected static final PartyIdentification CREDITOR = PartyIdentification.builder()
            .name("creditorName")
            .address(ADDRESS)
            .partyType(PartyIdentification.Person.builder()
                    .otherId(OTHER_ID)
                    .build())
            .build();
    /**
     * The Debtor account.
     */
    protected static final SortcodeAccountNumber DEBTOR_ACCOUNT = SortcodeAccountNumber.builder()
            .bicfi(BICFI_1)
            .sortcode(SORTCODE_1)
            .accountNumber(ACCOUNT_NUMBER_1)
            .address(PartyIdentification.Address.builder()
                    .country(COUNTRY)
                    .addressLine(ADDRESS_LINE_0)
                    .build())
            .agentName(DEBTOR_AGENT_NAME)
            .build();
    /**
     * The Creditor account.
     */
    protected static final SortcodeAccountNumber CREDITOR_ACCOUNT = SortcodeAccountNumber.builder()
            .bicfi(BICFI_2)
            .sortcode(SORTCODE_2)
            .accountNumber(ACCOUNT_NUMBER_2)
            .address(PartyIdentification.Address.builder()
                    .country(COUNTRY)
                    .addressLine(ADDRESS_LINE_0)
                    .build())
            .agentName(CREDITOR_AGENT_NAME)
            .build();
    /**
     * The Correspondent account.
     */
    protected static final SortcodeAccountNumber CORRESPONDENT_ACCOUNT = SortcodeAccountNumber.builder()
            .bicfi(BICFI_3)
            .sortcode(SORTCODE_3)
            .accountNumber(ACCOUNT_NUMBER_3)
            .address(PartyIdentification.Address.builder()
                    .country(COUNTRY)
                    .addressLine(ADDRESS_LINE_0)
                    .build())
            .agentName("correspondent-agent-name")
            .build();
    /**
     * The Instructed agent.
     */
    protected static final BankAccount.Agent INSTRUCTED_AGENT = BankAccount.Agent.builder()
            .bicfi(BICFI_2)
            .name("instructedAgentName")
            .address(ADDRESS)
            .build();
    /**
     * The Instructing agent.
     */
    protected static final BankAccount.Agent INSTRUCTING_AGENT = BankAccount.Agent.builder()
            .bicfi(BICFI_1)
            .name("instructedAgentName")
            .address(ADDRESS)
            .build();
    /**
     * The Regulatory report.
     */
    protected static final RegulatoryReport REGULATORY_REPORT = RegulatoryReport.builder()
            .country(COUNTRY)
            .narrative(NARRATIVE)
            .typeCode(RegulatoryReportingTypeCode.BOTH)
            .build();

    protected static final String[] DEBTOR_REFERENCES = {"debtor ref 1", "debtor ref 2", "debtor ref 3"};
    protected static final String[] CREDITOR_REFERENCES = {"debtor ref 1", "debtor ref 2", "debtor ref 3"};

    protected static final String PAYMENT_SCHEME = "FP";

    protected static final SchemeInfo SCHEME_ID = new SchemeInfo("scheme-id", FP);
    protected static final ReasonInfo REASON = ReasonInfo.builder()
            .code(Proprietary.builder()
                    .code("reason-code")
                    .build())
            .rawCode("raw-reason-code")
            .rawDescription("reason description")
            .build();

    protected static final ObjectMapper objectMapper = new ObjectMapper()
            .setSerializationInclusion(JsonInclude.Include.NON_NULL)
            .registerModule(new JavaTimeModule())
            .setDateFormat(DateFormat.getDateInstance());

    /**
     * Build not valid pacs 008 document document.
     *
     * @return the document
     */
    public static Document buildNotValidPacs008Document() {
        return new Document();
    }

    public static com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Document buildNotValidPacs004Document() {
        return new com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Document();
    }

    /**
     *
     * @return pain001 non-valid Document
     */
    public static com.santander.pagonxt.iso20022.messages.pain.pain001.model.Document buildNotValidPain001Document() {
        return new com.santander.pagonxt.iso20022.messages.pain.pain001.model.Document();
    }

    /**
     * Build valid pacs 008 document document.
     *
     * @return the document
     * @throws IOException the io exception
     */
    public static Document buildValidPacs008Document() throws IOException {
        return objectMapper.readValue(readString("fixtures/messages/pacs/pacs008/validPacs008v08.json"),
                Document.class);
    }

    public static com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Document buildValidPacs004Document()
            throws IOException {
        return objectMapper.readValue(readString("fixtures/messages/pacs/pacs004/validPacs004v09.json"),
                com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Document.class);
    }

    public static com.santander.pagonxt.iso20022.messages.pain.pain001.model.Document buildValidPain001Document()
            throws JAXBException {

        final JAXBContext jaxbContext = JAXBContext.newInstance(com.santander.pagonxt.iso20022.messages.pain.pain001.model.Document.class);
        final Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();

        ClassLoader classLoader = IsoMessagesScaffolding.class.getClassLoader();
        final InputStream inputFile = classLoader.getResourceAsStream("fixtures/messages/pain/pain001/GTS.I.PAIN01.0003.3");

        var documentPain001 = (com.santander.pagonxt.iso20022.messages.pain.pain001.model.Document) jaxbUnmarshaller.unmarshal(inputFile);

        return documentPain001;
    }

    /**
     * Read string string.
     *
     * @param path the path
     * @return the string
     * @throws IOException the io exception
     */
    public static String readString(String path) throws IOException {
        InputStream inputStream = IsoMessagesScaffolding.class.getClassLoader().getResourceAsStream(path);
        assert inputStream != null;
        return IOUtils.toString(inputStream, StandardCharsets.UTF_8.name());
    }
}
