package com.santander.pagonxt.iso20022.messages.pacs.pacs008;

import com.santander.pagonxt.iso20022.messages.pacs.pacs008.model.Document;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static com.santander.pagonxt.iso20022.IsoMessagesScaffolding.buildNotValidPacs008Document;
import static com.santander.pagonxt.iso20022.IsoMessagesScaffolding.buildValidPacs008Document;
import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.junit.jupiter.api.Assertions.assertDoesNotThrow;

/**
 * The type Pacs 008 validator test.
 */
class Pacs008v08ValidatorTest {

    /**
     * Should not validate invalid pacs 008 document and throw marshal exception.
     */
    @Test
    void shouldNotValidateInvalidPacs008Document_andThrowMarshalException() {
        //given
        final Document pacs008 = buildNotValidPacs008Document();

        //when
        //then
        assertThatThrownBy(() -> new Pacs008v08Message(pacs008).validateMessage())
                .isInstanceOf(RuntimeException.class);
    }

    /**
     * Should validate valid pacs 008 document.
     *
     * @throws IOException the io exception
     */
    @Test
    void shouldValidateValidPacs008Document() throws IOException {
        //given
        final Document pacs008 = buildValidPacs008Document();

        //when
        //then
        assertDoesNotThrow(() -> new Pacs008v08Message(pacs008).validateMessage());
    }

    /**
     * Should throw not validate when document is null.
     */
    @Test
    void shouldThrowNotValidateWhenDocumentIsNull() {
        //given
        //when
        //then
        assertThatThrownBy(() -> new Pacs008v08Message(null).validateMessage())
                .isInstanceOf(RuntimeException.class)
                .hasMessage("Process stopped, trying to validate null document");
    }
}
