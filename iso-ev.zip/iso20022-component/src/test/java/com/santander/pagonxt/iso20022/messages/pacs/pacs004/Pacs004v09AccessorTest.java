package com.santander.pagonxt.iso20022.messages.pacs.pacs004;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.santander.pagonxt.iso20022.common.accounts.BankAccount;
import com.santander.pagonxt.iso20022.common.accounts.SortcodeAccountNumber;
import com.santander.pagonxt.iso20022.common.fields.PartyIdentification;
import com.santander.pagonxt.iso20022.common.fields.ReasonInfo;
import com.santander.pagonxt.iso20022.common.fields.RemittanceInformation;
import com.santander.pagonxt.iso20022.common.fields.ReturnReason;
import com.santander.pagonxt.iso20022.core.Iso20022MessageAccessor;
import com.santander.pagonxt.iso20022.messages.pacs.pacs004.model.Document;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.text.DateFormat;
import java.util.List;
import java.util.UUID;

import static com.santander.pagonxt.iso20022.IsoMessagesScaffolding.readString;
import static com.santander.pagonxt.iso20022.common.fields.Priority.NORM;
import static com.santander.pagonxt.iso20022.common.fields.ReasonInfo.AdditionalInformation.additionalInformation;
import static javax.money.Monetary.getDefaultAmountFactory;
import static org.assertj.core.api.Assertions.assertThat;

class Pacs004v09AccessorTest {

    private static ObjectMapper mapper;

    @BeforeAll
    static void setUp() {
        mapper = new ObjectMapper()
                .setSerializationInclusion(JsonInclude.Include.NON_NULL)
                .registerModule(new JavaTimeModule())
                .setDateFormat(DateFormat.getDateInstance());
    }

    @Test
    void shouldBeAbleToAccessCorrectlyPacs004Properties() throws IOException {
        final String expectedMessageId = "message-id";
        final Document document =
                mapper.readValue(readString("fixtures/messages/pacs/pacs004/validPacs004v09.json"), Document.class);
        final Pacs004v09Message pacs004v09Message = new Pacs004v09Message(document);
        final Iso20022MessageAccessor<Document> pacs004v09Accessor = pacs004v09Message.getAccessor();

        assertThat(pacs004v09Accessor.messageId())
                .isNotNull()
                .isEqualTo(expectedMessageId);
        assertThat(pacs004v09Accessor.paymentScheme())
                .isNotNull()
                .isEqualTo("FP");
        assertThat(pacs004v09Accessor.schemeId())
                .isNotNull()
                .isEqualTo("debtor ref 1");
        assertThat(pacs004v09Accessor.paymentSubType())
                .isNotNull()
                .isEqualTo("SHAR");
        assertThat(pacs004v09Accessor.paymentCode())
                .isNotNull()
                .isEqualTo("instrument");
        assertThat(pacs004v09Accessor.amount())
                .isNotNull()
                .isEqualTo(getDefaultAmountFactory()
                        .setCurrency("EUR")
                        .setNumber(1.0)
                        .create());
        assertThat(pacs004v09Accessor.debtorAccount())
                .isNotNull()
                .isEqualTo(SortcodeAccountNumber.builder()
                        .accountNumber("12345678")
                        .agentName("debtor-agent-name")
                        .bicfi("ABBYGB20")
                        .sortcode("000000")
                        .address(PartyIdentification.Address.builder()
                                .country("ES")
                                .addressLine(List.of("addressLine-0"))
                                .build())
                        .build());
        assertThat(pacs004v09Accessor.creditorAccount())
                .isNotNull()
                .isEqualTo(SortcodeAccountNumber.builder()
                        .accountNumber("87654321")
                        .agentName("creditor-agent-name")
                        .bicfi("ABBYGB21")
                        .sortcode("666666")
                        .address(PartyIdentification.Address.builder()
                                .country("ES")
                                .addressLine(List.of("addressLine-0"))
                                .build())
                        .build());
        assertThat(pacs004v09Accessor.debtor())
                .isNotNull()
                .isEqualTo(PartyIdentification.builder()
                        .name("debtorName")
                        .address(PartyIdentification.Address.builder()
                                .postCode("28752")
                                .town("Madrid")
                                .country("ES")
                                .build())
                        .partyType(PartyIdentification.Person.builder()
                                .otherId("other-id")
                                .build())
                        .build());
        assertThat(pacs004v09Accessor.creditor())
                .isNotNull()
                .isEqualTo(PartyIdentification.builder()
                        .name("creditorName")
                        .address(PartyIdentification.Address.builder()
                                .postCode("28752")
                                .town("Madrid")
                                .country("ES")
                                .build())
                        .partyType(PartyIdentification.Person.builder()
                                .otherId("other-id")
                                .build())
                        .build());
        assertThat(pacs004v09Accessor.debtorReferences())
                .isNotNull()
                .isEqualTo(List.of("debtor ref 1", "debtor ref 2", "debtor ref 3"));
        assertThat(pacs004v09Accessor.creditorReferences())
                .isNotNull()
                .isEqualTo(List.of());
        assertThat(pacs004v09Accessor.instructionPriority())
                .isNotNull()
                .isEqualTo(NORM);
        assertThat(pacs004v09Accessor.transactionId())
                .isNotNull()
                .isEqualTo("instructionId");
        assertThat(pacs004v09Accessor.transactionReference())
                .isNotNull()
                .isEqualTo("instructionId");
        assertThat(pacs004v09Accessor.endToEndId())
                .isNotNull()
                .isEqualTo("e2e-id");
        assertThat(pacs004v09Accessor.uetr())
                .isNotNull()
                .isEqualTo(UUID.fromString("f2ff2344-cdc0-4c52-bbae-f1703b0dd2cb"));
        assertThat(pacs004v09Accessor.instructionId())
                .isNotNull()
                .isEqualTo("instructionId");
        assertThat(pacs004v09Accessor.originalTransactionId())
                .isNotNull()
                .isEqualTo("original-tx-id");
        assertThat(pacs004v09Accessor.originalMessageId())
                .isNotNull()
                .isEqualTo("original-message-id");
        assertThat(pacs004v09Accessor.originalMessageName())
                .isNotNull()
                .isEqualTo("original-message-name-id");
        assertThat(pacs004v09Accessor.requestedCollectionDate())
                .isNotNull()
                .isEqualTo("2021-09-30");
        assertThat(pacs004v09Accessor.tppId())
                .isNotNull()
                .isEqualTo("tppid");
        assertThat(pacs004v09Accessor.remittanceInformation())
                .isNotNull()
                .isEqualTo(RemittanceInformation.builder()
                        .reference("debtor ref 1")
                        .unstructured("debtor ref 2")
                        .build());
        assertThat(pacs004v09Accessor.originalAmount())
                .isNotNull()
                .isEqualTo(getDefaultAmountFactory()
                        .setCurrency("EUR")
                        .setNumber(2.5)
                        .create());
        assertThat(pacs004v09Accessor.interBankSttlmDate())
                .isNotNull()
                .isEqualTo("2021-09-30");
        assertThat(pacs004v09Accessor.originalTxInternationalBankSettlementDate())
                .isNotNull()
                .isEqualTo("2021-09-30");
        assertThat(pacs004v09Accessor.xchgRate())
                .isNotNull()
                .isEqualTo("2.0");
        assertThat(pacs004v09Accessor.compensationAmount())
                .isNotNull()
                .isEqualTo(getDefaultAmountFactory()
                        .setCurrency("EUR")
                        .setNumber(1.5)
                        .create());
        assertThat(pacs004v09Accessor.ultimateDebtor())
                .isNotNull()
                .isEqualTo(PartyIdentification.builder()
                        .name("debtorName")
                        .address(PartyIdentification.Address.builder()
                                .postCode("28752")
                                .town("Madrid")
                                .country("ES")
                                .build())
                        .partyType(PartyIdentification.Person.builder()
                                .otherId("other-id")
                                .build())
                        .build());
        assertThat(pacs004v09Accessor.debtorParty())
                .isNotNull()
                .isEqualTo(PartyIdentification.builder()
                        .name("debtorName")
                        .address(PartyIdentification.Address.builder()
                                .postCode("28752")
                                .town("Madrid")
                                .country("ES")
                                .build())
                        .partyType(PartyIdentification.Person.builder()
                                .otherId("other-id")
                                .build())
                        .build());
        assertThat(pacs004v09Accessor.ultimateCreditor())
                .isNotNull()
                .isEqualTo(PartyIdentification.builder()
                        .name("creditorName")
                        .address(PartyIdentification.Address.builder()
                                .postCode("28752")
                                .town("Madrid")
                                .country("ES")
                                .build())
                        .partyType(PartyIdentification.Person.builder()
                                .otherId("other-id")
                                .build())
                        .build());
        assertThat(pacs004v09Accessor.creditorParty())
                .isNotNull()
                .isEqualTo(PartyIdentification.builder()
                        .name("creditorName")
                        .address(PartyIdentification.Address.builder()
                                .postCode("28752")
                                .town("Madrid")
                                .country("ES")
                                .build())
                        .partyType(PartyIdentification.Person.builder()
                                .otherId("other-id")
                                .build())
                        .build());
        assertThat(pacs004v09Accessor.returnedInstructedAmount())
                .isNotNull()
                .isEqualTo(getDefaultAmountFactory()
                        .setCurrency("EUR")
                        .setNumber(1.0)
                        .create());
        ReasonInfo.AdditionalInformation additionalInformation = additionalInformation();
        additionalInformation.setExtraInfo(List.of("raw-reason-code", "reason description"));
        assertThat(pacs004v09Accessor.returnReason().getRawCode())
                .isNotNull()
                .isEqualTo("raw-reason-code");
        assertThat(pacs004v09Accessor.returnReason().getCode().code())
                .isNotNull()
                .isEqualTo(ReturnReason.AC01.code());
        assertThat(pacs004v09Accessor.returnReason().getRawDescription())
                .isNotNull()
                .isEqualTo("reason description");
        assertThat(pacs004v09Accessor.returnReason().getAdditionalInformation())
                .isNotNull()
                .isEqualTo(additionalInformation);
        assertThat(pacs004v09Accessor.instructingAgent())
                .isNotNull()
                .isEqualTo(BankAccount.Agent.builder()
                        .bicfi("ABBYGB24")
                        .build());
        assertThat(pacs004v09Accessor.instructedAgent())
                .isNotNull()
                .isEqualTo(BankAccount.Agent.builder()
                        .bicfi("ABBYGB25")
                        .build());
        assertThat(pacs004v09Accessor.debtorAgent())
                .isNotNull()
                .isEqualTo(BankAccount.Agent.builder()
                        .name("instructedAgentName")
                        .bicfi("ABBYGB21")
                        .address(PartyIdentification.Address.builder()
                                .postCode("28752")
                                .town("Madrid")
                                .country("ES")
                                .build())
                        .build());
        assertThat(pacs004v09Accessor.creditorAgent())
                .isNotNull()
                .isEqualTo(BankAccount.Agent.builder()
                        .name("instructingAgentName")
                        .bicfi("ABBYGB20")
                        .address(PartyIdentification.Address.builder()
                                .postCode("28752")
                                .town("Madrid")
                                .country("ES")
                                .build())
                        .build());
    }
}
